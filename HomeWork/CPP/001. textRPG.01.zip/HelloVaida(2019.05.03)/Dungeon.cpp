#include "stdafx.h"
#include "Player.h"
#include "Monster.h"
#include "Dungeon.h"


Dungeon::Dungeon()
	: mpPlayer(nullptr), mpMonster(nullptr), mBattleState(BATTLE_STATE::AGAIN)
{

}


Dungeon::~Dungeon()
{
	Release();
}

void Dungeon::Init(void)
{
}

void Dungeon::Progress(void)
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		cout << "1. �ʱ�, 2. �߱�, 3. ����, 4. ����, 5. �ҷ�����, 6. ������" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			mpMonster = new Monster(Info("������", 1, 30, 10));
			break;
		case 2:
			mpMonster = new Monster(Info("������", 1, 30, 10));
			break;
		case 3:
			mpMonster = new Monster(Info("������", 1, 30, 10));
			break;

		case 4:
			SaveData();
			continue;
		case 5:
			LoadData();
			continue;

		case 6:
			return;

		default:
			continue;
		}

		GoIntoTheDungeon();

		switch (mBattleState)
		{
		case BATTLE_STATE::RUN:
			//mpPlayer->setGold(0);
			dynamic_cast<Player *>(mpPlayer)->setGold(0);
			break;
		case BATTLE_STATE::HUNT:
			GetDungeonReward();
			break;
		case BATTLE_STATE::DIE:
			//mpPlayer->setExp(0);
			//mpPlayer->setHp(mpPlayer->getMaxHp());
			dynamic_cast<Player *>(mpPlayer)->setExp(0);
			mpPlayer->setHp(dynamic_cast<Player *>(mpPlayer)->getMaxHp());
			break;
		}

		Release();
	}
}

void Dungeon::Release(void)
{
	//cout << "Dungeon::Release()" << endl;
	//system("pause");
	SAFE_DELETE(mpMonster);
}

void Dungeon::GoIntoTheDungeon(void)
{
	int sel = 0;

	mBattleState = BATTLE_STATE::AGAIN;
	while (mBattleState == BATTLE_STATE::AGAIN)
	{
		system("cls");
		mpPlayer->ShowStatus();
		mpMonster->ShowStatus();
		cout << "1. ����, 2. ����" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			mBattleState = AttackMonster();
			break;
		case 2:
			mBattleState = BATTLE_STATE::RUN;
			break;

		default:
			continue;
		}
	}
}

BATTLE_STATE Dungeon::AttackMonster(void)
{
	mpPlayer->GetDamaged(mpMonster->getAttackDamage());
	mpMonster->GetDamaged(mpPlayer->getAttackDamage());

	if (mpPlayer->getHp() <= 0)
	{
		system("cls");
		mpPlayer->setHp(0);
		if (mpMonster->getHp() <= 0)
		{
			mpMonster->setHp(0);
		}

		mpPlayer->ShowStatus();
		mpMonster->ShowStatus();

		if (mpMonster->getHp() <= 0)
		{
			cout << "�ƽ��Ե�.. " << endl;
		}
		cout << "[��� ����]" << endl;


		system("pause");

		return BATTLE_STATE::DIE;
	}
	else if (mpMonster->getHp() <= 0)
	{
		system("cls");

		mpMonster->setHp(0);
		mpPlayer->ShowStatus();
		mpMonster->ShowStatus();
		cout << "[��� ����]" << endl;

		system("pause");
		
		return BATTLE_STATE::HUNT;
	}

	return BATTLE_STATE::AGAIN;
}

void Dungeon::GetDungeonReward(void)
{
	dynamic_cast<Player *>(mpPlayer)->GetReward(mpMonster->getExp(), mpMonster->getGold());
}

void Dungeon::SaveData(void)
{
}

void Dungeon::LoadData(void)
{
}
