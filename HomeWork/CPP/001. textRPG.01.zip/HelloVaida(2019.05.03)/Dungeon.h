#pragma once
#ifndef _DUNGEON_H_
#define _DUNGEON_H_

//class Obj;

class Dungeon
{
public:
	Dungeon();
	~Dungeon();

public:
	void Init(void);
	void Progress(void);
	void Release(void);

public:
	void GoIntoTheDungeon(void);

	BATTLE_STATE AttackMonster(void);

	void GetDungeonReward(void);

	void SaveData(void);
	void LoadData(void);

public:
	void setPPlayer(Obj *pPlayer) { mpPlayer = pPlayer; }

private:
	Obj *mpPlayer;
	Obj *mpMonster;

	BATTLE_STATE mBattleState;
};


#endif