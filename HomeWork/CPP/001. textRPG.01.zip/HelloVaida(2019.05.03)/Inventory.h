#pragma once
#ifndef _INVENTORY_H_
#define _INVENTORY_H_

class Obj;

class Inventory
{
public:
	Inventory();
	~Inventory();

public:
	void Init(void);
	void Progress(void);
	void Release(void);

public:
	void ShowInventory(void);

	bool PushItem(Obj *item);
	const int PopItem(int index);

	void EquipItem(void);
	void UnEquipItem(void);

public:

	ITEM GetItemType(int index);
	ITEM_STATE GetItemState(int index);

	bool isInventoryEmpty(void);
	bool isInventoryFull(void);

	void SaveData(FILE *fp);
	void LoadData(FILE *fp);

public:
	void setPPlyaer(Obj *pPlayer) { mpPlayer = pPlayer; }

private:
	Obj *mpPlayer;
	size_t mMaxSize;
	vector<Obj *> mVecItem;
};

#endif
