#include "stdafx.h"
#include "Item.h"

Item::Item()
{
}

Item::Item(const Info & ref)
	: Obj(ref), mItemType(ITEM::ITEM_END), mItemState(ITEM_STATE::UNEQUIP)
{
	Init();
}


Item::~Item()
{
	Release();
}

void Item::Init(void)
{
}

void Item::Progress(void)
{
}

void Item::Release(void)
{
	//cout << "Item::Release()" << endl;
	//system("pause");
}

void Item::ShowStatus(void)
{
	if (mItemState == ITEM_STATE::EQUIP)
	{
		cout << "<<<<< ������ >>>>>" << endl;
	}
	cout << "��  ��: " << mInfo.level << endl;
	cout << "��  ��: " << mInfo.className << endl;
	cout << "ü  ��: ";
	if (mInfo.hp > 0)
		cout << "+";
	cout << mInfo.hp << endl;
	cout << "���ݷ�: ";
	if (mInfo.attackDamage > 0)
		cout << "+";
	cout << mInfo.attackDamage << endl;
	cout << "��  ��: " << mInfo.gold << endl;
	cout << "################################" << endl;
}

void Item::SaveData(FILE *fp)
{
	// ������ ���������� ����ǰ�, ���� �����͸� �Ѱܹ��� ����

	fwrite(&mInfo, sizeof(Info), 1, fp);

	fwrite(&mItemType, sizeof(ITEM), 1, fp);

	fwrite(&mItemState, sizeof(ITEM_STATE), 1, fp);

}

void Item::LoadData(FILE *fp)
{
	fread(&mInfo, sizeof(Info), 1, fp);

	fread(&mItemType, sizeof(ITEM), 1, fp);

	fread(&mItemState, sizeof(ITEM_STATE), 1, fp);
}
