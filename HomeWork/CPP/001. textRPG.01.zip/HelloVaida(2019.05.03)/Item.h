#pragma once
#ifndef _ITEM_H_
#define _ITEM_H_

#include "Obj.h"

class Item : public Obj
{
public:
	Item();
	Item(const Info &ref);
	virtual ~Item();

public:
	virtual void Init(void);
	virtual void Progress(void);
	virtual void Release(void);

public:
	virtual void ShowStatus(void);

	virtual void SaveData(FILE *fp);
	virtual void LoadData(FILE *fp);

public:
	void setItemType(ITEM type) { mItemType = type; }
	void setItemState(ITEM_STATE state) { mItemState = state; }

public:
	const char* getClassName(void) { return mInfo.className; }
	const ITEM getItemType(void) { return mItemType; }
	const ITEM_STATE getItemState(void) { return mItemState; }

private:
	ITEM mItemType;
	ITEM_STATE mItemState;

};

#endif