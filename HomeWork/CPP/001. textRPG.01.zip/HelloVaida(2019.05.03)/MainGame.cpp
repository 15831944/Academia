#include "stdafx.h"
#include "Player.h"
#include "Dungeon.h"
#include "Store.h"
#include "MainGame.h"



MainGame::MainGame()
	: mpPlayer(nullptr), mpDungeon(nullptr), mpStore(nullptr)
{
}


MainGame::~MainGame()
{
	Release();
}

bool MainGame::Init(void)
{
	ShowTitleMenu();

	if (mpPlayer == nullptr)
	{
		return FALSE;
	}

	mpDungeon = new Dungeon;
	if (mpDungeon == nullptr)
	{
		return FALSE;
	}
	mpDungeon->Init();
	mpDungeon->setPPlayer(mpPlayer);

	mpStore = new Store;
	if (mpStore == nullptr)
	{
		return FALSE;
	}
	mpStore->Init();
	mpStore->setPPlayer(mpPlayer);


	return TRUE;
}

void MainGame::Progress(void)
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		cout << "1. ����, 2. ����, 3. �κ��丮, 4. ����, 5. ����" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			mpDungeon->Progress();
			break;
		case 2:
			mpStore->Progress();
			break;
		case 3:
			dynamic_cast<Player *>(mpPlayer)->OpenInventory();
			break;
		case 4:
			SaveData();
			continue;

		case 5:
			cout << "������ �����մϴ�." << endl << endl;
			return;

		default:
			continue;
		}
	}



}

void MainGame::Release(void)
{
	SAFE_DELETE(mpStore);
	SAFE_DELETE(mpDungeon);
	SAFE_DELETE(mpPlayer);
}

void MainGame::ShowTitleMenu(void)
{
	int sel = 0;

	while (mpPlayer == nullptr)
	{
		system("cls");
		cout << "1. �����ϱ�, 2. �ҷ�����" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			SelectClass();
			break;
		case 2:
			LoadData();
			break;

		default:
			continue;
		}
	}
}

void MainGame::SelectClass(void)
{
	int sel = 0;

	while (mpPlayer == nullptr)
	{
		system("cls");
		cout << "1. ����, 2. ������, 3. ����" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case CLASS::WARRIOR:
			mpPlayer = new Player(Info("����", 150, 10));
			break;
		case CLASS::WIZARD:
			mpPlayer = new Player(Info("������", 100, 20));
			break;
		case CLASS::THIEF:
			mpPlayer = new Player(Info("����", 125, 15));
			break;

		default:

			continue;
		}

	}
}

void MainGame::SaveData(void)
{
	FILE *fp = nullptr;
	errno_t err = fopen_s(&fp, "./hello.txt", "wb");

	if (err == 0)
	{
		cout << "�����͸� �����մϴ�." << endl;

		fwrite(&(mpPlayer->getInfo()), sizeof(Info), 1, fp);

		mpPlayer->SaveData(fp);

		fclose(fp);
	}
	else
	{
		cout << "���� ���� ����" << endl;
	}
	system("pause");
}

void MainGame::LoadData(void)
{
	FILE *fp = nullptr;
	errno_t err = fopen_s(&fp, "./hello.txt", "rb");

	if (err == 0)
	{
		cout << "�����͸� �ҷ��ɴϴ�." << endl;
	
		SAFE_DELETE(mpPlayer);

		Info temp;
		fread(&temp, sizeof(Info), 1, fp);

		mpPlayer = new Player(temp);
		if (mpPlayer == nullptr)
		{
			cout << "�ҷ����� ����" << endl;
			system("pause");
			return;
		}

		mpPlayer->LoadData(fp);

		fclose(fp);
	}
	else
	{
		cout << "���� ���� ����" << endl;
	}
	system("pause");
}
