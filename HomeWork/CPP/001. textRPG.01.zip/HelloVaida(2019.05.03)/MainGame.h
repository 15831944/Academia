#pragma once
#ifndef _MAIN_GAME_H_
#define _MAIN_GAME_H_

class Obj;
class Dungeon;
class Store;

class MainGame
{
public:
	MainGame();
	~MainGame();

public:
	bool Init(void);
	void Progress(void);
	void Release(void);

public:
	void ShowTitleMenu(void);

	void SelectClass(void);

	void SaveData(void);
	void LoadData(void);

private:
	Obj *mpPlayer;
	Dungeon *mpDungeon;
	Store *mpStore;
};

#endif

