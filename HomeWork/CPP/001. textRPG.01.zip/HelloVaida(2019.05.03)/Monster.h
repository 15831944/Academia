#pragma once
#ifndef _MONSTER_H_
#define _MONSTER_H_

#include "Obj.h"

class Monster : public Obj
{
public:
	Monster();
	Monster(const Info &ref);
	virtual ~Monster();


public:
	virtual void Init(void);
	virtual void Progress(void);
	virtual void Release(void);

public:
	virtual void ShowStatus(void);


public:


};

#endif
