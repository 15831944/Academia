#include "stdafx.h"
#include "Obj.h"



Obj::Obj()
{
}

Obj::Obj(const Info &ref)
	: mInfo(ref)
{
}


Obj::~Obj()
{
	Release();
}

void Obj::Progress(void)
{
}

void Obj::Release(void)
{
	//cout << "Obj::Release()" << endl;
	//system("pause");
}

void Obj::SaveData(FILE *fp)
{

}

void Obj::LoadData(FILE *fp)
{

}
