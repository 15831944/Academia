#pragma once
#ifndef _OBJ_H_
#define _OBJ_H_

class Obj
{
public:
	Obj();
	Obj(const Info &ref);
	virtual ~Obj();

public:
	virtual void Init(void) = 0;
	virtual void Progress(void);
	virtual void Release(void);

public:
	virtual void ShowStatus(void) = 0;

	void GetDamaged(int attackDamage) { mInfo.hp -= attackDamage; }

	virtual void SaveData(FILE *fp);
	virtual void LoadData(FILE *fp);

public:
	const int getHp(void) const { return mInfo.hp; }
	//const int getMaxHp(void) const { return mInfo.maxHp; }
	const int getAttackDamage(void) const { return mInfo.attackDamage; }
	const int getExp(void) const { return mInfo.exp; }
	const int getGold(void) const { return mInfo.gold; }

	const Info& getInfo(void) const { return mInfo; }

public:
	void setHp(const int hp) { mInfo.hp = hp; }
	//void setExp(const int exp) { mInfo.exp = exp; }
	//void setGold(const int gold) { mInfo.gold = gold; }


protected:
	Info mInfo;
};

#endif
