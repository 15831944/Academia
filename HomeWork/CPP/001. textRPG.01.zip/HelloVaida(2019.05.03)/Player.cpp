#include "stdafx.h"
#include "Item.h"
#include "Inventory.h"
#include "Player.h"



Player::Player()
{
}

Player::Player(const Info &ref)
	: Obj(ref)
{
	Init();
}


Player::~Player()
{
	Release();
}

void Player::Init(void)
{
	mpInventory = new Inventory;
	mpInventory->setPPlyaer(this);
	memset(mEquippedItem, 0, sizeof(mEquippedItem));
}

void Player::Progress(void)
{
}

void Player::Release(void)
{
	//cout << "Player::Release()" << endl;
	//system("pause");

	SAFE_DELETE(mpInventory);
}

void Player::ShowStatus(void)
{
	cout << "��  ��: " << mInfo.level << endl;
	//cout << "( " << mInfo.exp << "/ " << mInfo.maxExp << " )" << endl;
	cout << "Ŭ����: " << mInfo.className << endl;
	cout << "ü  ��: " << mInfo.hp << "/ " << mInfo.maxHp << endl;
	cout << "���ݷ�: " << mInfo.attackDamage << endl;
	cout << "����ġ: " << mInfo.exp << "/ " << mInfo.maxExp << endl;
	cout << "��  ��: " << mInfo.gold << endl;
	cout << "################################" << endl;

	ShowEquippedItem();
}

void Player::GetReward(const int exp, const int gold)
{
	mInfo.exp += exp;

	if (mInfo.exp >= mInfo.maxExp)
	{
		mInfo.exp -= mInfo.maxExp;

		++mInfo.level;

		if (!strcmp(mInfo.className, "����"))
		{
			mInfo.maxHp += 20;
			mInfo.attackDamage += 10;
		}
		else if (!strcmp(mInfo.className, "������"))
		{
			mInfo.maxHp += 10;
			mInfo.attackDamage += 20;
		}
		else if (!strcmp(mInfo.className, "����"))
		{
			mInfo.maxHp += 15;
			mInfo.attackDamage += 15;
		}

		mInfo.hp = mInfo.maxHp;
	}

	mInfo.gold += gold;

}

void Player::OpenInventory(void)
{
	int sel = 0;

	if (mpInventory->isInventoryEmpty())
	{
		cout << "�κ��丮�� ����ֽ��ϴ�." << endl;
		system("pause");
	}
	else 
	{
		while (TRUE)
		{
			system("cls");
			ShowStatus();
			mpInventory->ShowInventory();
			cout << "1. ����, 2. ����, 3. ������" << endl;
			cout << "�Է�: ";
			cin >> sel;

			switch (sel)
			{
			case 1:
				mpInventory->EquipItem();
				break;
			case 2:
				mpInventory->UnEquipItem();
				break;

			case 3:

				return;

			default:
				continue;
			}
		}
	}
}

void Player::ShowInventory(void)
{
	mpInventory->ShowInventory();
}

void Player::ShowEquippedItem(void)
{
	cout << "########  Euipped Item  ########" << endl;
	for (int i = 0; i < ITEM_END; ++i)
	{
		if (mEquippedItem[i])
		{
			Item *temp = dynamic_cast<Item *>(mEquippedItem[i]);
			cout << i + 1 << ") " << temp->getClassName() << endl;
		}
	}
	cout << "################################" << endl;
}

bool Player::PurchaseItem(Obj *pItem)
{
	if (mInfo.gold >= pItem->getGold() &&
		mpInventory->PushItem(pItem))
	{
		mInfo.gold -= pItem->getGold();
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

bool Player::SellItem(int index)
{
	int gold = mpInventory->PopItem(index);
	if (gold >= 0)
	{
		mInfo.gold += gold;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

void Player::EquipItem(Obj *pItem)
{
	Item *pTemp = dynamic_cast<Item *>(pItem);

	ITEM type = pTemp->getItemType();

	if (mEquippedItem[type]) // "nullptr"�� �ƴ� ��
	{
		dynamic_cast<Item *>(mEquippedItem[type])->setItemState(ITEM_STATE::UNEQUIP);
		RenewPlayerStatus(-mEquippedItem[type]->getHp() , -mEquippedItem[type]->getAttackDamage());
	}

	mEquippedItem[type] = pTemp;
	pTemp->setItemState(ITEM_STATE::EQUIP);
	RenewPlayerStatus(pTemp->getHp(), pTemp->getAttackDamage());
}

void Player::UnEquipItem(int index)
{
	if (index < 0 || index >= ITEM::ITEM_END || mEquippedItem[index] == nullptr)
	{
		cout << "�������� �ʴ� �������Դϴ�." << endl;
		system("pause");
		return;
	}

	if (mEquippedItem[index]) // "nullptr"�� �ƴ� ��
	{
		dynamic_cast<Item *>(mEquippedItem[index])->setItemState(ITEM_STATE::UNEQUIP);
		RenewPlayerStatus(-mEquippedItem[index]->getHp(), -mEquippedItem[index]->getAttackDamage());
	}

	mEquippedItem[index] = nullptr;

}

bool Player::isInventoryFull(void)
{
	return false;
}

void Player::RenewPlayerStatus(int hp, int attackDamage)
{
	mInfo.hp += hp;
	mInfo.maxHp += hp;
	mInfo.attackDamage += attackDamage;
}

void Player::SaveData(FILE *fp)
{
	mpInventory->SaveData(fp);
}

void Player::LoadData(FILE *fp)
{
	mpInventory->LoadData(fp);
}

void Player::setEquippedItem(Obj * pItem, int index)
{
	mEquippedItem[index] = pItem;
}
