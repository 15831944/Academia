#pragma once
#ifndef _PLYAER_H_
#define _PLYAER_H_

#include "Obj.h"

class Inventory;

class Player : public Obj
{
public:
	Player();
	Player(const Info &ref);
	virtual ~Player();


public:
	virtual void Init(void);
	virtual void Progress(void);
	virtual void Release(void);

public:
	virtual void ShowStatus(void);

	void GetReward(const int exp, const int gold);

	void OpenInventory(void);
	void ShowInventory(void);

	void ShowEquippedItem(void);

	bool PurchaseItem(Obj *pItem);
	bool SellItem(int index);

	void EquipItem(Obj *pItem);
	void UnEquipItem(int index);

	bool isInventoryFull(void);

	void RenewPlayerStatus(int hp, int attackDamage);

	virtual void SaveData(FILE *fp);
	virtual void LoadData(FILE *fp);

public:
	const int getMaxHp(void) const { return mInfo.maxHp; }

public:
	void setExp(const int exp) { mInfo.exp = exp; }
	void setGold(const int gold) { mInfo.gold = gold; }

	void setEquippedItem(Obj *pItem, int index);

private:
	Inventory *mpInventory;
	Obj *mEquippedItem[ITEM_END];
};

#endif
