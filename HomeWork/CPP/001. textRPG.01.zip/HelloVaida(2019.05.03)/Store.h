#pragma once
#ifndef _STORE_H_
#define _STORE_H_

class Obj;

class Store
{
public:
	Store();
	~Store();

public:
	void Init(void);
	void Progress(void);
	void Release(void);

public:
	void GoIntoTheStore(int storeLevel);
	void ShowStore(int storeLevel);

	void PurchaseItemProg(Obj *item);
	void SellItemProg(void);

public:
	void setPPlayer(Obj *pPlayer) { mpPlayer = pPlayer; }

private:
	Obj *mpPlayer;
	Obj *itemArr[LEVEL::LEVEL_END][ITEM::ITEM_END];
};

#endif
