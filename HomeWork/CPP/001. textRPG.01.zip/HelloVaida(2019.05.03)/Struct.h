#pragma once
#ifndef _STRUCT_H_
#define _STRUCT_H_

#include "stdafx.h"

typedef struct InfoType
{
	InfoType() {}

	InfoType(char *name, int maxHp, int attackDamage)
		: level(1), hp(maxHp), maxHp(maxHp),
		attackDamage(attackDamage), exp(0), maxExp(100),
		gold(50000)
	{
		strcpy_s(className, NAME_LEN, name);
	}

	InfoType(char *name, int level, int maxHp, int attackDamage)
		: level(level), hp(maxHp), maxHp(maxHp),
		attackDamage(attackDamage), exp(0), maxExp(0),
		gold(0)
	{
		strcpy_s(className, NAME_LEN, name);
	}

	InfoType(char *name, int level, int maxHp, int attackDamage, int gold)
		: level(level), hp(maxHp), maxHp(maxHp),
		attackDamage(attackDamage), exp(0), maxExp(0),
		gold(gold)
	{
		strcpy_s(className, NAME_LEN, name);
	}

	InfoType(const InfoType &ref)
		: level(ref.level), hp(ref.hp), maxHp(ref.maxHp),
		attackDamage(ref.attackDamage), exp(ref.exp), maxExp(ref.maxExp),
		gold(ref.gold)
	{
		strcpy_s(className, NAME_LEN, ref.className);
	}


public:
	char className[NAME_LEN];
	int level;
	int hp;
	int maxHp;
	int attackDamage;
	int exp;
	int maxExp;
	int gold;

} Info;

#endif