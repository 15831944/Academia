#include "stdafx.h"
#include "Player.h"
#include "Monster.h"
#include "Dungeon.h"

Dungeon::Dungeon()
	: mpPlayer(nullptr), mpMonster(nullptr), mState(AGAIN)
{
	Init();
}

Dungeon::~Dungeon()
{
	Release();
}

void Dungeon::Init(void)
{
}

void Dungeon::Progress(void)
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		cout << "1.�ʱ�, 2.�߱�, 3.����, 4.������" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			mpMonster = new Monster(Info("������1", 1, 30, 10));
			break;
		case 2:
			mpMonster = new Monster(Info("������2", 3, 300, 100));
			break;
		case 3:
			mpMonster = new Monster(Info("������3", 5, 3000, 1000));
			break;

		case 4:
			return;

		default:
			continue;
		}

		if (mpMonster == nullptr)
			continue;

		GoIntoTheDungeon();

		switch (mState)
		{
		case RUN:
			mpPlayer->setGold(0);
			break;
		case HUNT:
			dynamic_cast<Player *>(mpPlayer)->GetReward(mpMonster->getExp(), mpMonster->getGold());
			break;
		case DIE:
			mpPlayer->setExp(0);
			mpPlayer->setHp(mpPlayer->getMaxHp());
			break;
		}

		Release();
	}
}

void Dungeon::Release(void)
{
	SAFE_DELETE_PTR(mpMonster);
}

void Dungeon::GoIntoTheDungeon(void)
{
	int sel = 0;

	mState = AGAIN;
	while (mState == AGAIN)
	{
		system("cls");
		mpPlayer->ShowStatus();
		mpMonster->ShowStatus();
		cout << "1.����, 2.����" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			mState = AttackMonster();
			break;
		case 2:
			mState = RUN;
			break;

		default:
			continue;
		}


	}
}

BATTLE_STATE Dungeon::AttackMonster()
{
	system("cls");

	mpPlayer->GetDamaged(mpMonster->getAttackDamage());
	mpMonster->GetDamaged(mpPlayer->getAttackDamage());

	if (mpPlayer->getHp() <= 0)
	{
		mpPlayer->setHp(0);
		if (mpMonster->getHp() <= 0)
		{
			mpMonster->setHp(0);
		}

		mpPlayer->ShowStatus();
		mpMonster->ShowStatus();
		if (mpMonster->getHp() <= 0)
		{
			cout << "�ƽ��Ե�.." << endl;
		}
		cout << "[��ɽ���]" << endl;

		system("pause");

		return DIE;

	}
	else if (mpMonster->getHp() <= 0)
	{
		mpMonster->setHp(0);
		mpPlayer->ShowStatus();
		mpMonster->ShowStatus();

		cout << "[��ɼ���]" << endl;

		system("pause");

		return HUNT;

	}

	return AGAIN;
}
