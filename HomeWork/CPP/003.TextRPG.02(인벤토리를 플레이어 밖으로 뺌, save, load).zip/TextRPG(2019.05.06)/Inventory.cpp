#include "stdafx.h"
#include "Item.h"
#include "Player.h"
#include "Inventory.h"



Inventory::Inventory()
	: mpPlayer(nullptr), mMaxSize(5)
{
	Init();
}


Inventory::~Inventory()
{
	Release();
}

void Inventory::Init(void)
{
	mVecItem.reserve(mMaxSize);
}

void Inventory::Progress(void)
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		ShowInventory();
		cout << "1.����, 2.����, 3.������" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			EquipItem();
			break;
		case 2:
			UnEquipItem();
			break;

		case 3:
			return;

		default:
			continue;
		}
	}
}

void Inventory::Release(void)
{
	size_t size = mVecItem.size();
	for (size_t i = 0; i < size; ++i)
	{
		SAFE_DELETE_PTR(mVecItem[i]);
	}
	mVecItem.clear();
}

void Inventory::ShowInventory()
{
	if (mVecItem.empty())
	{
		cout << "�κ��丮�� ����ֽ��ϴ�." << endl;
	}
	else
	{
		cout << "############# �κ��丮 #############" << endl;
		for (size_t i = 0; i < mVecItem.size(); ++i)
		{
			cout << i + 1 << ") ";
			mVecItem[i]->ShowStatus();
		}
	}
}

void Inventory::EquipItem()
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		ShowInventory();
		cout << "0) ������" << endl;
		cout << "�Է�: ";
		cin >> sel;
		--sel;

		if (sel < 0)
			return;
		else if (static_cast<size_t>(sel) >= mVecItem.size())
		{
			cout << "���� ���� �ʴ� ������ �Դϴ�." << endl;
			system("pause");
			continue;
		}

		dynamic_cast<Player *>(mpPlayer)->EquipItem(mVecItem[sel]);
	}

}

void Inventory::UnEquipItem()
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		cout << "0) ������" << endl;
		cout << "�Է�: ";
		cin >> sel;
		--sel;

		if (sel < 0)
			return;
	
		dynamic_cast<Player *>(mpPlayer)->UnEquipItem(sel);
	}

}

bool Inventory::PurchaseItem(Obj * pItem)
{
	if (mVecItem.size() >= mMaxSize)
	{
		cout << "�κ��丮�� �� á���ϴ�." << endl;
		return FALSE;
	}
	else
	{
		Item *pTemp = dynamic_cast<Item *>(pItem);
		Obj *pCopy = new Item(*pTemp);
		mVecItem.push_back(pCopy);

		return TRUE;
	}


}

const int Inventory::SellItem(size_t index)
{
	if (mVecItem.empty())
	{
		return -1;
	}
	else if (index >= mVecItem.size())
	{
		cout << "�������� �ʴ� �������Դϴ�." << endl;
		return -1;
	}
	else if (dynamic_cast<Item *>(mVecItem[index])->getState() == EQUIP)
	{
		cout << "���� ���� �������Դϴ�." << endl;
		return -1;
	}
	else
	{
		vector<Obj *>::iterator iter = mVecItem.begin();
		iter += index;

		int gold = (*iter)->getGold();

		SAFE_DELETE_PTR(*iter);

		mVecItem.erase(iter);

		return gold;
	}

}


void Inventory::PushItem(Obj * pItem)
{
	mVecItem.push_back(pItem);
}
