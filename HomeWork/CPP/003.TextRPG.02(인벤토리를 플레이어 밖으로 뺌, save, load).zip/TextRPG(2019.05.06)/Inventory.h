#pragma once
#ifndef _INVEN_H_
#define _INVEN_H_

class Obj;

class Inventory
{
public:
	Inventory();
	~Inventory();

public:
	void Init(void);
	void Progress(void);
	void Release(void);

public:
	void ShowInventory();

	void EquipItem();
	void UnEquipItem();

	bool PurchaseItem(Obj *pItem);
	const int SellItem(size_t index);

	void PushItem(Obj *pItem);

public:
	const Obj* GetItem(size_t index) const { return mVecItem[index]; }
	const size_t GetCurSize() const { return mVecItem.size(); }

public:
	void setPPlayer(Obj *pPlayer) { mpPlayer = pPlayer; }


private:
	Obj *mpPlayer;
	size_t mMaxSize;
	vector<Obj *> mVecItem;
};



#endif