#include "stdafx.h"
#include "Item.h"

Item::Item()
{
}

Item::Item(const Info & ref, ITEM type)
	: Obj(ref), mType(type), mState(UNEQUIP)
{
}

Item::~Item()
{
}

void Item::Init(void)
{
}

void Item::ShowStatus(void)
{
	cout << "����: " << mInfo.level << "/ ";
	cout << "�̸�: " << mInfo.className << "/ ";
	cout << "ü��: ";
	if (mInfo.hp > 0)
		cout << "+";
	cout << mInfo.hp << "/ ";
	cout << "���ݷ�: ";
	if (mInfo.attackDamage > 0)
		cout << "+";
	cout << mInfo.attackDamage << "/ ";
	cout << "���: " << mInfo.gold;
	if (mState == EQUIP)
		cout << "/ <<< ������ >>>";
	cout << endl;
	cout << "###################################" << endl;
}
