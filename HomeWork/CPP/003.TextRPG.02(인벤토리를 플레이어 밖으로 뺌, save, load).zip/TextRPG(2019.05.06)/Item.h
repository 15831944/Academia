#pragma once
#ifndef _ITEM_H_
#define _ITEM_H_

#include "Obj.h"

class Item : public Obj
{
public:
	Item();
	Item(const Info &ref, ITEM type);
	virtual ~Item();

public:
	virtual void Init(void);

public:
	virtual void ShowStatus(void);

public:
	const ITEM& getType() const { return mType; }
	const ITEM_STATE& getState() const { return mState; }

public:
	void setType(ITEM type) { mType = type; }
	void setState(ITEM_STATE state) { mState = state; }

private:
	ITEM mType;
	ITEM_STATE mState;
};

#endif