#include "stdafx.h"
#include "Player.h"
#include "Dungeon.h"
#include "Store.h"
#include "Item.h"
#include "Inventory.h"
#include "MainGame.h"



MainGame::MainGame()
	: mpPlayer(nullptr), mpDungeon(nullptr),
	mpStore(nullptr), mpInven(nullptr)
{
}


MainGame::~MainGame()
{
	Release();
}

bool MainGame::Init(void)
{
	TITLE menu = TitleMenuProg();
	if (menu == NEW)
	{
		SelectClass();
	}
	else if (menu == LOAD)
	{
		LoadData();
	}
	else
	{
		return FALSE;
	}

	if (mpPlayer == nullptr)
	{
		return FALSE;
	}


	if (mpInven == nullptr)
	{
		mpInven = new Inventory;
		if (mpInven == nullptr)
		{
			return FALSE;
		}
		mpInven->setPPlayer(mpPlayer);
	}

	if (mpStore == nullptr)
	{
		mpStore = new Store;
		if (mpStore == nullptr)
		{
			return FALSE;
		}
		mpStore->Init();
		mpStore->setPPlayer(mpPlayer);
		mpStore->setPInven(mpInven);
	}

	if (mpDungeon == nullptr)
	{
		mpDungeon = new Dungeon;
		if (mpDungeon == nullptr)
		{
			return FALSE;
		}
		mpDungeon->setPPlayer(mpPlayer);
	}


	return TRUE;
}

void MainGame::Progress(void)
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		cout << "1.����, 2.����, 3.�κ��丮, 4.����, 5.��������" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			mpDungeon->Progress();
			break;
		case 2:
			mpStore->Progress();
			break;
		case 3:
			mpInven->Progress();
			break;

		case 4:
			SaveData();
			continue;

		case 5:
			return;

		default:
			continue;
		}
	}
}

void MainGame::Release(void)
{
	SAFE_DELETE_PTR(mpDungeon);
	SAFE_DELETE_PTR(mpStore);
	SAFE_DELETE_PTR(mpInven);
	SAFE_DELETE_PTR(mpPlayer);
}

TITLE MainGame::TitleMenuProg(void)
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		cout << "1.���ν���, 2.�ҷ�����, 3.����" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			return NEW;
		case 2:
			return LOAD;
		case 3:
			return EXIT;

		default:
			continue;
		}
	}
}

void MainGame::SelectClass()
{
	int sel = 0;

	while (mpPlayer == nullptr)
	{
		system("cls");
		cout << "1.����, 2.������, 3.����, 4.����" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			mpPlayer = new Player(Info("����", 150, 10));
			break;
		case 2:
			mpPlayer = new Player(Info("����", 150, 10));
			break;
		case 3:
			mpPlayer = new Player(Info("����", 150, 10));
			break;

		case 4:
			return;

		default:
			continue;

		}
	}
}

void MainGame::SaveData()
{
	FILE *fp = nullptr;
	errno_t err = fopen_s(&fp, "./hello.txt", "wb");

	if (err == 0)
	{
		cout << "���� ���� ����" << endl;

		fwrite(&(mpPlayer->getInfo()), sizeof(Info), 1, fp);

		size_t curSize = mpInven->GetCurSize();
		fwrite(&curSize, sizeof(size_t), 1, fp);

		const Item *temp = nullptr;
		for (size_t i = 0; i < curSize; ++i)
		{
			temp = dynamic_cast<const Item *>(mpInven->GetItem(i));
			fwrite(&(temp->getInfo()), sizeof(Info), 1, fp);
			fwrite(&(temp->getType()), sizeof(ITEM), 1, fp);
			fwrite(&(temp->getState()), sizeof(ITEM_STATE), 1, fp);
		}

		fclose(fp);
	}
	else
	{
		cout << "���� ���� ����" << endl;
	}
	system("pause");

}

void MainGame::LoadData()
{
	FILE *fp = nullptr;
	errno_t err = fopen_s(&fp, "./hello.txt", "rb");

	if (err == 0)
	{
		cout << "���� ���� ����" << endl;

		Info temp;
		fread(&temp, sizeof(Info), 1, fp);
		mpPlayer = new Player(temp);

		size_t curSize = 0;
		fread(&curSize, sizeof(size_t), 1, fp);

		mpInven = new Inventory;
		mpInven->setPPlayer(mpPlayer);

		
		Item *pTemp = nullptr;
		for (size_t i = 0; i < curSize; ++i)
		{
			Info tempInfo;
			ITEM type;
			ITEM_STATE state;

			fread(&tempInfo, sizeof(Info), 1, fp);
			fread(&type, sizeof(ITEM), 1, fp);
			fread(&state, sizeof(ITEM_STATE), 1, fp);

			pTemp = new Item(tempInfo, type);
			if (state == EQUIP)
			{
				pTemp->setState(EQUIP);
				dynamic_cast<Player *>(mpPlayer)->SetEquippedItem(type, pTemp);
			}

			mpInven->PushItem(pTemp);
		}

		fclose(fp);
	}
	else
	{
		cout << "���� ���� ����" << endl;
	}
	system("pause");

}
