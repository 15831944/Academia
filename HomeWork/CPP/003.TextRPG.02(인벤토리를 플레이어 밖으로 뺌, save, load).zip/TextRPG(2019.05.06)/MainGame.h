#pragma once
#ifndef _MAIN_H_
#define _MAIN_H_

class Obj;
class Dungeon;
class Store;
class Inventory;

class MainGame
{
public:
	MainGame();
	~MainGame();

public:
	bool Init(void);
	void Progress(void);
	void Release(void);

public:
	TITLE TitleMenuProg(void);

	void SelectClass();

	void SaveData();
	void LoadData();


private:
	Obj *mpPlayer;
	Dungeon *mpDungeon;
	Store *mpStore;
	Inventory *mpInven;
};

#endif