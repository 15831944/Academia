#include "stdafx.h"
#include "Monster.h"

Monster::Monster()
{
}

Monster::Monster(const Info & ref)
	: Obj(ref)
{
	Init();
}

Monster::~Monster()
{

}

void Monster::Init(void)
{
	mInfo.exp = ((rand() % 50) + 1) + 30;
	mInfo.gold = ((rand() % 100) + 1) + 30;
}

void Monster::ShowStatus(void)
{
	cout << "����: " << mInfo.level << endl;
	cout << "Ŭ����: " << mInfo.className << endl;
	cout << "ü��: " << mInfo.hp << "/ " << mInfo.maxHp << endl;
	cout << "���ݷ�: " << mInfo.attackDamage << endl;
	cout << "###################################" << endl;
}
