#pragma once
#ifndef _MONSTER_H_
#define _MONSTER_H_

#include "Obj.h"

class Monster : public Obj
{
public:
	Monster();
	Monster(const Info &ref);
	virtual ~Monster();

public:
	virtual void Init(void);

public:
	virtual void ShowStatus(void);
};

#endif