#include "stdafx.h"
#include "Obj.h"

Obj::Obj()
{
}

Obj::Obj(const Info & ref)
	: mInfo(ref)
{
}

Obj::~Obj()
{

}