#pragma once
#ifndef _OBJ_H_
#define _OBJ_H_

class Obj
{
public:
	Obj();
	Obj(const Info &ref);
	virtual ~Obj();

public:
	virtual void Init(void) = 0;

public:
	virtual void ShowStatus(void) = 0;

	void GetDamaged(int damage) { mInfo.hp -= damage; }

public:
	const char* getClassName() const { return mInfo.className; }
	const int getHp() const { return mInfo.hp; }
	const int getMaxHp() const{ return mInfo.maxHp; }
	const int getAttackDamage() const { return mInfo.attackDamage; }
	const int getExp() const { return mInfo.exp; }
	const int getGold() const { return mInfo.gold; }
	const Info& getInfo() const { return mInfo; }

public:
	void setHp(int hp) { mInfo.hp = hp; }
	void setExp(int exp) { mInfo.exp = exp; }
	void setGold(int gold) { mInfo.gold = gold; }

protected:
	Info mInfo;
};

#endif