#include "stdafx.h"
#include "Item.h"
#include "Player.h"

Player::Player()
{
}

Player::Player(const Info & ref)
	: Obj(ref)
{
	Init();
}

Player::~Player()
{
}

void Player::Init(void)
{
	memset(mEquip, 0, sizeof(mEquip));
}

void Player::ShowStatus(void)
{
	cout << "����: " << mInfo.level << endl;
	cout << "Ŭ����: " << mInfo.className << endl;
	cout << "ü��: " << mInfo.hp << "/ " << mInfo.maxHp << endl;
	cout << "���ݷ�: " << mInfo.attackDamage << endl;
	cout << "����ġ: " << mInfo.exp << "/ " << mInfo.maxExp << endl;
	cout << "���: " << mInfo.gold << endl;
	cout << "###################################" << endl;

	ShowEquippedItem();
}

void Player::ShowEquippedItem(void)
{
	for (int i = 0; i < ITEM_END; ++i)
	{
		if (mEquip[i])
		{
			cout << i + 1 << ") " << mEquip[i]->getClassName() << endl;
		}
	}
	cout << "###################################" << endl;

}

void Player::GetReward(int exp, int gold)
{
	mInfo.exp += exp;

	if (mInfo.exp >= mInfo.maxExp)
	{
		mInfo.exp -= mInfo.maxExp;
		mInfo.maxExp <<= 1;

		++mInfo.level;

		if (!strcmp(mInfo.className, "����"))
		{
			mInfo.attackDamage += 10;
			mInfo.maxHp += 10;
		}
		else if (!strcmp(mInfo.className, "������"))
		{
			mInfo.attackDamage += 10;
			mInfo.maxHp += 10;
		}
		else if (!strcmp(mInfo.className, "����"))
		{
			mInfo.attackDamage += 10;
			mInfo.maxHp += 10;
		}

		mInfo.hp = mInfo.maxHp;
	}

	mInfo.gold += gold;
}

void Player::EquipItem(Obj * pItem)
{
	Item *pTemp = dynamic_cast<Item *>(pItem);
	ITEM type = pTemp->getType();

	if (mEquip[type])
	{
		dynamic_cast<Item *>(mEquip[type])->setState(UNEQUIP);
		RenewStatus(-mEquip[type]->getHp(), -mEquip[type]->getAttackDamage());
	}

	mEquip[type] = pTemp;
	pTemp->setState(EQUIP);
	RenewStatus(mEquip[type]->getHp(), mEquip[type]->getAttackDamage());

}

void Player::UnEquipItem(int index)
{
	if (index < 0 || index >= ITEM_END)
	{
		return;
	}
	else if (mEquip[index])
	{
		dynamic_cast<Item *>(mEquip[index])->setState(UNEQUIP);
		RenewStatus(-mEquip[index]->getHp(), -mEquip[index]->getAttackDamage());

		mEquip[index] = nullptr;
	}
}

void Player::RenewStatus(int hp, int damage)
{
	mInfo.hp += hp;
	mInfo.maxHp += hp;
	mInfo.attackDamage += damage;
}

void Player::SetEquippedItem(int index, Obj * pItem)
{
	mEquip[index] = pItem;
}
