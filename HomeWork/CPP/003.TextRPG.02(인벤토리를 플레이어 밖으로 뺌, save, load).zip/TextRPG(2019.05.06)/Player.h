#pragma once
#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "Obj.h"

class Player : public Obj
{
public:
	Player();
	Player(const Info &ref);
	virtual ~Player();

public:
	virtual void Init(void);

public:
	virtual void ShowStatus(void);

	void ShowEquippedItem(void);

	void GetReward(int exp, int gold);

	void EquipItem(Obj *pItem);
	void UnEquipItem(int index);

	void RenewStatus(int hp, int damage);

public:
	void SetEquippedItem(int index, Obj *pItem);

private:
	Obj *mEquip[ITEM_END];
};

#endif