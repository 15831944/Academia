#include "stdafx.h"
#include "Player.h"
#include "Inventory.h"
#include "Item.h"
#include "Store.h"

Store::Store()
	: mpPlayer(nullptr), mpInven(nullptr)
{
}

Store::~Store()
{
	Release();
}

void Store::Init(void)
{
	mItemArr[BEGINNER][ATT] = new Item(Info("�ʱް�", 1, 0, 10, 100), ATT); // �����Ҵ� ����ó��...
	mItemArr[BEGINNER][DEF] = new Item(Info("�ʱ޿�", 1, 10, 0, 100), DEF);

	mItemArr[ADVANCED][ATT] = new Item(Info("�߱ް�", 3, 0, 20, 200), ATT);
	mItemArr[ADVANCED][DEF] = new Item(Info("�߱޿�", 3, 20, 0, 200), DEF);

	mItemArr[EXPERT][ATT] = new Item(Info("���ް�", 5, 0, 30, 300), ATT);
	mItemArr[EXPERT][DEF] = new Item(Info("���޿�", 5, 30, 0, 300), DEF);
}

void Store::Progress(void)
{
	int sel = 0;

	while (TRUE)
	{
		mpPlayer->ShowStatus();
		mpInven->ShowInventory();
		ShowItemArr();
		cout << "1. ������ ����, 2. ������ �Ǹ�, 3. ������" << endl;
		cout << "�Է�: ";
		cin >> sel;

		switch (sel)
		{
		case 1:
			PurchaseItem();
			break;
		case 2:
			SellItem();
			break;

		case 3:
			return;

		default:
			continue;
		}
	}
}

void Store::Release(void)
{
	for (int i = 0; i < LEVEL_END; ++i)
	{
		for (int j = 0; j < ITEM_END; ++j)
		{
			SAFE_DELETE_PTR(mItemArr[i][j]);
		}
	}
}

void Store::ShowItemArr(void)
{
	cout << "############## ���� ##############" << endl;
	int count = 0;
	for (int i = 0; i < LEVEL_END; ++i)
	{
		for (int j = 0; j < ITEM_END; ++j)
		{
			cout << ++count << ") " << endl;
			mItemArr[i][j]->ShowStatus();
		}
	}
}

void Store::PurchaseItem(void)
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		mpInven->ShowInventory();
		ShowItemArr();
		cout << "0) ������" << endl;
		cout << "�Է�: ";
		cin >> sel;
		--sel;

		if (sel < 0)
			return;
		else if (sel >= LEVEL_END *ITEM_END)
		{
			cout << "�������� �ʴ� ������" << endl;
			system("pause");
			continue;
		}
		else
		{
			int level = sel / 2;
			int type = sel % 2;

			Obj *pItem = mItemArr[level][type];

			if (mpPlayer->getGold() >= pItem->getGold()
				&& mpInven->PurchaseItem(pItem))
			{
				cout << "������ ���� ����" << endl;

				mpPlayer->setGold(mpPlayer->getGold() - pItem->getGold());
			}
			else
			{
				cout << "������ ���� ����" << endl;
			}

			system("pause");
		}
		
	}
}

void Store::SellItem(void)
{
	int sel = 0;

	while (TRUE)
	{
		system("cls");
		mpPlayer->ShowStatus();
		mpInven->ShowInventory();
		cout << "0) ������" << endl;
		cout << "�Է�: ";
		cin >> sel;
		--sel;

		if (sel < 0)
			return;
		else
		{
			int gold = mpInven->SellItem(sel);
			if (gold >= 0)
			{
				cout << "������ �Ǹ� ����" << endl;

				mpPlayer->setGold(mpPlayer->getGold() + gold);
			}
			else
			{
				cout << "������ �Ǹ� ����" << endl;
			}

			system("pause");
		}

	}
}
