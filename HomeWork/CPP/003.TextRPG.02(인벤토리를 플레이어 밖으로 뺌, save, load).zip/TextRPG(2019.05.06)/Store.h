#pragma once
#ifndef _STORE_H_
#define _STORE_H_

class Obj;
class Inventory;

class Store
{
public:
	Store();
	~Store();

public:
	void Init(void);
	void Progress(void);
	void Release(void);

public:
	void ShowItemArr(void);

	void PurchaseItem(void);
	void SellItem(void);

public:
	void setPPlayer(Obj *pPlayer) { mpPlayer = pPlayer; }
	void setPInven(Inventory *pInven) { mpInven = pInven; }


private:
	Obj *mpPlayer;
	Inventory *mpInven;
	Obj *mItemArr[LEVEL_END][ITEM_END];
};



#endif