#pragma once
#ifndef _ABSTRACT_FACTORY_OBJ_H_
#define _ABSTRACT_FACTORY_OBJ_H_

class Obj;

template <typename T>
class AbstractFactoryObj
{
private:
	AbstractFactoryObj() {}
	~AbstractFactoryObj() {}

public:
	static Obj* Create()
	{
		Obj *pObj = new T;
		pObj->Init();

		return pObj;
	}

	static Obj* Create(float x, float y)
	{
		Obj *pObj = new T;
		pObj->Init();
		pObj->SetPosition(x, y);

		return pObj;
	}

	static Obj* Create(float x, float y, float angle)
	{
		Obj *pObj = new T;
		pObj->Init();
		pObj->SetPosition(x, y);
		pObj->setAngle(angle);

		return pObj;
	}
};


#endif