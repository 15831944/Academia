#pragma once
#ifndef _ENUM_H_
#define _ENUM_H_

namespace OBJ
{
	enum TYPE {
		BACKGROUND_FX,
		BOSS,
		MONSTER,
		MONSTER_WEAPON,
		PLAYER_WEAPON,
		MONSTER_FX,
		PLAYER,
		PLAYER_FX,
		END
	};
}

namespace KEYSET
{
	enum TYPE {
		LEFT,
		RIGHT,
		UP,
		DOWN,
		I,
		NUM1,
		NUM2,
		NUM3,
		NUM4,
		NUM5,
		NUM6,
		Z,
		X,
		C,
		V,
		END
	};
}

namespace SINGLETEXTURE
{
	enum KEY {
		//PLAYER,
		NIFLHEIM_ICE_BULLET,
		NIFLHEIM_ICE_PILLAR,
		END
	};
}

namespace MULTITEXTURE
{
	enum KEY {
		PLAYER,
		NIFLHEIM,
		NIFLHEIM_ICE_BULLET,
		NIFLHEIM_ICE_PILLAR,
		END
	};
}

namespace DIRECTION
{
	enum TYPE {
		LEFT,
		RIGHT,
		END
	};
}

#endif