#include "stdafx.h"

#include "IcePillar.h"

#include "MultiTexture.h"

#include "IceBullet.h"


IceBullet::IceBullet()
{
	ZeroMemory(&mvOrigin, sizeof(mvOrigin));
	ZeroMemory(&mvConvert, sizeof(mvConvert));
}


IceBullet::~IceBullet()
{
	Release();
}

void IceBullet::Init()
{
	mtInfo.vPos = { 0.0f, 0.0f, 0.0f };
	mtInfo.vDirOrigin = { 0.0f, -1.0f, 0.0f };
	mtInfo.vSize = { 3.0f, 3.0f, 0.0f };

	mvOrigin[0] = { -4.5f, -9.0f, 0.0f };
	mvOrigin[1] = { 4.5f, -9.0f, 0.0f };
	mvOrigin[2] = { 4.5f, 9.0f, 0.0f };
	mvOrigin[3] = { -4.5f, 9.0f, 0.0f };

	Obj::InitMatrixIdentity();

	mpMultiTexture = const_cast<MultiTexture *>(TextureManager::getInstance()->getMultiTexture(MULTITEXTURE::NIFLHEIM_ICE_BULLET, &std::wstring(L"IceBullet")));
	mwstrStateKey = L"IceBullet";

	dwMaintainTime = GetTickCount();
}

void IceBullet::LateInit()
{
	//mtInfo.vPos = mpIcePillar->getInfo().vPos;
	mAngle = mpIcePillar->getAngle();
}

int IceBullet::Update()
{
	Obj::LateInit();

	if (mbIsDead)
	{
		return OBJ_DEAD;
	}

	D3DXMatrixScaling(&mtInfo.matScale, mtInfo.vSize.x, mtInfo.vSize.x, mtInfo.vSize.y);
	D3DXMatrixRotationZ(&mtInfo.matRotZ, D3DXToRadian(-mAngle));
	D3DXMatrixTranslation(&mtInfo.matTrans, mtInfo.vPos.x, mtInfo.vPos.y, mtInfo.vPos.z);

	D3DXMATRIX matParent;
	D3DXMatrixIdentity(&matParent);
	matParent._41 = mpNiflheim->getInfo().vPos.x;// + mpIcePillar->getInfo().vPos.x;
	matParent._42 = mpNiflheim->getInfo().vPos.y;// + mpIcePillar->getInfo().vPos.y;
	matParent._43 = mpNiflheim->getInfo().vPos.z;// + mpIcePillar->getInfo().vPos.z;


	if (dynamic_cast<IcePillar *>(mpIcePillar)->getIsShield())
	{
		mtInfo.matWorld = mtInfo.matScale * mtInfo.matRotZ * mtInfo.matTrans * matParent;
	}
	else
	{
		mtInfo.matWorld = mtInfo.matScale * mtInfo.matRotZ * mtInfo.matTrans;
	}



	for (int i = 0; i < 4; ++i)
	{
		D3DXVec3TransformCoord(&mvConvert[i], &mvOrigin[i], &mtInfo.matWorld);
	}

	D3DXVec3TransformNormal(&mtInfo.vDir, &mtInfo.vDirOrigin, &mtInfo.matWorld);

	D3DXVec3Normalize(&mtInfo.vDir, &mtInfo.vDir);

	mtInfo.vPos += mtInfo.vDir * 10.0f;

	return OBJ_NOEVENT;
}

void IceBullet::LateUpdate()
{
	Obj::FrameMove();

	/*if (mtInfo.vPos.x < 100 || mtInfo.vPos.x > 1200
		|| mtInfo.vPos.y < 100 || mtInfo.vPos.y > 700)
	{
		mbIsDead = true;
	}*/

	if (dwMaintainTime + 1500 < GetTickCount())
	{
		mbIsDead = true;
		dwMaintainTime = GetTickCount();
	}
}

void IceBullet::Render(HDC hDC)
{
	const TEXTURE_INFO *pTextureInfo = mpMultiTexture->getTextureInfo(mwstrStateKey, mtFrame.frameStart);
	if (pTextureInfo == nullptr)
	{
		return;
	}

	float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

	DeviceManager::getInstance()->getSprite()->SetTransform(&mtInfo.matWorld);
	DeviceManager::getInstance()->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,
		&D3DXVECTOR3(centerX, centerY, 0.0f),
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);
}

void IceBullet::Release()
{
}
