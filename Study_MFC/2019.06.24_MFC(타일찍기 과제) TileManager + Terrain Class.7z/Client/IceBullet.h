#pragma once
#ifndef _ICE_BULLET_H_
#define _ICE_BULLET_H_

#include "Obj.h"

class MultiTexture;

class IceBullet : public Obj
{
public:
	IceBullet();
	virtual ~IceBullet();

public:
	// Obj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual void LateInit() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hDC) override;

private:
	virtual void Release() override;

public:
	void setNiflheim(Obj *pNiflheim) { mpNiflheim = pNiflheim; }
	void setIcePillar(Obj *pIcePillar) { mpIcePillar = pIcePillar; }

private:
	Obj *mpNiflheim;
	Obj *mpIcePillar;

	D3DXVECTOR3 mvOrigin[4];
	D3DXVECTOR3 mvConvert[4];

	DWORD dwMaintainTime;

	MultiTexture *mpMultiTexture;
};

#endif