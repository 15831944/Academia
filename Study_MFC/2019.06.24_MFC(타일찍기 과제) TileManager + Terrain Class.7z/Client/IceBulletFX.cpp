#include "stdafx.h"
#include "IceBulletFX.h"


IceBulletFX::IceBulletFX()
{
}


IceBulletFX::~IceBulletFX()
{
}
