#pragma once
#ifndef _ICE_BULLET_FX_H_
#define _ICE_BULLET_FX_H_

#include "Obj.h"

class IceBulletFX : public Obj
{
public:
	IceBulletFX();
	virtual ~IceBulletFX();
};

#endif