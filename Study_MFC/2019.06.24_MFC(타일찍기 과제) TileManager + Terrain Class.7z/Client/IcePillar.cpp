#include "stdafx.h"

#include "IceBullet.h"

#include "MultiTexture.h"

#include "ObjManager.h"

#include "AbstractFactoryObj.h"

#include "IcePillar.h"


IcePillar::IcePillar()
	: mpNiflheim(nullptr), mbIsShield(true),
	mpMultiTexture(nullptr),
	mIcePillarNum(0)
{
	ZeroMemory(&mvOrigin, sizeof(mvOrigin));
	ZeroMemory(&mvConvert, sizeof(mvConvert));
}


IcePillar::~IcePillar()
{
	Release();
}

void IcePillar::Init()
{
	mtInfo.vPos = { 0.0f, 0.0f, 0.0f };
	mtInfo.vDirOrigin = { 0.0f, -1.0f, 0.0f };
	mtInfo.vSize = { 3.0f, 3.0f, 0.0f };

	mvOrigin[0] = { -31.0f, -16.5f, 0.0f };
	mvOrigin[1] = { 31.0f, -16.5f, 0.0f };
	mvOrigin[2] = { 31.0f, 16.5f, 0.0f };
	mvOrigin[3] = { -31.0f, 16.5f, 0.0f };

	Obj::InitMatrixIdentity();

	D3DXMatrixIdentity(&matRevZ);
	mRevAngle = 0.0f;

	mpMultiTexture = const_cast<MultiTexture *>(TextureManager::getInstance()->getMultiTexture(MULTITEXTURE::NIFLHEIM_ICE_PILLAR, &std::wstring(L"IcePillar")));
	mwstrStateKey = L"IcePillar";
}

void IcePillar::LateInit()
{
	if (mIcePillarNum == 0)
	{
		mvPosOrigin = mtInfo.vPos;
	}
	else if (mIcePillarNum == 1)
	{
		mvPosOrigin = mtInfo.vPos;

	}
	else if (mIcePillarNum == 2)
	{
		mvPosOrigin = mtInfo.vPos;

	}
	else if (mIcePillarNum == 3)
	{
		mvPosOrigin = mtInfo.vPos;
	}
	mvPosOrigin = mtInfo.vPos;

}

int IcePillar::Update()
{
	Obj::LateInit();



	if (mbIsDead)
	{
		return OBJ_DEAD;
	}

	D3DXMatrixScaling(&mtInfo.matScale, mtInfo.vSize.x, mtInfo.vSize.y, mtInfo.vSize.z);
	D3DXMatrixRotationZ(&mtInfo.matRotZ, D3DXToRadian(-mAngle));

	/*D3DXMatrixTranslation(&mtInfo.matTrans,
		mpNiflheim->getInfo().vPos.x,
		mpNiflheim->getInfo().vPos.y,
		mpNiflheim->getInfo().vPos.z
	);*/

	D3DXMatrixTranslation(&mtInfo.matTrans,
		mtInfo.vPos.x,
		mtInfo.vPos.y,
		mtInfo.vPos.z
	);

	D3DXMatrixRotationZ(&matRevZ, D3DXToRadian(-mRevAngle));
	//D3DXMatrixRotationAxis(&matRevZ, &D3DXVECTOR3(0.0f, 0.0f, 1.0f), D3DXToRadian(-mRevAngle));
	/*matRevZ._41 = -mtInfo.vPos.x;
	matRevZ._42 = -mtInfo.vPos.y;
	matRevZ._43 = -mtInfo.vPos.z;*/

	D3DXMATRIX matParent;
	D3DXMatrixIdentity(&matParent);
	matParent._41 = mpNiflheim->getInfo().vPos.x;
	matParent._42 = mpNiflheim->getInfo().vPos.y;
	matParent._43 = mpNiflheim->getInfo().vPos.z;

	// #################################################################
	// ���߿� ���� ��� ���ϴ� �� �����ϱ�
	// #################################################################
	if (mbIsShield)
	{
		mtInfo.matWorld = mtInfo.matScale * mtInfo.matRotZ * mtInfo.matTrans * matRevZ * matParent;
	}
	else
	{
		mtInfo.matWorld = mtInfo.matScale * mtInfo.matRotZ * mtInfo.matTrans;
	}

	//D3DXVec3TransformCoord(&mtInfo.vPos, &mvPosOrigin, &mtInfo.matWorld);


	for (int i = 0; i < 4; ++i)
	{
		//D3DXVec3TransformCoord(&mvConvert[i], &mvOrigin[i], &mtInfo.matWorld);
		D3DXVec3TransformCoord(&mvConvert[i], &mvOrigin[i], &mtInfo.matWorld);
	}

	D3DXVec3TransformNormal(&mtInfo.vDir, &mtInfo.vDirOrigin, &mtInfo.matWorld);

	D3DXVec3Normalize(&mtInfo.vDir, &mtInfo.vDir);

	return OBJ_NOEVENT;
}

void IcePillar::LateUpdate()
{
	Obj::FrameMove();

	if (mAngle == -360.0f
		|| mAngle == 360.0f)
	{
		mAngle = 0.0f;
	}

	if (mRevAngle == -360.0f
		|| mRevAngle == 360.0f)
	{
		mRevAngle = 0.0f;
	}

}

void IcePillar::Render(HDC hDC)
{
	const TEXTURE_INFO *pTextureInfo = mpMultiTexture->getTextureInfo(mwstrStateKey, mtFrame.frameStart);
	if (pTextureInfo == nullptr)
	{
		return;
	}

	float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

	if (mIcePillarNum == 0)
	{
		POINT pt;
		GetCursorPos(&pt);
		ScreenToClient(ghWnd, &pt);

		cout << "MOUSE: " << pt.x << " / " << pt.y << endl;
		cout << "Dir: " << mtInfo.vDir.x << " / " << mtInfo.vDir.y << endl;
		cout << "mAngle: " << mAngle << endl;
		cout << "pos: " << mtInfo.vPos.x << " / " << mtInfo.vPos.y << endl;
		cout << "Nifl Pos: " << mpNiflheim->getInfo().vPos.x << " / " << mpNiflheim->getInfo().vPos.y << endl;
	}

	DeviceManager::getInstance()->getSprite()->SetTransform(&mtInfo.matWorld);
	DeviceManager::getInstance()->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,

		&D3DXVECTOR3(centerX, centerY, 0.0f),
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);

}

void IcePillar::Release()
{
}

void IcePillar::ShootIceBullet()
{
	Obj *pIceBullet = AbstractFactoryObj<IceBullet>::Create(mtInfo.vPos.x, mtInfo.vPos.y);
	dynamic_cast<IceBullet *>(pIceBullet)->setNiflheim(mpNiflheim);
	dynamic_cast<IceBullet *>(pIceBullet)->setIcePillar(this);
	ObjManager::getInstance()->AddObject(pIceBullet, OBJ::PLAYER_WEAPON);

}
