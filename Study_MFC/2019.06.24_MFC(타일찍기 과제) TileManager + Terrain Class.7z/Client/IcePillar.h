#pragma once
#ifndef _ICE_PILLAR_H_
#define _ICE_PILLAR_H_

#include "Obj.h"

class MultiTexture;

class IcePillar : public Obj
{
public:
	IcePillar();
	virtual ~IcePillar();

public:
	// Obj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual void LateInit() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hDC) override;

private:
	virtual void Release() override;

public:
	void ShootIceBullet();

public:
	float getRevAngle() const { return mRevAngle; }
	bool getIsShield() const { return mbIsShield; }

public:
	void setRevAngle(float angle) { mRevAngle = angle; }
	void setNiflheim(Obj *pNiflheim) { mpNiflheim = pNiflheim; }
	void setIcePillarNum(int num) { mIcePillarNum = num; }
	void setIsShield(bool isTrue) { mbIsShield = isTrue; }

private:
	Obj *mpNiflheim;
	bool mbIsShield;

	int mIcePillarNum;

	D3DXVECTOR3 mvOrigin[4];
	D3DXVECTOR3 mvConvert[4];

	D3DXVECTOR3 mvPosOrigin;

	D3DXMATRIX matRevZ;
	float mRevAngle;

	MultiTexture *mpMultiTexture;
};

#endif