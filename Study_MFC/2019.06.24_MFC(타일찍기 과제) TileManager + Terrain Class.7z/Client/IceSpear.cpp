#include "stdafx.h"
#include "IceSpear.h"


IceSpear::IceSpear()
{
}


IceSpear::~IceSpear()
{
}

void IceSpear::Init()
{
}

int IceSpear::Update()
{
	return 0;
}

void IceSpear::LateUpdate()
{
}

void IceSpear::Render(HDC hDC)
{
}

void IceSpear::Release()
{
}
