#pragma once
#ifndef _ICE_SPEAR_H_
#define _ICE_SPEAR_H_

#include "Obj.h"

class IceSpear : public Obj
{
public:
	IceSpear();
	virtual ~IceSpear();

public:
	// Obj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hDC) override;

private:
	virtual void Release() override;



};

#endif