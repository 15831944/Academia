#include "stdafx.h"
#include "KeyManager.h"

IMPLEMENT_SINGLETON(KeyManager)

KeyManager::KeyManager()
{
	Init();
}

KeyManager::~KeyManager()
{
}

void KeyManager::Init()
{
	mMapKeyMapping.emplace(KEYSET::LEFT, 'A');
	mMapKeyState.emplace('A', false);
	mMapKeyMapping.emplace(KEYSET::RIGHT, 'D');
	mMapKeyState.emplace('D', false);

	mMapKeyMapping.emplace(KEYSET::UP, 'W');
	mMapKeyState.emplace('W', false);
	mMapKeyMapping.emplace(KEYSET::DOWN, 'S');
	mMapKeyState.emplace('S', false);

	mMapKeyMapping.emplace(KEYSET::I, 'I');
	mMapKeyState.emplace('I', false);

	mMapKeyMapping.emplace(KEYSET::NUM1, '1');
	mMapKeyState.emplace('1', false);
	mMapKeyMapping.emplace(KEYSET::NUM2, '2');
	mMapKeyState.emplace('2', false);
	mMapKeyMapping.emplace(KEYSET::NUM3, '3');
	mMapKeyState.emplace('3', false);

	mMapKeyMapping.emplace(KEYSET::NUM4, '4');
	mMapKeyState.emplace('4', false);
	mMapKeyMapping.emplace(KEYSET::NUM5, '5');
	mMapKeyState.emplace('5', false);
	mMapKeyMapping.emplace(KEYSET::NUM6, '6');
	mMapKeyState.emplace('6', false);



	mMapKeyMapping.emplace(KEYSET::Z, 'Z');
	mMapKeyState.emplace('Z', false);
	mMapKeyMapping.emplace(KEYSET::X, 'X');
	mMapKeyState.emplace('X', false);
	mMapKeyMapping.emplace(KEYSET::C, 'C');
	mMapKeyState.emplace('C', false);
	mMapKeyMapping.emplace(KEYSET::V, 'V');
	mMapKeyState.emplace('V', false);
}

bool KeyManager::IsKeyDown(KEYSET::TYPE eType)
{
	if (!(mMapKeyState[mMapKeyMapping[eType]])
		&& (GetAsyncKeyState(mMapKeyMapping[eType]) & 0x8000))
	{
		mMapKeyState[mMapKeyMapping[eType]] = true;
		return true;
	}
	return false;
}

bool KeyManager::IsKeyUp(KEYSET::TYPE eType)
{
	if (mMapKeyState[mMapKeyMapping[eType]]
		&& !(GetAsyncKeyState(mMapKeyMapping[eType]) & 0x8000))
	{
		mMapKeyState[mMapKeyMapping[eType]] = false;
		return true;
	}
	return false;
}

bool KeyManager::IsKeyPressing(KEYSET::TYPE eType)
{
	if (GetAsyncKeyState(mMapKeyMapping[eType]) & 0x8000)
	{
		mMapKeyState[mMapKeyMapping[eType]] = true;
		return true;
	}
	return false;
}

void KeyManager::UpdateKeyState()
{
	map<KEYSET::TYPE, int>::iterator iter = mMapKeyMapping.begin();
	for (; iter != mMapKeyMapping.end(); ++iter)
	{
		if (mMapKeyState[iter->second]
			&& !(GetAsyncKeyState(iter->second) & 0x8000))
		{
			mMapKeyState[iter->second] = false;
		}
	}
}
