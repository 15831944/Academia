#pragma once
#ifndef _KEY_MANAGER_H_
#define _KEY_MANAGER_H_

class KeyManager
{
	DECLARE_SINGLETON(KeyManager)

private:
	KeyManager();
	~KeyManager();

private:
	void Init();

public:
	bool IsKeyDown(KEYSET::TYPE eType);
	bool IsKeyUp(KEYSET::TYPE eType);
	bool IsKeyPressing(KEYSET::TYPE eType);

public:
	void UpdateKeyState();

private:
	map<KEYSET::TYPE, int> mMapKeyMapping;
	map<int, bool> mMapKeyState;
};

#endif