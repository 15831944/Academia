#pragma once
#ifndef _MAIN_GAME_H_
#define _MAIN_GAME_H_

class SingleTexture;

class MainGame
{
public:
	MainGame();
	~MainGame();

public:
	void Init();
	void Update();
	void LateUpdate();
	void Render();

private:
	void Release();

private:
	HDC mhDC;

	//SingleTexture *mpSingleTexture;
};

#endif