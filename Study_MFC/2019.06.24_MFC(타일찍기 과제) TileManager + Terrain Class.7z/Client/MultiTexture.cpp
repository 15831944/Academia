#include "stdafx.h"
#include "MultiTexture.h"


MultiTexture::MultiTexture()
	: mpTextureInfo(nullptr),
	wstrStateKey(nullptr),
	mFrameEnd(0)
{
}


MultiTexture::~MultiTexture()
{
	Release();
}

void MultiTexture::Release()
{
	if (mpTextureInfo != nullptr)
	{
		for (int i = 0; i < mFrameEnd; ++i)
		{
			if (mpTextureInfo[i].pTexture->Release())
			{
				MessageBox(ghWnd, L"LPDIRECT3DTEXTURE9 Release Failed", L"MultiTexture::Release()", MB_OK);
			}
		}
	}

	SafeDeleteArr(mpTextureInfo);
}

HRESULT MultiTexture::LoadTexture(
	const wstring & wstrFilePath,				// ../Texture/Player/Attack/AKIHA_AKI_01_ ����
	const wstring & wstrStateKey /*= L""*/,		// Attack - Attack ���� �̸�?!
	const int & count /*= 0*/)					// 6��
{
	mFrameEnd = count;
	mpTextureInfo = new TEXTURE_INFO[count];
	ZeroMemory(mpTextureInfo, sizeof(TEXTURE_INFO) * count);

	HRESULT hr = 0;

	wstring wstrTemp = L"";

	for (int i = 0; i < count; ++i)
	{
		wstrTemp = wstrFilePath;
		if (i < 10)
		{
			wstrTemp += L"00";
		}
		else if (i >= 10 && i < 100)
		{
			wstrTemp += L"0";
		}
		wstrTemp += std::to_wstring(i);
		wstrTemp += L".png";

		// #########################
		int j = 0;
		// #########################

		hr = D3DXGetImageInfoFromFile(
			wstrTemp.c_str(),
			&(mpTextureInfo[i].tImageInfo)
		);

		if (FAILED(hr))
		{
			MessageBox(ghWnd, L"D3DXGetImageInfoFromFile Failed", L"MultiTexture::LoadTexture()", MB_OK);
			return E_FAIL;
		}

		hr = D3DXCreateTextureFromFileEx(
			DeviceManager::getInstance()->getDevice(),
			wstrTemp.c_str(),
			mpTextureInfo[i].tImageInfo.Width,
			mpTextureInfo[i].tImageInfo.Height,
			mpTextureInfo[i].tImageInfo.MipLevels,
			0,
			mpTextureInfo[i].tImageInfo.Format,
			D3DPOOL_MANAGED,
			D3DX_DEFAULT,
			D3DX_DEFAULT,
			0,
			nullptr,
			nullptr,
			&(mpTextureInfo[i].pTexture)
		);

		if (FAILED(hr))
		{
			MessageBox(ghWnd, L"Create Texture Failed", L"MultiTexture::LoadTexture()", MB_OK);
			return E_FAIL;
		}

		// ##########################
		int k = 0;
		// ##########################
	}

	return S_OK;
}

const TEXTURE_INFO * MultiTexture::getTextureInfo(
	const wstring & wstrStateKey /*= L""*/,
	const int & index /*= 0*/)
{
	return &(mpTextureInfo[index]);
}
