#include "stdafx.h"

#include "IceBullet.h"
#include "IcePillar.h"

#include "MultiTexture.h"

#include "ObjManager.h"

#include "AbstractFactoryObj.h"

#include "Niflheim.h"


Niflheim::Niflheim()
{
	ZeroMemory(mIcePillar, sizeof(mIcePillar));
}


Niflheim::~Niflheim()
{
	Release();
}

void Niflheim::Init()
{
	mtInfo.vPos = { 500.0f, 500.0f, 0.0f };
	mtInfo.vDirOrigin = { 0.0f, -1.0f, 0.0f }; // �⺻������ �¿츦 ����.
	mtInfo.vSize = { 2.5f, 2.5f, 0.0f };

	mvOrigin[0] = { -21.0f, -16.5f, 0.0f };
	mvOrigin[1] = { 21.0f, -16.5f, 0.0f };
	mvOrigin[2] = { 21.0f, 16.5f, 0.0f };
	mvOrigin[3] = { -21.0f, 16.5f, 0.0f };

	Obj::InitMatrixIdentity();

	//mIcePillar[0] = AbstractFactoryObj<IcePillar>::Create(mtInfo.vPos.x - 100.0f, mtInfo.vPos.y, 90.0f);
	mIcePillar[0] = AbstractFactoryObj<IcePillar>::Create(-100.0f, 0.0f, 90.0f);
	dynamic_cast<IcePillar *>(mIcePillar[0])->setNiflheim(this);
	dynamic_cast<IcePillar *>(mIcePillar[0])->setIcePillarNum(0);
	ObjManager::getInstance()->AddObject(mIcePillar[0], OBJ::MONSTER_WEAPON);

	//mIcePillar[1] = AbstractFactoryObj<IcePillar>::Create(mtInfo.vPos.x, mtInfo.vPos.y - 100.0f, 0.0f);
	mIcePillar[1] = AbstractFactoryObj<IcePillar>::Create(0.0f, -100.0f, 0.0f);
	dynamic_cast<IcePillar *>(mIcePillar[1])->setNiflheim(this);
	dynamic_cast<IcePillar *>(mIcePillar[1])->setIcePillarNum(1);
	ObjManager::getInstance()->AddObject(mIcePillar[1], OBJ::MONSTER_WEAPON);

	//mIcePillar[2] = AbstractFactoryObj<IcePillar>::Create(mtInfo.vPos.x + 100.0f, mtInfo.vPos.y, -90.0f);
	mIcePillar[2] = AbstractFactoryObj<IcePillar>::Create(100.0f, 0.0f, -90.0f);
	dynamic_cast<IcePillar *>(mIcePillar[2])->setNiflheim(this);
	dynamic_cast<IcePillar *>(mIcePillar[2])->setIcePillarNum(2);
	ObjManager::getInstance()->AddObject(mIcePillar[2], OBJ::MONSTER_WEAPON);

	//mIcePillar[3] = AbstractFactoryObj<IcePillar>::Create(mtInfo.vPos.x, mtInfo.vPos.y + 100.0f, 180.0f);
	mIcePillar[3] = AbstractFactoryObj<IcePillar>::Create(0.0f, 100.0f, 180.0f);
	dynamic_cast<IcePillar *>(mIcePillar[3])->setNiflheim(this);
	dynamic_cast<IcePillar *>(mIcePillar[3])->setIcePillarNum(3);
	ObjManager::getInstance()->AddObject(mIcePillar[3], OBJ::MONSTER_WEAPON);


	mpMultiTexture = const_cast<MultiTexture *>(TextureManager::getInstance()->getMultiTexture(MULTITEXTURE::NIFLHEIM, &std::wstring(L"Idle")));
	mwstrStateKey = L"Idle";

	mtFrame.frameStart = 0;
	mtFrame.frameEnd = mpMultiTexture->getFrameEnd();
	mtFrame.dwFrameSpeed = 100;
	mtFrame.dwFrameTime = GetTickCount();


	dwShootTime = GetTickCount();
}

int Niflheim::Update()
{
	if (mbIsDead)
	{
		return OBJ_DEAD;
	}

	if (KeyManager::getInstance()->IsKeyPressing(KEYSET::Z)) // Rotation
	{
		for (int i = 0; i < 4; ++i)
		{
			mIcePillar[i]->setAngle(mIcePillar[i]->getAngle() + 5.0f);
		}
	}
	if (KeyManager::getInstance()->IsKeyPressing(KEYSET::X)) // Revolution
	{
		for (int i = 0; i < 4; ++i)
		{
			dynamic_cast<IcePillar *>(mIcePillar[i])->setRevAngle(dynamic_cast<IcePillar *>(mIcePillar[i])->getRevAngle() + 4.0f);
		}
	}
	if (KeyManager::getInstance()->IsKeyPressing(KEYSET::C))
	{
		for (int i = 0; i < 4; ++i)
		{
			dynamic_cast<IcePillar *>(mIcePillar[i])->setRevAngle(dynamic_cast<IcePillar *>(mIcePillar[i])->getRevAngle() - 4.0f);
		}
	}
	if (KeyManager::getInstance()->IsKeyPressing(KEYSET::V))
	{
		if (dwShootTime + 100 < GetTickCount())
		{
			for (int i = 0; i < 4; ++i)
			{
				dynamic_cast<IcePillar *>(mIcePillar[i])->ShootIceBullet();
			}
			dwShootTime = GetTickCount();
		}
	}

	if (KeyManager::getInstance()->IsKeyDown(KEYSET::NUM1)) // ���� ��ġ
	{
		for (int i = 0; i < 4; ++i)
		{
			dynamic_cast<IcePillar *>(mIcePillar[i])->setRevAngle(0.0f);
			dynamic_cast<IcePillar *>(mIcePillar[i])->setIsShield(false);
			mIcePillar[i]->setAngle(0.0f);
		}

		mIcePillar[0]->SetPosition(WINSIZE_X / 2.0f - 375.0f, WINSIZE_Y / 4.0f);
		mIcePillar[1]->SetPosition(WINSIZE_X / 2.0f - 125.0f, WINSIZE_Y / 4.0f);
		mIcePillar[2]->SetPosition(WINSIZE_X / 2.0f + 125.0f, WINSIZE_Y / 4.0f);
		mIcePillar[3]->SetPosition(WINSIZE_X / 2.0f + 375.0f, WINSIZE_Y / 4.0f);

	}

	if (KeyManager::getInstance()->IsKeyDown(KEYSET::NUM2)) // Shield ��ġ
	{
		mIcePillar[0]->SetPosition(-100.0f, 0.0f);
		mIcePillar[0]->setAngle(90.0f);

		mIcePillar[1]->SetPosition(0.0f, -100.0f);
		mIcePillar[1]->setAngle(0.0f);

		mIcePillar[2]->SetPosition(100.0f, 0.0f);
		mIcePillar[2]->setAngle(-90.0f);

		mIcePillar[3]->SetPosition(0.0f, 100.0f);
		mIcePillar[3]->setAngle(180.0f);

		for (int i = 0; i < 4; ++i)
		{
			dynamic_cast<IcePillar *>(mIcePillar[i])->setRevAngle(0.0f);
			dynamic_cast<IcePillar *>(mIcePillar[i])->setIsShield(true);
		}
	}
	if (KeyManager::getInstance()->IsKeyDown(KEYSET::NUM3)) // �ٵ��ǽ� ��ġ
	{
		for (int i = 0; i < 4; ++i)
		{
			dynamic_cast<IcePillar *>(mIcePillar[i])->setRevAngle(0.0f);
			dynamic_cast<IcePillar *>(mIcePillar[i])->setIsShield(false);
			mIcePillar[i]->setAngle(0.0f);
		}

		mIcePillar[0]->SetPosition(WINSIZE_X / 2.0f - 200.0f, WINSIZE_Y / 2.0f - 200.0f);
		mIcePillar[1]->SetPosition(WINSIZE_X / 2.0f + 200.0f, WINSIZE_Y / 2.0f - 200.0f);
		mIcePillar[2]->SetPosition(WINSIZE_X / 2.0f + 200.0f, WINSIZE_Y / 2.0f + 200.0f);
		mIcePillar[3]->SetPosition(WINSIZE_X / 2.0f - 200.0f, WINSIZE_Y / 2.0f + 200.0f);
	}



	D3DXMatrixScaling(&mtInfo.matScale, mtInfo.vSize.x, mtInfo.vSize.y, mtInfo.vSize.z);
	D3DXMatrixRotationZ(&mtInfo.matRotZ, D3DXToRadian(-mAngle));
	D3DXMatrixTranslation(&mtInfo.matTrans, mtInfo.vPos.x, mtInfo.vPos.y, mtInfo.vPos.z);

	mtInfo.matWorld = mtInfo.matScale * mtInfo.matRotZ * mtInfo.matTrans;

	for (int i = 0; i < 4; ++i)
	{
		D3DXVec3TransformCoord(&mvConvert[i], &mvOrigin[i], &mtInfo.matWorld);
	}

	D3DXVec3TransformNormal(&mtInfo.vDir, &mtInfo.vDirOrigin, &mtInfo.matWorld);

	D3DXVec3Normalize(&mtInfo.vDir, &mtInfo.vDir);

	return OBJ_NOEVENT;
}

void Niflheim::LateUpdate()
{
	Obj::FrameMove();
	MoveDirection();
}

void Niflheim::Render(HDC hDC)
{
	//cout << "mIcePillar[0]: " << mIcePillar[0]->getInfo().vPos.x << " / " << mIcePillar[0]->getInfo().vPos.y << endl;
	//cout << "m: " << dynamic_cast<IcePillar *>(mIcePillar[0])->getRevAngle() << endl;
	/*cout << "mIcePillar[1]: " << mIcePillar[1]->getInfo().vPos.x << " / " << mIcePillar[1]->getInfo().vPos.y << endl;
	cout << "mIcePillar[2]: " << mIcePillar[2]->getInfo().vPos.x << " / " << mIcePillar[2]->getInfo().vPos.y << endl;
	cout << "mIcePillar[3]: " << mIcePillar[3]->getInfo().vPos.x << " / " << mIcePillar[3]->getInfo().vPos.y << endl;*/

	const TEXTURE_INFO *pTextureInfo = mpMultiTexture->getTextureInfo(mwstrStateKey, mtFrame.frameStart);
	if (pTextureInfo == nullptr)
	{
		return;
	}

	float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

	DeviceManager::getInstance()->getSprite()->SetTransform(&mtInfo.matWorld);
	DeviceManager::getInstance()->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,

		&D3DXVECTOR3(centerX, centerY, 0.0f),
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);
}

void Niflheim::Release()
{
}

void Niflheim::ChangeScene()
{
	if (meCurState != meNextState)
	{
		switch (meNextState)
		{
		case Niflheim::ENTER:
			break;
		case Niflheim::IDLE:
			break;
		case Niflheim::ATTAK:
			break;
		case Niflheim::DIE:
			break;
		default:
			break;
		}

		meCurState = meNextState;
	}
}

void Niflheim::MoveDirection()
{
	Obj::MoveDirection();

	const Obj *pPlayer = ObjManager::getInstance()->getPlayer();
	if (pPlayer != nullptr)
	{
		if (mtInfo.vPos.x >= pPlayer->getInfo().vPos.x)
		{
			meDirection = DIRECTION::LEFT;
		}
		else// if (mtInfo.vPos.x < pPlayer->getInfo().vPos.x)
		{
			meDirection = DIRECTION::RIGHT;
		}
	}

}
