#pragma once
#ifndef _NIFLHEIM_H_
#define _NIFLHEIM_H_

#include "Monster.h"

class MultiTexture;

class Niflheim : public Monster
{
public:
	Niflheim();
	virtual ~Niflheim();

public:
	enum STATE {
		ENTER,
		IDLE,
		ATTAK,
		DIE,
		END
	};

public:
	// Monster��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hDC) override;

private:
	virtual void Release() override;

public:

private:
	void ChangeScene();
	virtual void MoveDirection();

private:
	D3DXVECTOR3 mvOrigin[4];
	D3DXVECTOR3 mvConvert[4];

	DWORD dwShootTime;

	MultiTexture *mpMultiTexture;

	Obj *mIcePillar[4];

	STATE meCurState;
	STATE meNextState;
};

#endif