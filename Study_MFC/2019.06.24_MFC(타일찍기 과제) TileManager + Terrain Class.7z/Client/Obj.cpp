#include "stdafx.h"
#include "Obj.h"


Obj::Obj()
	: mbIsInit(false), mbIsDead(false),
	mAngle(0.0f), mRotSpeed(0.0f),
	mSpeed(0.0f),
	mwstrStateKey({})
{
	ZeroMemory(&mtInfo, sizeof(INFO));
	ZeroMemory(&mtFrame, sizeof(FRAME));
}


Obj::~Obj()
{
}

void Obj::LateInit()
{
	if (!(mbIsInit))
	{
		mbIsInit = true;
		this->LateInit();
	}
}

void Obj::FrameMove()
{
	if (mtFrame.dwFrameTime + mtFrame.dwFrameSpeed < GetTickCount())
	{
		++mtFrame.frameStart;
		mtFrame.dwFrameTime = GetTickCount();
	}

	if (mtFrame.frameStart >= mtFrame.frameEnd)
	{
		mtFrame.frameStart = 0;
	}
}

void Obj::MoveDirection()
{
	if (meDirection == DIRECTION::LEFT)
	{
		mtInfo.vSize.x = -fabs(mtInfo.vSize.x);
	}
	else if(meDirection == DIRECTION::RIGHT)
	{
		mtInfo.vSize.x = fabs(mtInfo.vSize.x);
	}
}

void Obj::InitMatrixIdentity()
{
	D3DXMatrixIdentity(&mtInfo.matWorld);
	D3DXMatrixIdentity(&mtInfo.matScale);
	D3DXMatrixIdentity(&mtInfo.matRotZ);
	D3DXMatrixIdentity(&mtInfo.matTrans);
}
