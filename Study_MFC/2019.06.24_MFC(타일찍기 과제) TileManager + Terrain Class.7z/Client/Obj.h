#pragma once
#ifndef _OBJ_H_
#define _OBJ_H_

class Obj
{
public:
	Obj();
	virtual ~Obj();

public:
	virtual void Init() = 0;
	virtual void LateInit();
	virtual int Update() = 0;
	virtual void LateUpdate() = 0;
	virtual void Render(HDC hDC) = 0;
	virtual void Release() = 0;

protected:
	void FrameMove();
	virtual void MoveDirection();
	void InitMatrixIdentity();

public:
	DIRECTION::TYPE getDirection() const { return meDirection; }

public:
	const INFO& getInfo() const { return mtInfo; }
	const FRAME& getFrame() const { return mtFrame; }
	const float getAngle() const { return mAngle; }

public:
	void SetPosition(float x, float y) { mtInfo.vPos.x = x, mtInfo.vPos.y = y; }
	void setAngle(float angle) { mAngle = angle; }

protected:
	INFO mtInfo;
	FRAME mtFrame;

	float mAngle;
	float mRotSpeed;
	float mSpeed;

	DIRECTION::TYPE meDirection;

	bool mbIsInit;
	bool mbIsDead;

	wstring mwstrStateKey;
};

#endif