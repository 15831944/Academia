#include "stdafx.h"

#include "Obj.h"

#include "ObjManager.h"

IMPLEMENT_SINGLETON(ObjManager)

ObjManager::ObjManager()
{
}

ObjManager::~ObjManager()
{
	Release();
}

void ObjManager::Update()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		list<Obj *>::iterator iter = mListObj[i].begin();
		for (; iter != mListObj[i].end();)
		{
			int eventNum = (*iter)->Update();
			if (eventNum == OBJ_DEAD)
			{
				SafeDelete(*iter);
				iter = mListObj[i].erase(iter);
			}
			else
			{
				++iter;
			}
		}
	}
}

void ObjManager::LateUpdate()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mListObj[i])
		{
			pObj->LateUpdate();
		}
	}
}

void ObjManager::Render(HDC hDC)
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mListObj[i])
		{
			pObj->Render(hDC);
		}
	}
}

void ObjManager::Init()
{
}

void ObjManager::Release()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mListObj[i])
		{
			SafeDelete(pObj);
		}
		mListObj[i].clear();
	}
}

void ObjManager::AddObject(Obj * pObj, OBJ::TYPE eType)
{
	if (pObj != nullptr)
	{
		mListObj[eType].emplace_back(pObj);
	}
}

void ObjManager::AddObjectFront(Obj * pObj, OBJ::TYPE eType)
{
	if (pObj != nullptr)
	{
		mListObj[eType].emplace_front(pObj);
	}
}

void ObjManager::ClearObjType(OBJ::TYPE eType)
{
	for (Obj *pObj : mListObj[eType])
	{
		SafeDelete(pObj);
	}
	mListObj[eType].clear();
}
