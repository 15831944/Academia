#pragma once
#ifndef _OBJ_MANAGER_H_
#define _OBJ_MANAGER_H_

class Obj;

class ObjManager
{
	DECLARE_SINGLETON(ObjManager)

private:
	ObjManager();
	~ObjManager();

public:
	void Update();
	void LateUpdate();
	void Render(HDC hDC);

private:
	void Init();
	void Release();

public:
	void AddObject(Obj *pObj, OBJ::TYPE eType);
	void AddObjectFront(Obj *pObj, OBJ::TYPE eType);
	void ClearObjType(OBJ::TYPE eType);

public:
	const Obj* getPlayer() const { return (mListObj[OBJ::PLAYER].empty() ? nullptr : mListObj[OBJ::PLAYER].front()); }
	const Obj* getBoss() const { return (mListObj[OBJ::BOSS].empty() ? nullptr : mListObj[OBJ::BOSS].front()); }

private:

	list<Obj *> mListObj[OBJ::TYPE::END];
};

#endif