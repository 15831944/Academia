#include "stdafx.h"

#include "MultiTexture.h"
#include "SingleTexture.h"

#include "Player.h"


Player::Player()
{
	ZeroMemory(&mvOrigin, sizeof(mvOrigin));
	ZeroMemory(&mvConvert, sizeof(mvConvert));
}


Player::~Player()
{
	Release();
}


// Obj��(��) ���� ��ӵ�

void Player::Init()
{
	mtInfo.vPos = { WINSIZE_X / 2.0f, WINSIZE_Y / 2.0f, 0.0f };
	mtInfo.vDirOrigin = { 0.0f, -1.0f, 0.0f };
	mtInfo.vSize = { 1.0f, 1.0f, 0.0f };

	mvOrigin[0] = { -50.0f, -50.0f, 0.0f };
	mvOrigin[1] = { 50.0f, -50.0f, 0.0f };
	mvOrigin[2] = { 50.0f, 50.0f, 0.0f };
	mvOrigin[3] = { -50.0f, 50.0f, 0.0f };

	mAngle = 0.0f;
	mRotSpeed = 3.0f;
	mSpeed = 5.0f;

	index = 0;

	Obj::InitMatrixIdentity();

	mbIsTurnDirection = false;

	//mpSingleTexture = new SingleTexture;
	//mpSingleTexture->LoadTexture(L"../Texture/Cube.png");

	//mpMultiTexture = new MultiTexture;
	//mpMultiTexture->LoadTexture(L"../Texture/Player/Attack/AKIHA_AKI01_", L"Attack", 6);

	//mpMultiTexture = const_cast<MultiTexture *>(TextureManager::getInstance()->getMultiTexture(MAPKEY::PLAYER, &std::wstring(L"Attack")));
	mpMultiTexture = const_cast<MultiTexture *>(TextureManager::getInstance()->getMultiTexture(MULTITEXTURE::PLAYER, &std::wstring(L"Stand")));
	mwstrStateKey = L"Stand";
}

int Player::Update()
{
	InputKeyBoard();

	D3DXMatrixScaling(&mtInfo.matScale, mtInfo.vSize.x, mtInfo.vSize.y, mtInfo.vSize.z);
	D3DXMatrixRotationZ(&mtInfo.matRotZ, D3DXToRadian(-mAngle)); // ȸ�� ������ �״�� ����ϱ� ������... ������ Cartesian ��ǥ�� ��ȯ
	D3DXMatrixTranslation(&mtInfo.matTrans, mtInfo.vPos.x, mtInfo.vPos.y, mtInfo.vPos.z);

	// Scaling * Rotation * Translation * Revolution * Parent
	mtInfo.matWorld = mtInfo.matScale * mtInfo.matRotZ * mtInfo.matTrans;

	for (int i = 0; i < 4; ++i)
	{
		D3DXVec3TransformCoord(&mvConvert[i], &mvOrigin[i], &mtInfo.matWorld);
	}

	D3DXVec3TransformNormal(&mtInfo.vDir, &mtInfo.vDirOrigin, &mtInfo.matWorld);

	D3DXVec3Normalize(&mtInfo.vDir, &mtInfo.vDir);

	return OBJ_NOEVENT;
}

void Player::LateUpdate()
{
	static DWORD dwOldTime = GetTickCount();

	if (dwOldTime + 100 < GetTickCount())
	{
		++index;
		if (index == mpMultiTexture->getFrameEnd())
			index = 0;

		dwOldTime = GetTickCount();
	}
}

void Player::Render(HDC hDC)
{
	/*MoveToEx(hDC, (int)mvConvert[0].x, (int)mvConvert[0].y, nullptr);
	LineTo(hDC, (int)mvConvert[1].x, (int)mvConvert[1].y);
	LineTo(hDC, (int)mvConvert[2].x, (int)mvConvert[2].y);
	LineTo(hDC, (int)mvConvert[3].x, (int)mvConvert[3].y);
	LineTo(hDC, (int)mvConvert[0].x, (int)mvConvert[0].y);

	for (int i = 0; i < 2; ++i)
	{
		Ellipse(hDC,
			(int)mvConvert[i].x - 10, (int)mvConvert[i].y - 10,
			(int)mvConvert[i].x + 10, (int)mvConvert[i].y + 10
		);
	}*/

	// Direct3D���� �������� �ϱ� ���ؼ��� Vertex�� �ʿ��մϴ�.
	// 3�������� ����� �̷�� �ּ� ������ "�ﰢ��"
	// 3D ���������� ������ ������ ��ƾ� �Ѵ� !!!!

	//const TEXTURE_INFO *pTextureInfo = mpSingleTexture->getTextureInfo();
	//const TEXTURE_INFO *pTextureInfo = mpMultiTexture->getTextureInfo(L"Attack", index);
	const TEXTURE_INFO *pTextureInfo = mpMultiTexture->getTextureInfo(mwstrStateKey, index);

	if (pTextureInfo != nullptr)
	{
		return;
	}

	float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY = pTextureInfo->tImageInfo.Height * 0.5f + 40.0f;


	// Transformation�� ���� Sprite COM ��ü�� �Լ��� �������ش�.
	// �׸���, Rendering �ϱ����� Transformation
	DeviceManager::getInstance()->getSprite()->SetTransform(&mtInfo.matWorld);
	DeviceManager::getInstance()->getSprite()->Draw(
		pTextureInfo->pTexture, // Texutre COM ��ü
		nullptr, // RECT�� ������(�̹����� �Ϻκ��� �������� �� ����)
				 //&D3DXVECTOR3(centerX, centerY, 0.0f), // Center
		&D3DXVECTOR3(centerX, centerY, 0.0f), // Center(�긦 �������� ȸ��)
		nullptr, // Position(�긦 �������� �׸��� �׸� offset ����)
				 // nullptr - �׸� ��ü ���, &DeDXVECTOR3(0.0f, 0.0f, 0.0f)
				 // �׸���, ���ʿ� World Matrix�� Translation�� ���� �ϹǷ� nullptr !!!!
		D3DCOLOR_ARGB(255, 255, 255, 255) // ���� 100%�� ����ϰڴٴ� �ǹ�.
	);

}

void Player::Release()
{
	//SafeDelete(mpMultiTexture);
	//SafeDelete(mpSingleTexture);
}

void Player::InputKeyBoard()
{
	if (KeyManager::getInstance()->IsKeyPressing(KEYSET::LEFT))
	{
		//mAngle += mRotSpeed;
		mtInfo.vPos.x += (-mSpeed);
		if (!(mbIsTurnDirection))
		{
			mbIsTurnDirection = true;
			mtInfo.vSize.x = -mtInfo.vSize.x;
		}
	}

	if (KeyManager::getInstance()->IsKeyPressing(KEYSET::RIGHT))
	{
		//mAngle += (-mRotSpeed);
		mtInfo.vPos.x += mSpeed;
		if (!(mbIsTurnDirection))
		{
			mbIsTurnDirection = true;
			mtInfo.vSize.x = -mtInfo.vSize.x;
		}
	}

	if (KeyManager::getInstance()->IsKeyPressing(KEYSET::UP))
	{
		mtInfo.vPos += mtInfo.vDir * mSpeed;
	}
	if (KeyManager::getInstance()->IsKeyPressing(KEYSET::DOWN))
	{
		mtInfo.vPos += mtInfo.vDir * (-mSpeed);
	}

	if (KeyManager::getInstance()->IsKeyDown(KEYSET::NUM1))
	{
		cout << "Attack" << endl;
		mpMultiTexture = const_cast<MultiTexture *>(TextureManager::getInstance()->getMultiTexture(MULTITEXTURE::PLAYER, &std::wstring(L"Attack")));
		mwstrStateKey = L"Attack";
		index = 0;

	}
	if (KeyManager::getInstance()->IsKeyDown(KEYSET::NUM2))
	{
		cout << "Stand" << endl;
		mpMultiTexture = const_cast<MultiTexture *>(TextureManager::getInstance()->getMultiTexture(MULTITEXTURE::PLAYER, &std::wstring(L"Stand")));
		mwstrStateKey = L"Stand";
		index = 0;

	}
	if (KeyManager::getInstance()->IsKeyDown(KEYSET::NUM3))
	{
		cout << "Walk" << endl;
		mpMultiTexture = const_cast<MultiTexture *>(TextureManager::getInstance()->getMultiTexture(MULTITEXTURE::PLAYER, &std::wstring(L"Walk")));
		mwstrStateKey = L"Walk";
		index = 0;

	}
}


