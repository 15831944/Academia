#pragma once
#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "Obj.h"

class SingleTexture;
class MultiTexture;

class Player : public Obj
{
public:
	Player();
	virtual ~Player();

public:
	enum STATE {
		STAND,
		WALK,
		ATTACK,
		END
	};

public:
	// Obj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hDC) override;

private:
	virtual void Release() override;

private:
	void InputKeyBoard();

private:
	D3DXVECTOR3 mvOrigin[4];
	D3DXVECTOR3 mvConvert[4];

	MultiTexture *mpMultiTexture;
	//SingleTexture *mpSingleTexture;

	int index;

	bool mbIsTurnDirection;
	wstring mwstrStateKey;
};

#endif