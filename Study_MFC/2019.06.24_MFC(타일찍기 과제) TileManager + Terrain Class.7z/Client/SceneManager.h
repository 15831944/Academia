#pragma once
#ifndef _SCENE_MANAGER_H_
#define _SCENE_MANAGER_H_

class SceneManager
{
	DECLARE_SINGLETON(SceneManager)

private:
	SceneManager();
	~SceneManager();

public:
	//void ChangeScene();

};

#endif