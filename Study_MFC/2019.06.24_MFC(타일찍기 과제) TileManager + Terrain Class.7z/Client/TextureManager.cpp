#include "stdafx.h"

#include "MultiTexture.h"
#include "SingleTexture.h"

#include "TextureManager.h"

IMPLEMENT_SINGLETON(TextureManager)

TextureManager::TextureManager()
{
}


TextureManager::~TextureManager()
{
	Release();
}

void TextureManager::Init()
{
	//InsertSingleTexture(MAPKEY::PLAYER, L"../Texture/Cube.png");

	//OBJ_MULTI_KEY::
	//OBJ_MULTI_KEY::
	//OBJ_MULTI_KEY::
	InsertMultiTexture(MULTITEXTURE::PLAYER, L"../Texture/Player/Attack/AKIHA_AKI01_", L"Attack", 6);
	InsertMultiTexture(MULTITEXTURE::PLAYER, L"../Texture/Player/Stand/AKIHA_AKI00_", L"Stand", 12);
	InsertMultiTexture(MULTITEXTURE::PLAYER, L"../Texture/Player/Walk/AKIHA_AKI26_", L"Walk", 13);

	InsertMultiTexture(MULTITEXTURE::NIFLHEIM, L"../Texture/Niflheim/Niflheim/Enter/Niflheim_Enter_", L"Enter", 16);
	InsertMultiTexture(MULTITEXTURE::NIFLHEIM, L"../Texture/Niflheim/Niflheim/Idle/Niflheim_Idle_", L"Idle", 6);
	InsertMultiTexture(MULTITEXTURE::NIFLHEIM, L"../Texture/Niflheim/Niflheim/Attack/Niflheim_Attack_", L"Attack", 11);
	InsertMultiTexture(MULTITEXTURE::NIFLHEIM, L"../Texture/Niflheim/Niflheim/Die/Niflheim_Die_", L"Die", 30);

	InsertMultiTexture(MULTITEXTURE::NIFLHEIM_ICE_PILLAR, L"../Texture/Niflheim/IcePillar/IcePillar_", L"IcePillar", 1);
	InsertMultiTexture(MULTITEXTURE::NIFLHEIM_ICE_PILLAR, L"../Texture/Niflheim/IcePillar/CreateFX/IcePillar_CreateFX_", L"CreateFX", 20);
	InsertMultiTexture(MULTITEXTURE::NIFLHEIM_ICE_PILLAR, L"../Texture/Niflheim/IcePillar/DestroyFX/IcePillar_DestroyFX_", L"DestroyFX", 3);

	InsertMultiTexture(MULTITEXTURE::NIFLHEIM_ICE_BULLET, L"../Texture/Niflheim/IceBullet/IceBullet_", L"IceBullet", 1);
	InsertMultiTexture(MULTITEXTURE::NIFLHEIM_ICE_BULLET, L"../Texture/Niflheim/IceBullet/FX/IceBullet_FX_", L"FX", 3);


	int i = 0;
}

void TextureManager::Release()
{
	for (auto &texturePair : mMapSingleTexture)
	{
		SafeDelete(texturePair.second);
	}
	//mMapSingleTexture.clear();

	for (int i = 0; i < MULTITEXTURE::KEY::END; ++i)
	{
		for (auto &texturePair : mMapMultiTexture[i])
		{
			SafeDelete(texturePair.second);
		}
		//mMapMultiTexture[i].clear();
	}

}

void TextureManager::InsertSingleTexture(SINGLETEXTURE::KEY eObjKeyType, const wstring & wstrFilePath)
{
	SingleTexture *pSingleTexture = new SingleTexture;
	pSingleTexture->LoadTexture(wstrFilePath);

	mMapSingleTexture.emplace(eObjKeyType, pSingleTexture);
}

void TextureManager::InsertMultiTexture(MULTITEXTURE::KEY eObjKeyType, const wstring & wstrFilePath, const wstring & wstrStateKey, const int & count)
{
	//map<wstring *, MultiTexture *> mMapMultiTex[MAPKEY::OBJ_KEY::END];

	MultiTexture *pMultiTexture = new MultiTexture;
	if (pMultiTexture != nullptr)
	{
		pMultiTexture->LoadTexture(wstrFilePath, wstrStateKey, count);
		const wstring wstrTemp = wstrStateKey;
		mMapMultiTexture[eObjKeyType].emplace(wstrTemp, pMultiTexture);
	}
}

const SingleTexture * TextureManager::getSingleTexture(SINGLETEXTURE::KEY eObjKeyType)
{
	return mMapSingleTexture[eObjKeyType];
}

const MultiTexture * TextureManager::getMultiTexture(MULTITEXTURE::KEY eObjKeyType, wstring *wstrState)
{
	//map<const wstring, MultiTexture *> mMapMultiTexture[MAPKEY::OBJ_KEY::END];

	map<const wstring, MultiTexture *>::iterator iter = mMapMultiTexture[eObjKeyType].begin();
	for (; iter != mMapMultiTexture[eObjKeyType].end(); ++iter)
	{
		if (!lstrcmp(wstrState->c_str(), (iter->first).c_str()))
		{
			return iter->second;
		}
	}

	return nullptr;
}

