#pragma once
#ifndef _TEXTURE_MANAGER_H_
#define _TEXTURE_MANAGER_H_

class SingleTexture;
class MultiTexture;

class TextureManager
{
	DECLARE_SINGLETON(TextureManager)

private:
	TextureManager();
	~TextureManager();

public:
	void Init();

private:
	void Release();

public:
	void InsertSingleTexture(
		SINGLETEXTURE::KEY eObjKeyType,
		const wstring & wstrFilePath
	);
	void InsertMultiTexture(
		MULTITEXTURE::KEY eObjKeyType,
		const wstring & wstrFilePath,
		const wstring & wstrStateKey,
		const int & count
	);

public:
	const SingleTexture* getSingleTexture(SINGLETEXTURE::KEY eObjKeyType);
	const MultiTexture* getMultiTexture(MULTITEXTURE::KEY eObjKeyType, wstring *wstrState);

private:
	map<SINGLETEXTURE::KEY, SingleTexture *> mMapSingleTexture;
	map<const wstring, MultiTexture *> mMapMultiTexture[MULTITEXTURE::KEY::END];
};

#endif