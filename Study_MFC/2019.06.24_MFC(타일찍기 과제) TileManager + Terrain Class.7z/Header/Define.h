#pragma once
#ifndef _DEFINE_H_
#define _DEFINE_H_

// #################################################################
// Client

#define WINSIZE_X 800
#define WINSIZE_Y 600

#define OBJ_NOEVENT 0
#define OBJ_DEAD 1


// #################################################################

#define NO_COPY(ClassName)						\
private:										\
	ClassName(const ClassName &);				\
	ClassName& operator=(const ClassName &);

#define DECLARE_SINGLETON(ClassName)			\
public:											\
	static ClassName* getInstance();			\
	static void DestroyInstance();				\
private:										\
	static ClassName *mpInstance;


#define IMPLEMENT_SINGLETON(ClassName)			\
ClassName* ClassName::mpInstance = nullptr;		\
ClassName* ClassName::getInstance()				\
{												\
	if (mpInstance == nullptr)					\
	{											\
		mpInstance = new ClassName;				\
	}											\
	return mpInstance;							\
}												\
void ClassName::DestroyInstance()				\
{												\
	if (mpInstance)								\
	{											\
		delete mpInstance;						\
		mpInstance = nullptr;					\
	}											\
}



// #################################################################
// Tool(MFC)

#define MIN_STR 64
#define MID_STR 128
#define MAX_STR 256

#define TILE_X 20
#define TILE_Y 30

#define TILESIZE_X 130
#define TILESIZE_Y 68

// �̰��� MFC ���� �޽��� �ڽ�.
#define ERR_MSG(msg)	\
AfxMessageBox(msg)

#define NULL_CHECK(ptr)	\
if(ptr == nullptr)		\
	return;

#define NULL_CHECK_MSG(ptr, msg)	\
if (ptr == nullptr)					\
{									\
	ERR_MSG(msg);					\
	return;							\
}

#define NULL_CHECK_RETURN(ptr, returnValue)	\
if (ptr == nullptr)							\
	return returnValue;

#define NULL_CHECK_MSG_RETURN(ptr, msg, returnValue)	\
if (ptr == nullptr)										\
{														\
	ERR_MSG(msg);										\
	return returnValue;									\
}


#define FAILED_CHECK(hr)	\
if (FAILED(hr))				\
	return;

#define FAILED_CHECK_MSG(hr, msg)	\
if (FAILED(hr))						\
{									\
	ERR_MSG(msg);					\
	return;							\
}

#define FAILED_CHECK_RETURN(hr, returnValue)	\
if (FAILED(hr))									\
	return returnValue;

#define FAILED_CHECK_MSG_RETURN(hr, msg, returnValue)	\
if (FAILED(hr))											\
{														\
	ERR_MSG(msg);										\
	return returnValue;									\
}



#endif