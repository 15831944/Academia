#pragma once
#ifndef _STRUCT_H_
#define _STRUCT_H_

typedef struct tagInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vDir;
	D3DXVECTOR3 vDirOrigin;
	D3DXVECTOR3 vSize;

	D3DXMATRIX matWorld;
	D3DXMATRIX matScale;
	D3DXMATRIX matRotZ;
	D3DXMATRIX matTrans;
} INFO;

typedef struct tagTextureInfo
{
	// COM ��ü�� Texture�� �����մϴ�.
	LPDIRECT3DTEXTURE9 pTexture;

	// ����ؾ� �� Texture ����
	D3DXIMAGE_INFO tImageInfo;
} TEXTURE_INFO;

typedef struct tagFrame
{
	int frameStart;
	int frameEnd;

	DWORD dwFrameSpeed;
	DWORD dwFrameTime;
} FRAME;

// ############################################################

typedef struct tagTileInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vSize;
	BYTE byDrawID;
	BYTE byOption;

} TILE_INFO;


#endif