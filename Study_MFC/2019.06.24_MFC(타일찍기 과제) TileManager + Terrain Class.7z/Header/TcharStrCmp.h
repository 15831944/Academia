#pragma once
#ifndef _TCHAR_STR_CMP_H_
#define _TCHAR_STR_CMP_H_





#endif