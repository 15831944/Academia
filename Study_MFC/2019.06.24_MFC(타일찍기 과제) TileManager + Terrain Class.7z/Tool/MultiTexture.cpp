#include "stdafx.h"

#include "MultiTexture.h"

CMultiTexture::CMultiTexture()
{
}


CMultiTexture ::~CMultiTexture()
{
	Release();
}

void CMultiTexture::Release()
{
	for (auto &MyPair : m_mapMultiTexture)
	{
		for (auto &pTextureInfo : MyPair.second)
		{
			pTextureInfo->pTexture->Release();
			SafeDelete(pTextureInfo);
		}

		MyPair.second.clear();
		MyPair.second.shrink_to_fit();
	}

	m_mapMultiTexture.clear();
}

HRESULT CMultiTexture::LoadTexture(
	const wstring &wstrFilePath, // ex. ../Texture/Terrain/Tile/Tile%d.png ����
	const wstring &wstrStateKey /*= L""*/,
	const int &count /*= 0*/)
{
	auto iterFind = m_mapMultiTexture.find(wstrStateKey);

	if (iterFind != m_mapMultiTexture.end()) // ������ ����.
		return E_FAIL;

	HRESULT hr = 0;

	TCHAR fullFilePath[MAX_STR] = L"";

	for (int i = 0; i < count; ++i)
	{
		// ############################################################
		swprintf_s(fullFilePath, wstrFilePath.c_str(), i);
		// ############################################################

		TEXTURE_INFO *pTextureInfo = new TEXTURE_INFO;
		ZeroMemory(pTextureInfo, sizeof(TEXTURE_INFO));

		// ����� �̹����� ������ ������ �Լ�.
		// ../Texture/Terrain/Tile/Tile0.png
		hr = D3DXGetImageInfoFromFile(fullFilePath, &pTextureInfo->tImageInfo);
		// HRESULT ������ ���� �־��ָ� ������ ����ó�� !!!!
		FAILED_CHECK_MSG_RETURN(hr, L"D3DXGetImageInfoFromFile Failed, MultiTexture::LoadTexture()", E_FAIL);

		// �̹��� �ҷ����� �Լ�(Texture ����)
		hr = D3DXCreateTextureFromFileEx(
			CDeviceManager::getInstance()->getDevice(),
			fullFilePath,
			pTextureInfo->tImageInfo.Width,
			pTextureInfo->tImageInfo.Height,
			pTextureInfo->tImageInfo.MipLevels,
			0,
			pTextureInfo->tImageInfo.Format,
			D3DPOOL_MANAGED,
			D3DX_DEFAULT,
			D3DX_DEFAULT,
			0,
			nullptr,
			nullptr,
			&pTextureInfo->pTexture
		);

		// HRESULT ������ ���� �־��ָ� ������ ����ó�� !!!!
		FAILED_CHECK_MSG_RETURN(hr, L"D3DXCreateTextureFromFileEx Failed, MultiTexture::LoadTexture()", E_FAIL);

		m_mapMultiTexture[wstrStateKey].push_back(pTextureInfo);
	}

	return E_NOTIMPL;
}

const TEXTURE_INFO* CMultiTexture::getTextureInfo(
	const wstring &wstrStateKey /*= L""*/,
	const int &index /*= 0*/)
{
	auto iterFind = m_mapMultiTexture.find(wstrStateKey);

	if (iterFind == m_mapMultiTexture.end())
		return nullptr;

	return iterFind->second[index];
}
