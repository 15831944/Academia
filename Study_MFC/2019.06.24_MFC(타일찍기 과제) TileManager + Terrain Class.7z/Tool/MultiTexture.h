#pragma once
#ifndef _MULTI_TEXTURE_H_
#define _MULTI_TEXTURE_H_

#include "Texture.h"

class CMultiTexture : public CTexture
{
public:
	CMultiTexture();
	virtual ~CMultiTexture();

public:
	// Texture��(��) ���� ��ӵ�
	virtual void Release() override;

public:
	virtual HRESULT LoadTexture(
		const wstring &wstrFilePath,
		const wstring &wstrStateKey = L"",
		const int &count = 0
	) override;

public:
	virtual const TEXTURE_INFO* getTextureInfo(
		const wstring &wstrStateKey = L"",
		const int &index = 0
	) override;

private:
	// ################################################################
	typedef vector<TEXTURE_INFO *>					VEC_TEXTRUE_INFO;
	typedef map<const wstring, VEC_TEXTRUE_INFO>	MAP_MULTITEXTURE; // ���� Ű�� ������ �� ?!?!?!
	MAP_MULTITEXTURE	m_mapMultiTexture;
	// ################################################################
};

#endif