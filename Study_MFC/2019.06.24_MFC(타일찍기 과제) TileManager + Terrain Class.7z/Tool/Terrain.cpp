#include "stdafx.h"
#include "Terrain.h"


CTerrain::CTerrain()
{
}


CTerrain::~CTerrain()
{
	Release();
}

void CTerrain::Render()
{
	D3DXMATRIX matScale, matTrans, matWorld;

	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		D3DXMatrixScaling(&matScale, m_vecTile[i]->vSize.x, m_vecTile[i]->vSize.y, 0.0f);
		D3DXMatrixTranslation(&matTrans, m_vecTile[i]->vPos.x, m_vecTile[i]->vPos.y, 0.0f);

		matWorld = matScale * matTrans;

		CDeviceManager::getInstance()->getSprite()->SetTransform(&matWorld);

		const TEXTURE_INFO *pTextureInfo = CTextureManager::getInstance()->getTextureInfo(
			L"Terrain", L"Tile", m_vecTile[i]->byDrawID
		);
		NULL_CHECK(pTextureInfo);

		float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
		float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

		CDeviceManager::getInstance()->getSprite()->Draw(
			pTextureInfo->pTexture,
			nullptr,
			&D3DXVECTOR3(centerX, centerY, 0.0f),
			nullptr,
			D3DCOLOR_ARGB(255, 255, 255, 255)
		);

	}
}

HRESULT CTerrain::Init()
{
	// 20 X 30 ���� Ÿ�Ͽ� �ش��ϴ� �޸� ������ �̸� ����.
	m_vecTile.reserve(TILE_X * TILE_Y);

	TILE_INFO *pTile = nullptr;

	for (int i = 0; i < TILE_Y; ++i)
	{
		for (int j = 0; j < TILE_X; ++j)
		{
			pTile = new TILE_INFO;
			ZeroMemory(pTile, sizeof(TILE_INFO));

			if (pTile != nullptr)
			{
				pTile->vPos.x = (j * TILESIZE_X) + (i % 2) * (TILESIZE_X * 0.5f);
				pTile->vPos.y = i * (TILESIZE_Y * 0.5f);

				pTile->vSize = { 1.0f, 1.0f, 0.0f };

				pTile->byDrawID = 9; // Default
				pTile->byOption = 0;

				m_vecTile.push_back(pTile);
			}
		}
	}

	return S_OK;
}

void CTerrain::Release()
{
	// ################################################
	for_each(m_vecTile.begin(), m_vecTile.end(), SafeDelete<TILE_INFO *>);

	m_vecTile.clear();
	m_vecTile.shrink_to_fit();
}

void CTerrain::ChangeTile(const D3DXVECTOR3 &vPos,
	const BYTE &byDrawID,
	const BYTE &byOption)
{
	int index = GetTileIndex(vPos);

	if (index < 0 || (size_t)index >= m_vecTile.size())
	{
		return;
	}

	m_vecTile[index]->byDrawID = byDrawID;
	m_vecTile[index]->byOption = byOption;
}

int CTerrain::GetTileIndex(const D3DXVECTOR3 &vPos)
{
	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		if (IsPiking(vPos, i))
		{
			return (int)i;
		}
	}

	// ���� ��, -1 ��ȯ.
	return -1;
}

bool CTerrain::IsPiking(const D3DXVECTOR3 &vPos, size_t index)
{
	// Linear Equation
	// y = a * x + b
	// 0 = a * x + b - y ���·� �ٲ� �� �ִ�.
	// ���ϴ� ��ǥ (x, y)�� �Է� �޾��� ��...
	// ############################################
	// Cartesian Coordinate ����
	// ############################################
	// "0"�� ����	: ������ ������.  ex. 0 = x - y (=> y = x)
	// "0"���� ŭ	: �Ʒ��� ��ġ��.
	// "0"���� ����	: ���� ��ġ��. 
	// #############################################
	// ��ǥ�� �����̴� ���� �ƴϱ� ������, ���ϴ� ������ ����ȴ�.
	// - Window ��ǥ�� Cartesian ��ǥ��� X-Axis ��Ī !!!!
	//  (Symmetry about the X-Axis)
	// #############################################

	// Gradient ����
	// 0 1
	// 3 2

	// Vertex ����
	//   0
	// 3   1
	//   2

	float gradient[4] = {
		(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		-(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		-(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
	};

	D3DXVECTOR3 vVertex[4] = {
		{ m_vecTile[index]->vPos.x, m_vecTile[index]->vPos.y + TILESIZE_Y * 0.5f, 0.0f }, // 12��
		{ m_vecTile[index]->vPos.x + TILESIZE_X * 0.5f, m_vecTile[index]->vPos.y, 0.0f }, // 03��
		{ m_vecTile[index]->vPos.x, m_vecTile[index]->vPos.y - TILESIZE_Y * 0.5f, 0.0f }, // 06��
		{ -m_vecTile[index]->vPos.x - TILESIZE_X * 0.5f, m_vecTile[index]->vPos.y, 0.0f }	// 09��
	};


	// 0 = a * x + b - y
	// b = y - a * x

	float b[4] = {
		vVertex[0].y - gradient[0] * vVertex[0].x,
		vVertex[1].y - gradient[1] * vVertex[1].x,
		vVertex[2].y - gradient[2] * vVertex[2].x,
		vVertex[3].y - gradient[3] * vVertex[3].x
	};


	return (gradient[0] * vPos.x + b[0] - vPos.y > 0
		&& gradient[1] * vPos.x + b[1] - vPos.y > 0
		&& gradient[2] * vPos.x + b[2] - vPos.y < 0
		&& gradient[3] * vPos.x + b[3] - vPos.y < 0);
}

CTerrain * CTerrain::Create()
{
	CTerrain *pInstance = new CTerrain;

	// Ÿ�� ������ �����ϸ� �ƿ� �޸� ��������� "nullptr" ��ȯ.
	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
