#pragma once
#ifndef _TERRAIN_H_
#define _TERRAIN_H_

class CTerrain
{
private:
	explicit CTerrain();

public:
	~CTerrain();

public:
	void Render();

private:
	HRESULT Init();
	void Release();

public:
	void ChangeTile(
		const D3DXVECTOR3 &vPos,
		const BYTE &byDrawID,
		const BYTE &byOption = 0
	);

private:
	int GetTileIndex(const D3DXVECTOR3 &vPos);
	bool IsPiking(const D3DXVECTOR3 &vPos, size_t index);

public:
	static CTerrain* Create();

private:
	vector<TILE_INFO *> m_vecTile;

};

#endif