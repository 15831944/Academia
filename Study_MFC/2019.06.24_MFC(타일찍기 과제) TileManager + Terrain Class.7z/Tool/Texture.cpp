#include "stdafx.h"
#include "Texture.h"


CTexture::CTexture()
{
}


CTexture::~CTexture()
{
}
