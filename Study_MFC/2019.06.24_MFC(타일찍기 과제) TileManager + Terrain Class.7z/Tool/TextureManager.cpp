#include "stdafx.h"

#include "SingleTexture.h"
#include "MultiTexture.h"

#include "TextureManager.h"

IMPLEMENT_SINGLETON(CTextureManager)

CTextureManager::CTextureManager()
{
}

CTextureManager::~CTextureManager()
{
	Release();
}

void CTextureManager::Release()
{
	for (auto &MyPair : m_mapTexture)
	{
		SafeDelete(MyPair.second);
	}

	m_mapTexture.clear();
}

HRESULT CTextureManager::LoadTexture(
	TEXTURE_TYPE eTextureType,
	const wstring &wstrFilePath,
	const wstring &wstrObjectKey,
	const wstring &wstrStateKey,
	const int &count)
{
	CTexture *pTexture = nullptr;

	auto iterFind = m_mapTexture.find(wstrObjectKey);

	switch (eTextureType)
	{
	case CTextureManager::SINGLE_TEXTURE:
		// Single Texture�� Object Ű�� ������ ����!!!
		if (iterFind != m_mapTexture.end())
			return E_FAIL;

		pTexture = new CSingleTexture;
		m_mapTexture[wstrObjectKey] = pTexture;
		break;

	case CTextureManager::MULTI_TEXTURE:
		// MultiTexture�� Object Ű�� ������ ���ʷ� �� �� ����
		if (iterFind == m_mapTexture.end())
		{
			pTexture = new CMultiTexture;
			m_mapTexture[wstrObjectKey] = pTexture;
		}
		break;

	default:
		break;
	}

	m_mapTexture[wstrObjectKey]->LoadTexture(wstrFilePath, wstrStateKey, count);

	return S_OK;
}

const TEXTURE_INFO* CTextureManager::getTextureInfo(
	const wstring &wstrObjectKey,
	const wstring &wstrStateKey,
	const int &index)
{
	auto iterFind = m_mapTexture.find(wstrObjectKey);

	if (iterFind == m_mapTexture.end())
		return nullptr;

	return iterFind->second->getTextureInfo(wstrStateKey, index);
}
