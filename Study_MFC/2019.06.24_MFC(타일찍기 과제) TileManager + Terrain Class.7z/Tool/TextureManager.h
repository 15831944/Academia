#pragma once
#ifndef _TEXTURE_MANAGER_H_
#define _TEXTURE_MANAGER_H_

class CTexture;

class CTextureManager
{
	DECLARE_SINGLETON(CTextureManager)

private:
	CTextureManager();
	~CTextureManager();

public:
	enum TEXTURE_TYPE { SINGLE_TEXTURE, MULTI_TEXTURE };

public:
	void Release();

public:
	HRESULT LoadTexture(
		TEXTURE_TYPE eTextureType,
		const wstring &wstrFilePath,
		const wstring &wstrObjectKey,
		const wstring &wstrStateKey = L"",
		const int &count = 0
	);

public:
	const TEXTURE_INFO* getTextureInfo(
		const wstring &wstrObjectKey,
		const wstring &wstrStateKey = L"",
		const int &index = 0
	);

private:
	map<const wstring, CTexture *> m_mapTexture;
};

#endif