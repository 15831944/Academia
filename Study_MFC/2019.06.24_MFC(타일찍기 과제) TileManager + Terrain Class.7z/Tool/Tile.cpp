#include "stdafx.h"
#include "Tile.h"


CTile::CTile()
	: mpTexture(nullptr), mIndex(9)
{
	ZeroMemory(&mvPos, sizeof(mvPos));
}

CTile::CTile(float x, float y, int index)
	: mvPos(x, y, 0.0f), mIndex(index)
{
}


CTile::~CTile()
{
	Release();
}

void CTile::Init()
{
}

void CTile::Render()
{
	const TEXTURE_INFO *pTextureInfo = CTextureManager::getInstance()->getTextureInfo(
		L"Terrain", L"Tile", mIndex
	);

	float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

	D3DXMATRIX matScale, matRotZ, matTrans, matWorld;
	D3DXMatrixScaling(&matScale, 1.0f, 1.0f, 0.0f);
	D3DXMatrixRotationZ(&matRotZ, D3DXToRadian(-0.0f));
	D3DXMatrixTranslation(&matTrans, mvPos.x, mvPos.y, 0.0f);

	matWorld = matScale * matRotZ * matTrans;

	CDeviceManager::getInstance()->getSprite()->SetTransform(&matWorld);
	CDeviceManager::getInstance()->getSprite()->Draw(
		pTextureInfo->pTexture, // Texture COM ��ü�� �ּ�
		nullptr, // RECT ��ü�� ������
		&D3DXVECTOR3(centerX, centerY, 0.0f), // Center
		nullptr, // Position
		D3DCOLOR_ARGB(255, 255, 255, 255) // 100% ������ ����ϴ� ���� �ǹ��մϴ�.
	);

}

void CTile::Release()
{
}

CTile * CTile::Create(float x, float y, int index)
{
	CTile *pTile = new CTile(x, y, index);
	return pTile;
}
