#pragma once
#ifndef _TILE_H_
#define _TILE_H_

class CTexture;

class CTile
{
private:
	CTile();
	CTile(float x, float y, int index);

public:
	~CTile();

public:
	void Init();
	void Render();

private:
	void Release();

public:
	static CTile* Create(float x, float y, int index);

public:
	void SetPosition(float x, float y) { mvPos.x = x, mvPos.y = y; }
	void setIndex(int index) { mIndex = index; }

private:
	D3DXVECTOR3 mvPos;

	CTexture *mpTexture;
	int mIndex;

};

#endif