#include "stdafx.h"

#include "Tile.h"

#include "TileManager.h"

IMPLEMENT_SINGLETON(CTileManager)

CTileManager::CTileManager()
{
}


CTileManager::~CTileManager()
{
	Release();
}

void CTileManager::Init()
{
	for (int i = 0; i < 7; ++i)
	{
		for (int j = 0; j < 20; ++j)
		{
			if (j % 2 == 0)
			{
				CTile *pTile = CTile::Create((float)TILESIZE_X * i, (float)TILESIZE_Y / 2.0f * j, 9);
				if (pTile != nullptr)
				{
					m_vecTile.push_back(pTile);
				}
			}
			else
			{
				CTile *pTile = CTile::Create((float)TILESIZE_X * i + TILESIZE_X / 2.0f, (float)TILESIZE_Y / 2.0f * j, 9);
				if (pTile != nullptr)
				{
					m_vecTile.push_back(pTile);
				}
			}

		}
	}
}

void CTileManager::Render()
{
	vector<CTile *>::iterator iter = m_vecTile.begin();
	for (; iter != m_vecTile.end(); ++iter)
	{
		(*iter)->Render();
	}
}

void CTileManager::Release()
{
	vector<CTile *>::iterator iter = m_vecTile.begin();
	for (; iter != m_vecTile.end(); ++iter)
	{
		SafeDelete(*iter);
	}
	m_vecTile.clear();
	m_vecTile.shrink_to_fit();
}
