#pragma once
#ifndef _TILE_MANAGER_H_
#define _TILE_MANAGER_H_

class CTile;

class CTileManager
{
	DECLARE_SINGLETON(CTileManager)

private:
	CTileManager();
	~CTileManager();

public:
	void Init();
	void Render();
	void Release();

private:
	vector<CTile *> m_vecTile;
};

#endif