#pragma once
#ifndef _STRUCT_H_
#define _STRUCT_H_

typedef struct tagTextureInfo
{
	LPDIRECT3DTEXTURE9 pTexture;
	D3DXIMAGE_INFO tImageInfo;
} TEXTURE_INFO;

typedef struct tagTileInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vSize;

	BYTE byDrawID;
	BYTE byOption;

} TILE_INFO;

#endif