#pragma once
#include "afxwin.h"
#ifndef _MAP_TOOL_H_
#define _MAP_TOOL_H_

// CMapTool ��ȭ �����Դϴ�.
class CToolView;

class CMapTool : public CDialog
{
	DECLARE_DYNAMIC(CMapTool)

public:
	CMapTool(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CMapTool();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MAPTOOL };
#endif

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public: // Message Function
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnLbnSelchangePicking();
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedLoad();


public: // Control Function
	CListBox m_ListBox;

	map<const CString, BYTE> m_mapTileList;

	CToolView *m_pToolView;
};

#endif