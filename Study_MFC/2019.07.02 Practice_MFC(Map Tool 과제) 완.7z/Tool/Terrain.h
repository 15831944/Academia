#pragma once
#ifndef _TERRAIN_H_
#define _TERRAIN_H_

class CToolView;

class CTerrain
{
private:
	explicit CTerrain();

public:
	~CTerrain();

public:
	void Render() const;
	void RenderMiniView() const;

private:
	HRESULT Init();
	void Release();


public:
	void ChangeTile(
		const D3DXVECTOR3 &vPos,
		const BYTE &byDrawID,
		const BYTE &byOption = 0
	);

	void SaveTileData(LPCWSTR filePath) const;
	void LoadTileData(LPCWSTR filePath);

private:
	int GetTileIndex(const D3DXVECTOR3 &vPos);
	bool IsPicking(const D3DXVECTOR3 &vPos, size_t index);
	bool IsPickingWithScalar(const D3DXVECTOR3 &vPos, size_t index);

public:
	void setToolView(CToolView *pToolView) { m_pToolView = pToolView; }

public:
	static CTerrain* Create(CToolView *pToolView);


private:
	vector<TILE_INFO *> m_vecTile;

	CToolView *m_pToolView;
};

#endif