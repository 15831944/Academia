#pragma once
#ifndef _ENUM_H_
#define _ENUM_H_

namespace KEYSET
{
	enum TYPE {
		LEFT,
		RIGHT,
		UP,
		DOWN,
		ATTACK,
		NUM1,
		NUM2,
		NUM3,
		NUM4,
		END
	};
}

#endif