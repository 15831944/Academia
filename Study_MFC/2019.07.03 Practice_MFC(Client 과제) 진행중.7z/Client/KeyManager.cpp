#include "stdafx.h"
#include "KeyManager.h"

IMPLEMENT_SINGLETON(CKeyManager);

CKeyManager::CKeyManager()
{
	Init();
}


CKeyManager::~CKeyManager()
{
	Release();
}

void CKeyManager::Init()
{
	m_mapKeyMapping.emplace(KEYSET::LEFT, 'A');
	m_mapKeyState.emplace('A', false);
	m_mapKeyMapping.emplace(KEYSET::RIGHT, 'D');
	m_mapKeyState.emplace('D', false);

	m_mapKeyMapping.emplace(KEYSET::UP, 'W');
	m_mapKeyState.emplace('W', false);
	m_mapKeyMapping.emplace(KEYSET::DOWN, 'S');
	m_mapKeyState.emplace('S', false);

	m_mapKeyMapping.emplace(KEYSET::ATTACK, 'F');
	m_mapKeyState.emplace('F', false);


	m_mapKeyMapping.emplace(KEYSET::NUM1, '1');
	m_mapKeyState.emplace('1', false);
	m_mapKeyMapping.emplace(KEYSET::NUM2, '2');
	m_mapKeyState.emplace('2', false);
	m_mapKeyMapping.emplace(KEYSET::NUM3, '3');
	m_mapKeyState.emplace('3', false);
	m_mapKeyMapping.emplace(KEYSET::NUM4, '4');
	m_mapKeyState.emplace('4', false);
}

void CKeyManager::Release()
{
	m_mapKeyMapping.clear();
	m_mapKeyState.clear();
}

bool CKeyManager::IsKeyDown(KEYSET::TYPE eKeyType)
{
	if (!(m_mapKeyState[m_mapKeyMapping[eKeyType]])
		&& (GetAsyncKeyState(m_mapKeyMapping[eKeyType]) & 0x8000))
	{
		m_mapKeyState[m_mapKeyMapping[eKeyType]] = true;
		return true;
	}

	return false;
}

bool CKeyManager::IsKeyUp(KEYSET::TYPE eKeyType)
{
	if (m_mapKeyState[m_mapKeyMapping[eKeyType]]
		&& !(GetAsyncKeyState(m_mapKeyMapping[eKeyType]) & 0x8000))
	{
		m_mapKeyState[m_mapKeyMapping[eKeyType]] = false;
		return true;
	}
	return false;
}

bool CKeyManager::IsKeyPressing(KEYSET::TYPE eKeyType)
{
	if (GetAsyncKeyState(m_mapKeyMapping[eKeyType]) & 0x8000)
	{
		m_mapKeyState[m_mapKeyMapping[eKeyType]] = true;
		return true;
	}
	return false;
}

bool CKeyManager::IsNotAnyKeyPressed()
{
	map<KEYSET::TYPE, int>::iterator iter = m_mapKeyMapping.begin();
	for (; iter != m_mapKeyMapping.end(); ++iter)
	{
		if (m_mapKeyState[iter->second])
		{
			return false;
		}
	}
	return true;
}

void CKeyManager::UpdateKeyState()
{
	map<KEYSET::TYPE, int>::iterator iter = m_mapKeyMapping.begin();
	for (; iter != m_mapKeyMapping.end(); ++iter)
	{
		if (m_mapKeyState[iter->second]
			&& !(GetAsyncKeyState(iter->second) & 0x8000))
		{
			m_mapKeyState[iter->second] = false;
		}
	}
}
