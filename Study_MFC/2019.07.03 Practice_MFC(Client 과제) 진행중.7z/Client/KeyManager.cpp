#include "stdafx.h"
#include "KeyManager.h"

IMPLEMENT_SINGLETON(CKeyManager);

CKeyManager::CKeyManager()
{
}


CKeyManager::~CKeyManager()
{
}
