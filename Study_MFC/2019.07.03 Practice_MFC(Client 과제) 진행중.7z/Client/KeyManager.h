#pragma once
#ifndef _KEY_MANAGER_H_
#define _KEY_MANAGER_H_

class CKeyManager
{
	DECLARE_SINGLETON(CKeyManager);

private:
	CKeyManager();
	~CKeyManager();

private:
	void Release();

public:
	bool IsKeyDown();
	bool IsKeyUp();
	bool IsKeyPressing();

private:
	void UpdateKeyState();

private:

};

#endif