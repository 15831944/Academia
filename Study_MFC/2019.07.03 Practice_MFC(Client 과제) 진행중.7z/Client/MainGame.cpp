#include "stdafx.h"
#include "MainGame.h"


CMainGame::CMainGame()
	: m_pDeviceManager(CDeviceManager::getInstance()),
	m_pTextureManager(CTextureManager::getInstance())
{
}


CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Update()
{
}

void CMainGame::LateUpdate()
{
}

void CMainGame::Render()
{
	m_pDeviceManager->RenderBegin();

	m_pDeviceManager->RenderEnd();
}

HRESULT CMainGame::Init()
{
	return E_NOTIMPL;
}

void CMainGame::Release()
{
}

CMainGame * CMainGame::Create()
{
	return nullptr;
}
