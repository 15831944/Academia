#include "stdafx.h"

#include "Player.h"
#include "Terrain.h"

#include "MainGame.h"


CMainGame::CMainGame()
	: m_pDeviceManager(CDeviceManager::getInstance()),
	m_pKeyManager(CKeyManager::getInstance()),
	m_pTextureManager(CTextureManager::getInstance()),
	m_pPlayer(nullptr)//, m_pTerrain(nullptr)
{
}


CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Update()
{
	m_pPlayer->Update();

}

void CMainGame::LateUpdate()
{
	m_pPlayer->LateUpdate();

	m_pKeyManager->UpdateKeyState();
}

void CMainGame::Render()
{
	m_pDeviceManager->RenderBegin();

	m_pTerrain->Render();
	m_pPlayer->Render();

	m_pDeviceManager->RenderEnd(g_hWnd);
}

HRESULT CMainGame::Init()
{
	m_pDeviceManager->InitDevice(g_hWnd, WINSIZE_X, WINSIZE_Y, CDeviceManager::SCREEN_TYPE::WINDOWED);
	
	m_pPlayer = CPlayer::Create();
	m_pTerrain = CTerrain::Create();
	
	return S_OK;
}

void CMainGame::Release()
{
	SafeDelete(m_pTerrain);
	SafeDelete(m_pPlayer);

	CKeyManager::DestroyInstance();
	CTextureManager::DestroyInstance();
	CDeviceManager::DestroyInstance();
}

CMainGame * CMainGame::Create()
{
	CMainGame *pInstance = new CMainGame;
	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
