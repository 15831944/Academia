#pragma once
#ifndef _MAIN_GAME_H_
#define _MAIN_GAME_H_

class CDeviceManager;
class CTextureManager;

class CMainGame
{
private:
	explicit CMainGame();

public:
	~CMainGame();

public:
	void Update();
	void LateUpdate();
	void Render();

private:
	HRESULT Init();
	void Release();

public:
	static CMainGame* Create();

private:
	CDeviceManager *m_pDeviceManager;
	CTextureManager *m_pTextureManager;
};

#endif