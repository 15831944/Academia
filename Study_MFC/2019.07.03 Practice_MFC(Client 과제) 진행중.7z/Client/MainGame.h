#pragma once
#ifndef _MAIN_GAME_H_
#define _MAIN_GAME_H_

class CDeviceManager;
class CTextureManager;

class CPlayer;
class CTerrain;

class CMainGame
{
private:
	explicit CMainGame();

public:
	~CMainGame();

public:
	void Update();
	void LateUpdate();
	void Render();

private:
	HRESULT Init();
	void Release();

public:
	static CMainGame* Create();

private:
	CPlayer *m_pPlayer;
	CTerrain *m_pTerrain;

	CDeviceManager *m_pDeviceManager;
	CKeyManager *m_pKeyManager;
	CTextureManager *m_pTextureManager;
};

#endif