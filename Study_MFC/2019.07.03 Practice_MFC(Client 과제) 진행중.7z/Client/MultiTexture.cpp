#include "stdafx.h"
#include "MultiTexture.h"


CMultiTexture::CMultiTexture()
{
}


CMultiTexture::~CMultiTexture()
{
	Release();
}

void CMultiTexture::Release()
{
	for (auto &MyPair : m_mapMultiTexture)
	{
		for (auto &pTextureInfo : MyPair.second)
		{
			pTextureInfo->pTexture->Release();
			SafeDelete(pTextureInfo);
		}
		MyPair.second.clear();
		MyPair.second.shrink_to_fit();
	}
	m_mapMultiTexture.clear();
}

HRESULT CMultiTexture::LoadTexture(
	const wstring &wstrFilePath,
	const wstring &wstrStateKey /*= L""*/,
	const int &count /*= 0*/)
{
	auto iterFind = m_mapMultiTexture.find(wstrStateKey);

	if (iterFind != m_mapMultiTexture.end())
	{
		//AfxMessageBox(L"�̹� �����ϴ� Texture�Դϴ�, CMultiTexture::LoadTexture()");
		return E_FAIL;
	}

	HRESULT hr = 0;

	TCHAR fileFullPath[MAX_STR] = L"";

	TEXTURE_INFO *pTextureInfo = nullptr;

	for (int i = 0; i < count; ++i)
	{
		swprintf_s(fileFullPath, wstrFilePath.c_str(), i);

		pTextureInfo = new TEXTURE_INFO;
		//NULL_CHECK_MSG_RETURN(pTextureInfo, L"TEXTURE_INFO memory allocation Failed, CMultiTexture::LoadTexture()", E_FAIL);
		ZeroMemory(pTextureInfo, sizeof(TEXTURE_INFO));

		hr = D3DXGetImageInfoFromFile(
			fileFullPath, &pTextureInfo->tImageInfo
		);

		//FAILED_CHECK_MSG_RETURN(hr, L"D3DXGetImageInfoFromFile Failed, CMultiTexture::LoadTexture()", E_FAIL);

		hr = D3DXCreateTextureFromFileEx(
			CDeviceManager::getInstance()->getDevice(),
			fileFullPath,
			pTextureInfo->tImageInfo.Width,
			pTextureInfo->tImageInfo.Height,
			pTextureInfo->tImageInfo.MipLevels,
			0,
			pTextureInfo->tImageInfo.Format,
			D3DPOOL_MANAGED,
			D3DX_DEFAULT,
			D3DX_DEFAULT,
			0,
			nullptr,
			nullptr,
			&pTextureInfo->pTexture
		);

		//FAILED_CHECK_MSG_RETURN(hr, L"D3DXCreateTextureFromFileEx Failed, CMultiTexture::LoadTexture()", E_FAIL);

		m_mapMultiTexture[wstrStateKey].emplace_back(pTextureInfo);
	}

	return S_OK;
}

const TEXTURE_INFO* CMultiTexture::getTextureInfo(
	const wstring &wstrStateKey /*= L""*/,
	const int &index /*= 0*/)
{
	auto iterFind = m_mapMultiTexture.find(wstrStateKey);

	if (iterFind == m_mapMultiTexture.end())
	{
		return nullptr;
	}

	return iterFind->second[index];
}
