#pragma once
#ifndef _PLAYER_H_
#define _PLAYER_H_

class CMultiTexture;

class CPlayer
{
private:
	explicit CPlayer();

public:
	~CPlayer();

public:
	enum STATE {
		STAND,
		WALK,
		DASH,
		ATTACK,
		END
	};

public:
	int Update();
	void LateUpdate();
	void Render();

private:
	HRESULT Init();
	void Release();

public:


private:
	void MoveFrame();
	void ChangeScene();
	void AdjustFrame();

public:
	static CPlayer* Create();

private:
	INFO m_tInfo;
	FRAME m_tFrame;

	float m_fAngle;
	float m_fRotSpeed;
	float m_fSpeed;

	D3DXVECTOR3 m_vOrigin[4];
	D3DXVECTOR3 m_vConvert[4];

	STATE m_eCurrentState;
	STATE m_eNextState;

	CDeviceManager *m_pDeviceManager;
	CKeyManager *m_pKeyManager;
	CTextureManager *m_pTextureManager;

	bool m_bIsAttack;
	bool m_bIsDashing;
	bool m_bIsPossibleDash;

	float m_fDashCheckTime;
	DWORD m_dwDashCheckTime;
};

#endif