#pragma once
class CPlayer
{
public:
	CPlayer();
	~CPlayer();
};

