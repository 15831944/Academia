#include "stdafx.h"
#include "Terrain.h"

CTerrain::CTerrain()
	: m_pDeviceManager(CDeviceManager::getInstance()),
	m_pTextureManger(CTextureManager::getInstance())
{
}

CTerrain::~CTerrain()
{
	Release();
}

void CTerrain::Render() const
{
	D3DXMATRIX matScale, matTrans, matWorld;

	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		D3DXMatrixScaling(&matScale, m_vecTile[i]->vSize.x, m_vecTile[i]->vSize.y, 0.0f);
		D3DXMatrixTranslation(
			&matTrans,
			m_vecTile[i]->vPos.x,
			m_vecTile[i]->vPos.y,
			0.0f
		);

		matWorld = matScale * matTrans;

		const TEXTURE_INFO *pTextureInfo = m_pTextureManger->getTextureInfo(
			L"Terrain", L"Tile", m_vecTile[i]->byDrawID
		);

		float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
		float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

		m_pDeviceManager->getSprite()->SetTransform(&matWorld);
		m_pDeviceManager->getSprite()->Draw(
			pTextureInfo->pTexture,
			nullptr,
			&D3DXVECTOR3(centerX, centerY, 0.0f),
			nullptr,
			D3DCOLOR_ARGB(255, 255, 255, 255)
		);

	}
}

HRESULT CTerrain::Init()
{
	m_pTextureManger->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Terrain/Tile/Tile%d.png",
		L"Terrain", L"Tile", 38
	);

	for (int i = 0; i < TILE_Y; ++i)
	{
		for (int j = 0; j < TILE_X; ++j)
		{
			TILE_INFO *pTile = new TILE_INFO;
			NULL_CHECK_MSG_RETURN(pTile, L"TILE_INFO memory allocation Failed, CTerrain::Init()", E_FAIL);

			pTile->vPos.x = (j * TILESIZE_X) + (i % 2) * (TILESIZE_X * 0.5f);
			pTile->vPos.y = i * (TILESIZE_Y * 0.5f);
			pTile->vSize = { 1.0f, 1.0f, 0.0f };

			pTile->byDrawID = 9;
			pTile->byOption = 0;

			m_vecTile.emplace_back(pTile);
		}
	}

	return S_OK;
}


void CTerrain::Release()
{
	for_each(m_vecTile.begin(), m_vecTile.end(), SafeDelete<TILE_INFO *>);

	m_vecTile.clear();
	m_vecTile.shrink_to_fit();
}

HRESULT CTerrain::LoadTile(const TCHAR *pFilePath)
{
	HANDLE hFile = CreateFile(
		pFilePath,
		GENERIC_READ,
		0,
		0,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		nullptr
	);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return E_FAIL;
	}

	if (!(m_vecTile.empty()))
	{
		Release();
	}

	DWORD dwByte = 0;
	TILE_INFO *pTileInfo = nullptr;
	TILE_INFO tReadTileInfo = {};

	while (true)
	{
		ReadFile(hFile, &tReadTileInfo, sizeof(TILE_INFO), &dwByte, nullptr);

		if (dwByte == 0)
		{
			break;
		}

		pTileInfo = new TILE_INFO(tReadTileInfo);
		m_vecTile.emplace_back(pTileInfo);
	}

	CloseHandle(hFile);

	return S_OK;
}


CTerrain* CTerrain::Create()
{
	CTerrain *pInstance = new CTerrain;

	if (FAILED(pInstance->Init()))
	{
		delete pInstance;
		return nullptr;
	}

	return pInstance;
}
