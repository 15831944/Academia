#pragma once
#ifndef _TERRAIN_H_
#define _TERRAIN_H_

class CTerrain
{
private:
	explicit CTerrain();

public:
	~CTerrain();

public:
	void Render() const;

private:
	HRESULT Init();
	void Release();

public:
	HRESULT LoadTile(const TCHAR *pFilePath);

public:
	static CTerrain* Create();


private:
	vector<TILE_INFO *> m_vecTile;

	CDeviceManager *m_pDeviceManager;
	CTextureManager *m_pTextureManger;
};

#endif