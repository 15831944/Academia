#pragma once
#ifndef _DEVICE_MANAGER_H_
#define _DEVICE_MANAGER_H_

class CDeviceManager
{
	DECLARE_SINGLETON(CDeviceManager);

private:
	CDeviceManager();
	~CDeviceManager();

public:
	enum SCREEN_TYPE {
		FULLSCREEN,
		WINDOWED
	};

private:
	void Release();

public:
	HRESULT InitDevice(
		HWND hWnd,
		const DWORD &dwWinWidth, const DWORD &dwWinHeight,
		SCREEN_TYPE eScreenType
	);

	void RenderBegin();
	void RenderEnd(HWND hWnd);

public:
	LPDIRECT3DDEVICE9 getDevice() const { return m_pGraphicDev; }
	LPD3DXSPRITE getSprite() const { return m_pSprite; }
	LPD3DXFONT getFont() const { return m_pFont; }

private:
	LPDIRECT3D9				m_pSDK;
	LPDIRECT3DDEVICE9		m_pGraphicDev;
	LPD3DXSPRITE			m_pSprite;
	LPD3DXFONT				m_pFont;

};

#endif