#pragma once
#ifndef _OBJ_H_
#define _OBJ_H_

class CObj
{
protected:
	explicit CObj();

public:
	virtual ~CObj();

public:
	virtual int Update() PURE;
	virtual void LateUpdate() PURE;
	virtual void Render() PURE;

protected:
	virtual HRESULT Init() PURE;
	virtual HRESULT LateInit();
	virtual void Release() PURE;

protected:
	bool m_bIsInit;

	CDeviceManager *m_pDeviceManager;
	CTextureManager *m_pTextureManager;
	CTimeManager *m_pTimeManager;
};

#endif