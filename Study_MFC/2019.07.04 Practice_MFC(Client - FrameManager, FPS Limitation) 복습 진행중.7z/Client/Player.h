#pragma once
#ifndef _PLAYER_H_
#define _PLYAER_H_

#include "Obj.h"

class CPlayer : public CObj
{
public:
	CPlayer();
	virtual ~CPlayer();

public:
	// CObj��(��) ���� ��ӵ�
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render() override;

private:
	virtual HRESULT Init() override;
	virtual HRESULT LateInit() override;
	virtual void Release() override;

public:
	static CPlayer* Create();

private:
	void MoveFrame(float fSpeed = 1.0f);

private:
	INFO m_tInfo;
	FRAME m_tFrame;
};

#endif