#include "stdafx.h"

#include "MultiTexture.h"

#include "Player2.h"


CPlayer2::CPlayer2()
	: m_fAngle(0.0f), m_fRotSpeed(5.0f), m_fSpeed(5.0f),
	m_pDeviceManager(CDeviceManager::getInstance()),
	m_pKeyManager(CKeyManager::getInstance()),
	m_pTextureManager(CTextureManager::getInstance()),
	m_bIsAttack(false), m_bIsDashing(false), m_iDashCheckCount(0)
{
	ZeroMemory(&m_tInfo, sizeof(INFO));
	//ZeroMemory(&m_tFrame, sizeof(FRAME));
	ZeroMemory(m_vOrigin, sizeof(m_vOrigin));
	ZeroMemory(m_vConvert, sizeof(m_vConvert));
}


CPlayer2::~CPlayer2()
{
	Release();
}

int CPlayer2::Update()
{
	if (m_pKeyManager->IsKeyPressing(KEYSET::LEFT))
	{
		m_tInfo.vDir = { -1.0f, 0.0f, 0.0f };
		m_tInfo.vSize = { -1.0f, 1.0f, 0.0f };
		m_tInfo.vPos += m_tInfo.vDir * m_fSpeed;
		m_eNextState = STATE::WALK;
	}
	if (m_pKeyManager->IsKeyPressing(KEYSET::RIGHT))
	{
		m_tInfo.vDir = { 1.0f, 0.0f, 0.0f };
		m_tInfo.vSize = { 1.0f, 1.0f, 0.0f };
		m_tInfo.vPos += m_tInfo.vDir * m_fSpeed;
		m_eNextState = STATE::WALK;
	}

	if (m_pKeyManager->IsKeyPressing(KEYSET::UP))
	{
		m_tInfo.vDir = { 0.0f, -1.0f, 0.0f };
		m_tInfo.vPos += m_tInfo.vDir * m_fSpeed;
		m_eNextState = STATE::WALK;
	}
	if (m_pKeyManager->IsKeyPressing(KEYSET::DOWN))
	{
		m_tInfo.vDir = { 0.0f, 1.0f, 0.0f };
		m_tInfo.vPos += m_tInfo.vDir * m_fSpeed;
		m_eNextState = STATE::WALK;
	}

	/*if (m_pKeyManager->IsKeyDown(KEYSET::V))
	{
		m_iDashCheckCount = 1;
		cout << "Dash Down" << endl;
		m_dwDashCheckTime = GetTickCount();
	}*/

	if (!(m_bIsDashing)
		&& m_pKeyManager->IsKeyDown(KEYSET::V))
	{
		cout << "DOWN" << endl;
		++m_iDashCheckCount;
		m_dwDashCheckTime = GetTickCount();
	}
	else if (m_pKeyManager->IsKeyPressing(KEYSET::V))
	{
		cout << "Pressing" << endl;
		if (m_dwDashCheckTime + 100 < GetTickCount())
		{
			if (m_iDashCheckCount == 2)
			{
				m_bIsDashing = true;
			}
		}

		if (m_bIsDashing)
		{
			m_eNextState = STATE::DASH;
			cout << "DAHSH" << endl;
		}
		else
		{
			cout << "WALK" << endl;
			m_eNextState = STATE::WALK;
		}
	}
	else if (m_dwDashCheckTime + 200 < GetTickCount())
	{
		m_iDashCheckCount = 0;
	}



	cout << m_iDashCheckCount << endl;


	if (m_pKeyManager->IsKeyDown(KEYSET::ATTACK))
	{
		m_eNextState = STATE::ATTACK;

		m_bIsAttack = true;

	}


	if (m_pKeyManager->IsKeyDown(KEYSET::NUM1))
	{
		m_eNextState = STATE::STAND;
	}
	if (m_pKeyManager->IsKeyDown(KEYSET::NUM2))
	{
		m_eNextState = STATE::WALK;
	}
	if (m_pKeyManager->IsKeyDown(KEYSET::NUM3))
	{
		m_eNextState = STATE::DASH;
	}
	if (m_pKeyManager->IsKeyDown(KEYSET::NUM4))
	{
		m_eNextState = STATE::ATTACK;
	}


	if (m_pKeyManager->IsNotAnyKeyPressed()
		&& !(m_bIsAttack))
	{
		m_eNextState = STATE::STAND;
		//m_bIsDashing = false;
		//m_bIsPossibleDash = true;
		if (m_iDashCheckCount != 1)
		{
			m_iDashCheckCount = 0;
		}
		m_bIsDashing = false;
	}

	return 0;
}

void CPlayer2::LateUpdate()
{
	MoveFrame();
	AdjustFrame();
	ChangeScene();

}

void CPlayer2::Render()
{
	const TEXTURE_INFO *pTextureInfo = m_pTextureManager->getTextureInfo(
		m_tFrame.wstrObjectKey, m_tFrame.wstrStateKey, m_tFrame.frameStart
	);
	NULL_CHECK(pTextureInfo);

	D3DXMatrixScaling(&m_tInfo.matScale, m_tInfo.vSize.x, m_tInfo.vSize.y, 0.0f);
	D3DXMatrixTranslation(&m_tInfo.matTrans, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.0f);
	D3DXMatrixRotationZ(&m_tInfo.matRotZ, D3DXToRadian(-(m_fAngle)));

	m_tInfo.matWorld = m_tInfo.matScale * m_tInfo.matRotZ * m_tInfo.matTrans;

	float fCenterX = pTextureInfo->tImageInfo.Width * 0.5f;
	float fCenterY = pTextureInfo->tImageInfo.Height * 0.5f;

	m_pDeviceManager->getSprite()->SetTransform(&m_tInfo.matWorld);
	m_pDeviceManager->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,
		&D3DXVECTOR3(fCenterX, fCenterY, 0.0f),
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);
}

HRESULT CPlayer2::Init()
{
	m_tInfo.vPos = { 400.0f, 300.0f, 0.0f };
	m_tInfo.vDirOrigin = { 1.0f, 0.0f, 0.0f }; // ���� ����
	m_tInfo.vSize = { 1.0f, 1.0f, 0.0f };

	// Window Coordinate Origin ����
	m_vOrigin[0] = { -50.0f, -50.0f, 0.0f };	// LT
	m_vOrigin[1] = { 50.0f, -50.0f, 0.0f };		// RT
	m_vOrigin[2] = { 50.0f, 50.0f, 0.0f };		// RB
	m_vOrigin[3] = { -50.0f, 50.0f, 0.0f };		// LB

	m_fAngle = 0.0f;
	m_fRotSpeed = 5.0f;
	m_fSpeed = 5.0f;

	HRESULT hr = 0;

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Stand/AKIHA_AKI00_%03d.png",
		L"Player", L"Stand", 12
	);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Walk/AKIHA_AKI26_%03d.png",
		L"Player", L"Walk", 13
	);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Dash/AKIHA_AKI13_%03d.png",
		L"Player", L"Dash", 11
	);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Attack/AKIHA_AKI01_%03d.png",
		L"Player", L"Attack", 6
	);

	m_tFrame.wstrObjectKey = L"Player";
	m_tFrame.wstrStateKey = L"Stand";

	m_tFrame.frameStart = 0;
	m_tFrame.frameEnd = 11;
	m_tFrame.dwFrameSpeed = 100;
	m_tFrame.dwFrameTime = GetTickCount();

	m_eCurrentState = STATE::STAND;
	m_eNextState = STATE::STAND;

	m_iDashCheckCount = 0;
	m_dwDashCheckTime = GetTickCount();

	return S_OK;
}

void CPlayer2::Release()
{
	m_tFrame.wstrObjectKey.swap(wstring());
}

void CPlayer2::MoveFrame()
{
	if (m_tFrame.dwFrameTime + m_tFrame.dwFrameSpeed < GetTickCount())
	{
		++m_tFrame.frameStart;

		m_tFrame.dwFrameTime = GetTickCount();
	}

	if (m_tFrame.frameStart > m_tFrame.frameEnd)
	{
		m_tFrame.frameStart = 0;
	}
}

void CPlayer2::ChangeScene()
{
	if (m_eNextState != m_eCurrentState)
	{
		switch (m_eNextState)
		{
		case CPlayer2::STAND:
			m_tFrame.wstrStateKey = L"Stand";

			m_tFrame.frameStart = 0;
			m_tFrame.frameEnd = 11;
			m_tFrame.dwFrameSpeed = 100;
			m_tFrame.dwFrameTime = GetTickCount();
			break;

		case CPlayer2::WALK:
			m_tFrame.wstrStateKey = L"Walk";

			m_tFrame.frameStart = 0;
			m_tFrame.frameEnd = 12;
			m_tFrame.dwFrameSpeed = 50;
			m_tFrame.dwFrameTime = GetTickCount();
			break;

		case CPlayer2::DASH:
			m_tFrame.wstrStateKey = L"Dash";

			m_tFrame.frameStart = 0;
			m_tFrame.frameEnd = 9;
			////m_tFrame.frameEnd = 10; // ���⋚ ������ 9, 10��.
			m_tFrame.dwFrameSpeed = 100;
			m_tFrame.dwFrameTime = GetTickCount();
			break;

		case CPlayer2::ATTACK:
			m_tFrame.wstrStateKey = L"Attack";

			m_tFrame.frameStart = 0;
			m_tFrame.frameEnd = 5;
			m_tFrame.dwFrameSpeed = 80;
			m_tFrame.dwFrameTime = GetTickCount();
			break;

		default:
			break;
		}

		m_eCurrentState = m_eNextState;
	}
}

void CPlayer2::AdjustFrame()
{

	if (m_eCurrentState == STATE::WALK)
	{
		if (m_tFrame.frameStart == m_tFrame.frameEnd)
		{
			m_tFrame.frameStart = 1;

		}
	}
	else if (m_eCurrentState == STATE::DASH)
	{
		if (m_tFrame.frameStart == m_tFrame.frameEnd) // Dash ����
		{
			m_tFrame.frameStart = 6;
		}

		//if(m_eNextState == STATE::STAND) // ���� ��, ���� �ִϸ��̼�
		//{
		//	m_eNextState == STATE::DASH;
		//	m_tFrame.frameEnd = 10;
		//	if (m_tFrame.frameStart = m_tFrame.frameEnd)
		//	{
		//		m_eNextState = STATE::STAND;
		//	}
		//}
	}
	else if (m_eCurrentState == STATE::ATTACK)
	{
		if (m_tFrame.frameStart == m_tFrame.frameEnd)
		{
			m_eNextState = STATE::STAND;
			m_bIsAttack = false;
		}
	}

}

CPlayer2 * CPlayer2::Create()
{
	CPlayer2 *pInstance = new CPlayer2;
	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
