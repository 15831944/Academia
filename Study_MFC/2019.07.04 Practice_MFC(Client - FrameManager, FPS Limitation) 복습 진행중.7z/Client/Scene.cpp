#include "stdafx.h"
#include "Scene.h"


CScene::CScene()
	: m_pObjManager(CObjManager::getInstance()),
	m_pSceneManager(CSceneManager::getInstance())
{
}


CScene::~CScene()
{
}
