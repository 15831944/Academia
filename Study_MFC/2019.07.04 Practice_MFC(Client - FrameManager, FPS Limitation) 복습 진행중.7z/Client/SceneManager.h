#pragma once
#ifndef _SCENE_MANAGER_H_
#define _SCENE_MANAGER_H_

class CScene;

class CSceneManager
{
	DECLARE_SINGLETON(CSceneManager);

private:
	CSceneManager();
	~CSceneManager();

public:
	enum SCENE_TYPE {
		LOGO,
		STAGE,
		END
	};

public:
	void Update();
	void LateUpdate();
	void Render();

private:
	void Release();

public:
	HRESULT ChangeScene(SCENE_TYPE eSceneType);

private:
	CScene *m_pCurScene;	// ���� Scene

	SCENE_TYPE m_eCurSceneType;	 // ���� Scene type
	SCENE_TYPE m_eNextSceneType; // ���� Scene type
};

#endif