#pragma once
#ifndef _FILE_INFO_H_
#define _FILE_INFO_H_

class CFileInfo
{
private:
	CFileInfo();
	~CFileInfo();

public:
	static CString ConvertRelativePath(const CString strFileFullPath);
};

#endif