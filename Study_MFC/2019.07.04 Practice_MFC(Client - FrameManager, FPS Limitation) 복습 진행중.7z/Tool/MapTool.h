#pragma once
#include "afxwin.h"


// CMapTool ��ȭ �����Դϴ�.

class CMapTool : public CDialog
{
	DECLARE_DYNAMIC(CMapTool)

public:
	CMapTool(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CMapTool();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MAPTOOL };
#endif

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

public: // Message Function
	DECLARE_MESSAGE_MAP()
	afx_msg void OnDropFiles(HDROP hDropInfo); // Drag & Drop
	afx_msg void OnLbnSelchangeTileList();
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedLoad();


public:
	BYTE getDrawID() const { return m_byDrawID; }

private: // User Function
	void CreateHorizontalScrollBar();

private: // Control Variable
	CListBox m_ListBox;		// Tile List Box
	CStatic m_PictureCtrl;	// Tile Image Preview

private:
	BYTE m_byDrawID;

public:
};
