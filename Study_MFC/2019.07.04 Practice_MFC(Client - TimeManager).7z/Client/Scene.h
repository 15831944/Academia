#pragma once
#ifndef _SCENE_H_
#define _SCENE_H_

class CScene
{
protected:
	CScene();

public:
	virtual ~CScene();

public:
	virtual void Update() PURE;
	virtual void LateUpdate() PURE;
	virtual void Render() PURE;

protected:
	virtual HRESULT Init() PURE;
	virtual void Release() PURE;

protected:
	CObjManager *m_pObjManager;
	CSceneManager *m_pSceneManager;
};

#endif