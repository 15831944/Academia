#include "stdafx.h"

#include "ScrollManager.h"

#include "Terrain.h"

CTerrain::CTerrain()
{
}


CTerrain::~CTerrain()
{
	Release();
}

int CTerrain::Update()
{
	CObj::LateInit();

	// Simpe Scroll Example(���콺�� ���ؼ� ��ũ�� �����̱�)
	POINT pt = {};
	GetCursorPos(&pt);
	ScreenToClient(g_hWnd, &pt);

	float fDeltaTime = m_pTimeManager->getDeltaTime();

	if (pt.x < 0)
	{
		// ���콺�� ȭ�� �������� �̵� => "- Negative"  Scroll
		CScrollManager::MoveScrollPos(D3DXVECTOR3(-1.0f, 0.0f, 0.0f));
	}
	if (pt.x > WINSIZE_X)
	{
		// ���콺�� ȭ�� ���������� �̵� => "+ Positive" Scroll
		CScrollManager::MoveScrollPos(D3DXVECTOR3(1.0f, 0.0f, 0.0f));
	}


	if (pt.y < 0)
	{
		CScrollManager::MoveScrollPos(D3DXVECTOR3(0.0f, -1.0f, 0.0f));
	}
	if (pt.y > WINSIZE_Y)
	{
		CScrollManager::MoveScrollPos(D3DXVECTOR3(0.0f, 1.0f, 0.0f));
	}

	return OBJ_NOEVENT;
}

void CTerrain::LateUpdate()
{
}

void CTerrain::Render()
{
	D3DXMATRIX matScale, matTrans, matWorld;

	TCHAR szIndex[MIN_STR] = L"";

	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		D3DXMatrixScaling(&matScale,
			m_vecTile[i]->vSize.x,
			m_vecTile[i]->vSize.y,
			0.0f
		);
		D3DXMatrixTranslation(&matTrans,
			m_vecTile[i]->vPos.x - CScrollManager::GetScrollPos().x,
			m_vecTile[i]->vPos.y - CScrollManager::GetScrollPos().y,
			0.0f
		);
		// if) ȭ�� �������� ���콺�� �����ٰ� �����ϸ�...
		// - ����� Scroll�� X ��ǥ���� "- Negative"...
		// Terrain�� ���������� �̵��ؾ� �ϹǷ�... ������ �ݴ� !!!!
		// ���� ���콺(�÷��̾�)�� ����;� �Ѵٸ�, "+ Positive"�� Scroll ���� �����ش�.

		matWorld = matScale * matTrans;

		m_pDeviceManager->getSprite()->SetTransform(&matWorld);

		const TEXTURE_INFO *pTextureInfo = m_pTextureManager->getTextureInfo(
			L"Terrain", L"Tile", m_vecTile[i]->byDrawID
		);
		NULL_CHECK(pTextureInfo);

		float fCenterX = pTextureInfo->tImageInfo.Width * 0.5f;
		float fCenterY = pTextureInfo->tImageInfo.Height * 0.5f;

		m_pDeviceManager->getSprite()->Draw(
			pTextureInfo->pTexture,
			nullptr,
			&D3DXVECTOR3(fCenterX, fCenterY, 0.0f),
			nullptr,
			D3DCOLOR_ARGB(255, 255, 255, 255)
		);

	}
}

HRESULT CTerrain::Init()
{
	HRESULT hr = LoadTile(L"../Data/MapData.dat");
	FAILED_CHECK_MSG_RETURN(hr, L"MapData.dat Load Failed, CTerrain::Init()", E_FAIL);

	return S_OK;
}

HRESULT CTerrain::LateInit()
{
	return S_OK;
}

void CTerrain::Release()
{
	for_each(m_vecTile.begin(), m_vecTile.end(), SafeDelete<TILE_INFO *>);

	m_vecTile.clear();
	m_vecTile.shrink_to_fit();
}

HRESULT CTerrain::LoadTile(const TCHAR *pFilePath)
{
	HANDLE hFile = CreateFile(
		pFilePath,
		GENERIC_READ,
		0,
		0,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		nullptr
	);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return E_FAIL;
	}

	if (!(m_vecTile.empty()))
	{
		Release();
	}

	DWORD dwByte = 0;
	TILE_INFO *pTile = nullptr;
	TILE_INFO tReadTileInfo = {};

	while (true)
	{
		ReadFile(hFile, &tReadTileInfo, sizeof(TILE_INFO), &dwByte, nullptr);

		if (dwByte == 0)
		{
			break;
		}

		pTile = new TILE_INFO(tReadTileInfo);
		m_vecTile.emplace_back(pTile);
	}

	CloseHandle(hFile);

	return S_OK;
}

CTerrain* CTerrain::Create()
{
	CTerrain *pInstance = new CTerrain;

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}