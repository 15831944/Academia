#pragma once
#ifndef _STRUCT_H_
#define _STRUCT_H_

typedef struct tagTextureInfo
{
	LPDIRECT3DTEXTURE9 pTexture;
	D3DXIMAGE_INFO tImageInfo;
} TEXTURE_INFO;

typedef struct tagTileInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vSize;

	BYTE byDrawID;
	BYTE byOption;

} TILE_INFO;

typedef struct tagUnitData
{
	tagUnitData()
		: strName(L""),
		iAttackDamage(0), iDefense(0),
		iClassIndex(0), iItem(0)
	{

	}

#ifdef CLIENT
	wstring strName;
#else
	CString strName;
#endif
	int iAttackDamage;
	int iDefense;
	int iClassIndex;
	int iItem;

} UNIT_DATA;


typedef struct tagInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vDir;
	D3DXVECTOR3 vDirOrigin;
	D3DXVECTOR3 vSize;

	D3DXMATRIX matWorld;
	D3DXMATRIX matScale;
	D3DXMATRIX matRotZ;
	D3DXMATRIX matTrans;
} INFO;

typedef struct tagFrame
{
	/*tagFrame()
		: wstrObjectKey(L""), wstrStateKey(L""),
		frameStart(0), frameEnd(0),
		dwFrameSpeed(0), dwFrameTime(0)
	{

	}*/

	wstring wstrObjectKey;
	wstring wstrStateKey;

	int frameStart;
	int frameEnd;

	DWORD dwFrameSpeed;
	DWORD dwFrameTime;
} FRAME;

#endif