#pragma once
#include "afxwin.h"
#ifndef _MY_FORM_VIEW_H_
#define _MY_FORM_VIEW_H_


// ####################################################################################
// CMyFormView �� ���Դϴ�.
#include "UnitTool.h"
#include "MapTool.h"

class CMyFormView : public CFormView
{
	DECLARE_DYNCREATE(CMyFormView)

protected:
	CMyFormView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CMyFormView();

public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MYFORMVIEW };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif


// ####################################################################################

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual void OnInitialUpdate();

	DECLARE_MESSAGE_MAP()

public: // Message Function
	afx_msg void OnBnClickedUnitTool();
	afx_msg void OnBnClickedMapTool();

public: // User Function
	const CUnitTool& getUnitTool() const { return m_UnitTool; }
	const CMapTool& getMapTool() const { return m_MapTool; }

private:
	// MFC���� �����ϴ� Font ��ü
	CFont m_Font;

	CUnitTool m_UnitTool;
	CMapTool m_MapTool;
};

#endif