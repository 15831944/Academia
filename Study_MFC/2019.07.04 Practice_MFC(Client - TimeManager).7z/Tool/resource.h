//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Tool.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ToolTYPE                    130
#define IDD_MYFORMVIEW                  310
#define IDD_UNITTOOL                    311
#define IDD_MAPTOOL                     312
#define IDC_BUTTON1                     1000
#define IDC_EDIT1                       1001
#define IDC_BUTTON6                     1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_EDIT5                       1005
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1007
#define IDC_RADIO3                      1008
#define IDC_LIST1                       1009
#define IDC_BUTTON2                     1010
#define IDC_BUTTON3                     1011
#define IDC_BUTTON4                     1012
#define IDC_BUTTON5                     1013
#define IDC_EDIT6                       1014
#define IDC_PICTURECTRL                 1015
#define IDC_RADIO4                      1015
#define IDC_CHECK1                      1016
#define IDC_CHECK2                      1017
#define IDC_CHECK3                      1018
#define IDC_RADIO5                      1019
#define IDC_RADIO6                      1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           313
#endif
#endif
