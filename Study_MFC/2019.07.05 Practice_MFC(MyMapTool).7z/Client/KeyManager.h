#pragma once
#ifndef _KEY_MANAGER_H_
#define _KEY_MANAGER_H_

class CKeyManager
{
	DECLARE_SINGLETON(CKeyManager);

private:
	CKeyManager();
	~CKeyManager();

private:
	void Init();
	void Release();

public:
	bool IsKeyDown(KEYSET::TYPE eKeyType);
	bool IsKeyUp(KEYSET::TYPE eKeyType);
	bool IsKeyPressing(KEYSET::TYPE eKeyType);
	bool IsNotAnyKeyPressed();
	void UpdateKeyState();

private:
	map<KEYSET::TYPE, int> m_mapKeyMapping;
	map<int, bool> m_mapKeyState;

};

#endif