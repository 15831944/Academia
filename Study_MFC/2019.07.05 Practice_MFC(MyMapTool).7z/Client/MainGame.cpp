#include "stdafx.h"

#include "Player2.h"
#include "Terrain.h"

#include "MainGame.h"


CMainGame::CMainGame()
	: m_pDeviceManager(CDeviceManager::getInstance()),
	m_pKeyManager(CKeyManager::getInstance()),
	m_pObjManager(CObjManager::getInstance()),
	m_pTextureManager(CTextureManager::getInstance()),
	m_pTimeManager(CTimeManager::getInstance()),
	m_pSceneManager(CSceneManager::getInstance())
{
}


CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Update()
{
	// ####################################
	// �Ź� Frame���� �ɸ� �ð��� ���� !!!!
	// ####################################
	m_pTimeManager->UpdateTime();

	m_pSceneManager->Update();
}

void CMainGame::LateUpdate()
{
	m_pSceneManager->LateUpdate();

	m_pKeyManager->UpdateKeyState();
}

void CMainGame::Render()
{
	m_pDeviceManager->RenderBegin();

	m_pSceneManager->Render();

	m_pDeviceManager->RenderEnd(g_hWnd);
}

HRESULT CMainGame::Init()
{
	HRESULT hr = 0;
	
	hr = m_pDeviceManager->InitDevice(g_hWnd, WINSIZE_X, WINSIZE_Y, CDeviceManager::SCREEN_TYPE::WINDOWED);
	FAILED_CHECK_MSG_RETURN(hr, L"InitDevice() Failed, CMainGame::Init()", E_FAIL);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Terrain/Tile/Tile%d.png",
		L"Terrain", L"Tile", 40
	);
	FAILED_CHECK_MSG_RETURN(hr, L"Tile - LoadTexture() Failed, CMainGame::Init()", E_FAIL);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Stand/AKIHA_AKI00_%03d.png",
		L"Player", L"Stand", 12
	);
	FAILED_CHECK_MSG_RETURN(hr, L"Player Stand - LoadTexture() Failed, CMainGame::Init()", E_FAIL);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Walk/AKIHA_AKI26_%03d.png",
		L"Player", L"Walk", 13
	);
	FAILED_CHECK_MSG_RETURN(hr, L"Player Walk - LoadTexture() Failed, CMainGame::Init()", E_FAIL);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Dash/AKIHA_AKI13_%03d.png",
		L"Player", L"Dash", 11
	);
	FAILED_CHECK_MSG_RETURN(hr, L"Player Dash - LoadTexture() Failed, CMainGame::Init()", E_FAIL);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Attack/AKIHA_AKI01_%03d.png",
		L"Player", L"Attack", 6
	);
	FAILED_CHECK_MSG_RETURN(hr, L"Player Attack - LoadTexture() Failed, CMainGame::Init()", E_FAIL);

	hr = m_pTextureManager->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Player/Dancer/Dancer%d.png",
		L"Player", L"Dancer", 1
	);
	FAILED_CHECK_MSG_RETURN(hr, L"Player Danger - LoadTexture() Failed, CMainGame::Init()", E_FAIL);





	hr = m_pSceneManager->ChangeScene(CSceneManager::SCENE_TYPE::LOGO);
	FAILED_CHECK_MSG_RETURN(hr, L"Logo - ChangeScene() Failed, CMainGame::Init()", E_FAIL);

	return S_OK;
}

void CMainGame::Release()
{

	CTimeManager::DestroyInstance();
	CKeyManager::DestroyInstance();
	CObjManager::DestroyInstance();
	CSceneManager::DestroyInstance();

	// COM ��ü �Ҹ� ������, ���� ���Ѿ���
	CTextureManager::DestroyInstance();
	CDeviceManager::DestroyInstance();
}

CMainGame * CMainGame::Create()
{
	CMainGame *pInstance = new CMainGame;

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
