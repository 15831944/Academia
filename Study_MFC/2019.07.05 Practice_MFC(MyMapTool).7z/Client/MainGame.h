#pragma once
#ifndef _MAIN_GAME_H_
#define _MAIN_GAME_H_

class CDeviceManager;
class CTextureManager;

class CPlayer;
class CTerrain;

class CMainGame
{
private:
	explicit CMainGame();

public:
	~CMainGame();

public:
	void Update();
	void LateUpdate();
	void Render();

private:
	HRESULT Init();
	void Release();

public:
	static CMainGame* Create();

private:
	CDeviceManager		*m_pDeviceManager;
	CFrameManager		*m_pFrameManager;
	CKeyManager			*m_pKeyManager;
	CObjManager			*m_pObjManager;
	CTextureManager		*m_pTextureManager;
	CTimeManager		*m_pTimeManager;
	CSceneManager		*m_pSceneManager;
};

#endif