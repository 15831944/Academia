#include "stdafx.h"
#include "Obj.h"


CObj::CObj()
	: m_bIsInit(false),
	m_pDeviceManager(CDeviceManager::getInstance()),
	m_pTextureManager(CTextureManager::getInstance()),
	m_pTimeManager(CTimeManager::getInstance())
{
}


CObj::~CObj()
{
}

HRESULT CObj::LateInit()
{
	if (!(m_bIsInit))
	{
		this->LateInit();
		m_bIsInit = true;
	}
	return S_OK;
}
