#pragma once
#ifndef _OBJ_MANAGER_H_
#define _OBJ_MANAGER_H_

class CObj;

class CObjManager
{
	DECLARE_SINGLETON(CObjManager);

private:
	CObjManager();
	~CObjManager();

public:
	enum OBJ_TYPE {
		TERRAIN,
		PLAYER,
		MONSTER,
		END
	};

public:
	void Update();
	void LateUpdate();
	void Render();

private:
	void Release();

public:
	HRESULT AddObject(OBJ_TYPE eObjType, CObj *pObj);

private:
	list<CObj *> m_listObj[OBJ_TYPE::END];
};

#endif