#include "stdafx.h"

#include "Terrain.h"
#include "Player.h"

#include "Stage.h"


CStage::CStage()
{
}


CStage::~CStage()
{
	Release();
}

void CStage::Update()
{
	m_pObjManager->Update();
}

void CStage::LateUpdate()
{
	m_pObjManager->LateUpdate();
}

void CStage::Render()
{
	m_pObjManager->Render();
}

HRESULT CStage::Init()
{
	CObj *pObj = nullptr;
	HRESULT hr = 0;

	// Terrain
	pObj = CTerrain::Create();
	NULL_CHECK_MSG_RETURN(pObj, L"Terrain Not Found, CStage::Init()", E_FAIL);

	hr = m_pObjManager->AddObject(CObjManager::OBJ_TYPE::TERRAIN, pObj);
	FAILED_CHECK_MSG_RETURN(hr, L"Terrain Add Failed, CStage::Init()", E_FAIL);

	// Player
	pObj = CPlayer::Create();
	NULL_CHECK_MSG_RETURN(pObj, L"Player Not Found, CStage::Init()", E_FAIL);

	hr = m_pObjManager->AddObject(CObjManager::OBJ_TYPE::PLAYER, pObj);
	FAILED_CHECK_MSG_RETURN(hr, L"Player Add Failed, CStage::Init()", E_FAIL);

	return S_OK;
}

void CStage::Release()
{
}

CStage * CStage::Create()
{
	CStage *pInstance = new CStage;

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
