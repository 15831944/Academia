#pragma once
class CWall
{
public:
	CWall();
	~CWall();
};

