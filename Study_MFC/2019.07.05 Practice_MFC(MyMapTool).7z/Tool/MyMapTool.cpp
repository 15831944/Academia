// MyMapTool.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Tool.h"

#include "MainFrm.h"
#include "ToolView.h"

#include "Terrain.h"

#include "MyMapTool.h"
#include "afxdialogex.h"


// MyMapTool ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CMyMapTool, CDialog)

CMyMapTool::CMyMapTool(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_MYMAPTOOL, pParent)
	, m_TileY(0)
	, m_TileX(0)
	, m_TileSizeX(0)
	, m_TileSizeY(0)
{

}

CMyMapTool ::~CMyMapTool()
{
}

void CMyMapTool::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT7, m_TileY);
	DDX_Text(pDX, IDC_EDIT8, m_TileX);
	DDX_Text(pDX, IDC_EDIT9, m_TileSizeX);
	DDX_Text(pDX, IDC_EDIT10, m_TileSizeY);
	DDX_Control(pDX, IDC_BUTTON1, m_RadioForObject[0]);
	DDX_Control(pDX, IDC_BUTTON2, m_RadioForObject[1]);
	DDX_Control(pDX, IDC_BUTTON3, m_RadioForObject[2]);
}


BOOL CMyMapTool::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	CMainFrame *pFramwWnd = dynamic_cast<CMainFrame *>(::AfxGetApp()->GetMainWnd());
	NULL_CHECK_MSG_RETURN(pFramwWnd, L"FramWnd Not Found, CMyMapTool::OnInitDialog()", TRUE);

	m_pToolView = dynamic_cast<CToolView *>(pFramwWnd->getMainSplitt().GetPane(0, 1));
	NULL_CHECK_MSG_RETURN(m_pToolView, L"ToolView Not Found, CMyMapTool::OnInitDialog()", TRUE);

	m_pTerrain = const_cast<CTerrain *>(m_pToolView->getTerrain());
	NULL_CHECK_MSG_RETURN(m_pTerrain, L"Terrain Not Found, CMyMapTool::OnInitDialog()", TRUE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BEGIN_MESSAGE_MAP(CMyMapTool, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &CMyMapTool::OnBnClickedApply)
	ON_BN_CLICKED(IDC_BUTTON6, &CMyMapTool::OnBnClickedReset)
	ON_LBN_SELCHANGE(IDC_LIST1, &CMyMapTool::OnLbnSelchangeMonster)
END_MESSAGE_MAP()


// MyMapTool �޽��� ó�����Դϴ�.


void CMyMapTool::OnBnClickedApply()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	UpdateData(TRUE); // control => variable

	//m_TileY 
	//m_TileX 
	//m_TileSizeX
	//m_TileSizeY

	if (m_RadioForObject[0].GetCheck())
	{

		m_pTerrain->Release();

		m_pTerrain->CreateTile(m_TileY, m_TileX, m_TileSizeX, m_TileSizeY);

		TCHAR szBuffer[MAX_STR] = L"";

		swprintf_s(szBuffer, L"TILE: %d / %d \nSIZE: %d / %d", m_TileX, m_TileY, m_TileSizeX, m_TileSizeY);
		ERR_MSG(szBuffer);

	}
	else if (m_RadioForObject[1].GetCheck())
	{

	}
	else
	{

	}


	m_pToolView->Invalidate(FALSE);

	UpdateData(FALSE); // variable => control
}


void CMyMapTool::OnBnClickedReset()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	UpdateData(TRUE); // control => variable

	m_pTerrain->Release();
	m_pToolView->Invalidate(FALSE);

	UpdateData(FALSE); // variable => control
}


void CMyMapTool::OnLbnSelchangeMonster()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	UpdateData(TRUE);



	UpdateData(FALSE);
}
