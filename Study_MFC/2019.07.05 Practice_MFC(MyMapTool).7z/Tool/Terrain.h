#pragma once
#ifndef _MY_TERRAIN_H_
#define _MY_TERRAIN_H_

class CToolView;

class CTerrain
{
private:
	explicit CTerrain();

public:
	~CTerrain();

public:
	void Render() const;
	void RenderMiniView() const;
	void Release();

private:
	HRESULT Init();


public:
	void ChangeTile(
		const D3DXVECTOR3 &vPos,
		const BYTE &byDrawID,
		const BYTE &byOption = 0
	);

	HRESULT SaveTile(const TCHAR *pFilePath) const;
	HRESULT LoadTile(const TCHAR *pFilePath);

	HRESULT CreateTile(int x, int y, int sizeX, int sizeY);

private:
	int GetTileIndex(const D3DXVECTOR3 &vPos);
	bool IsPicking(const D3DXVECTOR3 &vPos, size_t index);

public:
	void setToolView(CToolView *pToolView) { m_pToolView = pToolView; }
	void setStateKey(wstring &stateKey) { m_wstrStateKey = stateKey; }

public:
	static CTerrain* Create(CToolView *pToolView);


private:
	vector<TILE_INFO *> m_vecTile;
	vector<TILE_INFO *> m_vecWall;


	

	wstring m_wstrStateKey;

	CToolView *m_pToolView;
};

#endif