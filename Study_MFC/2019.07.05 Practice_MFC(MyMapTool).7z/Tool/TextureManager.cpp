#include "stdafx.h"

#include "SingleTexture.h"
#include "MultiTexture.h"

#include "TextureManager.h"

IMPLEMENT_SINGLETON(CTextureManager);

CTextureManager::CTextureManager()
{
}

CTextureManager::~CTextureManager()
{
	Release();
}

void CTextureManager::Release()
{
	for (auto &MyPair : m_mapTexture)
	{
		SafeDelete(MyPair.second);
	}
	m_mapTexture.clear();
}

HRESULT CTextureManager::LoadTexture(
	TEXTURE_TYPE eTextureType,
	const wstring &wstrFilePath,
	const wstring &wstrObjectKey,
	const wstring &wstrStateKey,
	const int &count)
{
	auto iterFind = m_mapTexture.find(wstrObjectKey);

	CTexture *pTexture = nullptr;

	switch (eTextureType)
	{
	case CTextureManager::SINGLETEXTURE:
		if (iterFind != m_mapTexture.end())
		{
			return E_FAIL;
		}
		pTexture = new CSingleTexture;
		m_mapTexture.emplace(wstrObjectKey, pTexture);
		break;

	case CTextureManager::MULTITEXTURE:
		if (iterFind == m_mapTexture.end())
		{
			pTexture = new CMultiTexture;
			m_mapTexture.emplace(wstrObjectKey, pTexture);
		}
		break;

	default:
		break;
	}

	return m_mapTexture[wstrObjectKey]->LoadTexture(wstrFilePath, wstrStateKey, count);
}

const TEXTURE_INFO * CTextureManager::getTextureInfo(
	const wstring &wstrObjectKey,
	const wstring &wstrStateKey,
	const int &index)
{
	auto iterFind = m_mapTexture.find(wstrObjectKey);

	if (iterFind == m_mapTexture.end())
	{
		return nullptr;
	}

	return iterFind->second->getTextureInfo(wstrStateKey, index);
}

