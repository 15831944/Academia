
// ToolView.cpp : CToolView Ŭ������ ����
//

#include "stdafx.h"
// SHARED_HANDLERS�� �̸� ����, ����� �׸� �� �˻� ���� ó���⸦ �����ϴ� ATL ������Ʈ���� ������ �� ������
// �ش� ������Ʈ�� ���� �ڵ带 �����ϵ��� �� �ݴϴ�.
#ifndef SHARED_HANDLERS
#include "Tool.h"
#endif

#include "ToolDoc.h"

// #################################################################################################
#include "MainFrm.h"

#include "MiniView.h"
#include "MyFormView.h"
#include "MapTool.h"

#include "Terrain.h"

#include "ToolView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CToolView

IMPLEMENT_DYNCREATE(CToolView, CScrollView)

BEGIN_MESSAGE_MAP(CToolView, CScrollView)
	// ǥ�� �μ� �����Դϴ�.
	ON_COMMAND(ID_FILE_PRINT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CScrollView::OnFilePrintPreview)
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()

// CToolView ����/�Ҹ�

CToolView::CToolView()
{
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.

}

CToolView::~CToolView()
{
	SafeDelete(m_pTerrain);

	CTextureManager::DestroyInstance();
	CDeviceManager::DestroyInstance();
}

BOOL CToolView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	//  Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.

	return CScrollView::PreCreateWindow(cs);
}

// CToolView �׸���

void CToolView::OnDraw(CDC* /*pDC*/)
{
	CToolDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: ���⿡ ���� �����Ϳ� ���� �׸��� �ڵ带 �߰��մϴ�.

	/*
	CDeviceManager::getInstance()->RenderBegin();

	const TEXTURE_INFO *pTextureInfo = CTextureManager::getInstance()->getTextureInfo(
		L"Cube"
	);

	vPos1 = { 0.0f, 0.0f, 0.0f };

	D3DXMatrixScaling(&matScale1, 1.0f, 1.0f, 0.0f);
	D3DXMatrixScaling(&matScale1, 0.5f, 0.5f, 0.0f);
	D3DXMatrixRotationZ(&matRotZ1, D3DXToRadian(-(0.0f)));
	D3DXMatrixTranslation(&matTrans1, 400.0f, 400.0f, 0.0f);

	D3DXMatrixRotationZ(&matRevZ1, D3DXToRadian(-(0.0f)));

	matWorld1 = matScale1 * matRotZ1 * matTrans1 * matRevZ1;

	D3DXVec3TransformCoord(&vPos1, &vPos1, &matWorld1);

	float centerX1 = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY1 = pTextureInfo->tImageInfo.Height * 0.5f;

	CDeviceManager::getInstance()->getSprite()->SetTransform(&matWorld1);
	CDeviceManager::getInstance()->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,
		&D3DXVECTOR3(centerX1, centerY1, 0.0f),
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);

	CDeviceManager::getInstance()->RenderEnd();
	*/



	CDeviceManager::getInstance()->RenderBegin();

	const TEXTURE_INFO *pTextureInfo = CTextureManager::getInstance()->getTextureInfo(
	L"Cube"
	);

	vPos1 = { 0.0f, 0.0f, 0.0f };

	D3DXMatrixScaling(&matScale1, 1.0f, 1.0f, 0.0f);
	D3DXMatrixScaling(&matScale1, 0.5f, 0.5f, 0.0f);
	D3DXMatrixRotationZ(&matRotZ1, D3DXToRadian(-(0.0f)));
	D3DXMatrixTranslation(&matTrans1, 400.0f, 400.0f, 0.0f);

	D3DXMatrixRotationZ(&matRevZ1, D3DXToRadian(-(0.0f)));

	matWorld1 = matScale1 * matRotZ1 * matTrans1 * matRevZ1;

	D3DXVec3TransformCoord(&vPos1, &vPos1, &matWorld1);

	float centerX1 = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY1 = pTextureInfo->tImageInfo.Height * 0.5f;

	CDeviceManager::getInstance()->getSprite()->SetTransform(&matWorld1);
	CDeviceManager::getInstance()->getSprite()->Draw(
	pTextureInfo->pTexture,
	nullptr,
	&D3DXVECTOR3(centerX1, centerY1, 0.0f),
	nullptr,
	D3DCOLOR_ARGB(255, 255, 255, 255)
	);

	m_pTerrain->Render();

	CDeviceManager::getInstance()->RenderEnd(m_hWnd);
	

	m_pMiniView->Invalidate(FALSE);
}


// CToolView �μ�

BOOL CToolView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// �⺻���� �غ�
	return DoPreparePrinting(pInfo);
}

void CToolView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ��ϱ� ���� �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
}

void CToolView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ� �� ���� �۾��� �߰��մϴ�.
}


// CToolView ����

#ifdef _DEBUG
void CToolView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CToolView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CToolDoc* CToolView::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CToolDoc)));
	return (CToolDoc*)m_pDocument;
}
#endif //_DEBUG


// CToolView �޽��� ó����


void CToolView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	//_CrtSetBreakAlloc(256);

	CScrollView::SetScrollSizes(MM_TEXT, CSize(TILESIZE_X * TILE_X, TILESIZE_Y * TILE_Y));

	CMainFrame *pFrameWnd = dynamic_cast<CMainFrame *>(::AfxGetApp()->GetMainWnd());
	
	RECT rcFrame;
	pFrameWnd->GetWindowRect(&rcFrame);
	::SetRect(&rcFrame, 0, 0, rcFrame.right - rcFrame.left, rcFrame.bottom - rcFrame.top);

	RECT rcView;
	GetClientRect(&rcView);

	int marginX = rcFrame.right - rcView.right;
	int marginY = rcFrame.bottom - rcView.bottom;

	pFrameWnd->SetWindowPos(
		nullptr,
		0, 0,
		WINSIZE_X + marginX, WINSIZE_Y + marginY,
		SWP_NOZORDER
	);

	HRESULT hr = 0;

	hr = CDeviceManager::getInstance()->InitDevice(
	m_hWnd,
	WINSIZE_X, WINSIZE_Y,
	CDeviceManager::SCREEN_TYPE::WINDOWED
	);

	FAILED_CHECK(hr);

	hr = CTextureManager::getInstance()->LoadTexture(
	CTextureManager::TEXTURE_TYPE::SINGLETEXTURE,
	L"../Texture/Cube.png",
	L"Cube"
	);

	FAILED_CHECK(hr);

	hr = CTextureManager::getInstance()->LoadTexture(
		CTextureManager::TEXTURE_TYPE::MULTITEXTURE,
		L"../Texture/Terrain/Tile/Tile%d.png",
		L"Terrain",
		L"Tile",
		40
	);
	FAILED_CHECK(hr);

	m_pTerrain = CTerrain::Create(this);
	NULL_CHECK(m_pTerrain);

	m_pMiniView = dynamic_cast<CMiniView *>(pFrameWnd->getSubSplitt().GetPane(0, 0));
	NULL_CHECK(m_pMiniView);

	CMyFormView *pMyFormView = dynamic_cast<CMyFormView *>(pFrameWnd->getSubSplitt().GetPane(1, 0));
	NULL_CHECK(pMyFormView);

	m_pMapTool = const_cast<CMapTool *>(&pMyFormView->getMapTool());
	NULL_CHECK(m_pMapTool);
}


void CToolView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CScrollView::OnLButtonDown(nFlags, point);

	RECT rcView = {};
	GetClientRect(&rcView);

	float viewSizeX = (float)(rcView.right - rcView.left);
	float viewSizeY = (float)(rcView.bottom - rcView.top);

	D3DXVECTOR3 vMousePos = {
		((float)point.x + CScrollView::GetScrollPos(0)) * WINSIZE_X / viewSizeX,
		((float)point.y + CScrollView::GetScrollPos(1)) * WINSIZE_Y / viewSizeY,
		0.0f
	};

	cout << "Mouse: "<< point.x << " / " << point.y << endl;

	BYTE byDrawID = m_pMapTool->getDrawID();
	m_pTerrain->ChangeTile(vMousePos, byDrawID);

	Invalidate(FALSE);
}

void CToolView::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CScrollView::OnRButtonDown(nFlags, point);

	TCHAR message[MAX_STR] = L"";

	swprintf_s(message, L"mouse: %d / %d \nmatWorld: %f / %f \nvPos1: %f / %f \nvPos2: %f / %f",
		point.x, point.y,
		matWorld1._41, matWorld1._42,
		vPos1.x, vPos1.y,
		vPos2.x, vPos2.y
	);

	AfxMessageBox(message);

	//Invalidate(FALSE);
}




void CToolView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CScrollView::OnMouseMove(nFlags, point);

	if (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
	{
		RECT rcView = {};
		GetClientRect(&rcView);

		float viewSizeX = (float)(rcView.right - rcView.left);
		float viewSizeY = (float)(rcView.bottom - rcView.top);

		D3DXVECTOR3 vMousePos = {
			((float)point.x + CScrollView::GetScrollPos(0)) * WINSIZE_X / viewSizeX,
			((float)point.y + CScrollView::GetScrollPos(1)) * WINSIZE_Y / viewSizeY,
			0.0f
		};

		cout << "Mouse: " << point.x << " / " << point.y << endl;


		BYTE byDrawID = m_pMapTool->getDrawID();
		m_pTerrain->ChangeTile(vMousePos, byDrawID);

		Invalidate(FALSE);
	}
}
