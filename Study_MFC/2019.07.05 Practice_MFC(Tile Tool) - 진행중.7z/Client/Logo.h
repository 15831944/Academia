#pragma once
#ifndef _LOGO_H_
#define _LOGO_H_

#include "Scene.h"

class CLogo : public CScene
{
public:
	CLogo();
	virtual ~CLogo();

public:
	// CScene��(��) ���� ��ӵ�
	virtual void Update() override;
	virtual void LateUpdate() override;
	virtual void Render() override;

private:
	virtual HRESULT Init() override;
	virtual void Release() override;

public:
	static CLogo* Create();
};

#endif