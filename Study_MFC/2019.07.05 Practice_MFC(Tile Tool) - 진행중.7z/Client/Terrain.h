#pragma once
#ifndef _TERRAIN_H_
#define _TERRAIN_H_

#include "Obj.h"

class CTerrain : public CObj
{
private:
	explicit CTerrain();

public:
	~CTerrain();

public:
	// CObj��(��) ���� ��ӵ�
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render() override;

private:
	virtual HRESULT Init() override;
	virtual HRESULT LateInit() override;
	virtual void Release() override;

private:
	HRESULT LoadTile(const TCHAR *pFilePath);

public:
	static CTerrain* Create();

private:
	vector<TILE_INFO *> m_vecTile;

};

#endif