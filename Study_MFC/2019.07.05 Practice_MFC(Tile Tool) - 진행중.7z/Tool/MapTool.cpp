// MapTool.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Tool.h"

#include "MainFrm.h"
#include "ToolView.h"

#include "Terrain.h"

#include "FileInfo.h"

#include "MapTool.h"
#include "afxdialogex.h"


// CMapTool ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CMapTool, CDialog)

CMapTool::CMapTool(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_MAPTOOL, pParent)
{

}

CMapTool::~CMapTool()
{
}

void CMapTool::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_ListBox);
	DDX_Control(pDX, IDC_PICTURECTRL, m_PictureCtrl);
}



void CMapTool::CreateHorizontalScrollBar()
{
	CString strFilePath = L"";

	CSize size;
	int iCX = 0;

	CDC *pDC = m_ListBox.GetDC(); // ListBox�� DC���� �׷�����?!

	for (int i = 0; i < m_ListBox.GetCount(); ++i)
	{
		m_ListBox.GetText(i, strFilePath);

		// �ȼ� ���� ũ��� ��ȯ.
		size = pDC->GetTextExtent(strFilePath);

		if (size.cx > iCX)
		{
			iCX = size.cx;
		}
	}

	if (iCX > m_ListBox.GetHorizontalExtent())
	{
		m_ListBox.SetHorizontalExtent(iCX);
	}

	m_ListBox.ReleaseDC(pDC);
}


BEGIN_MESSAGE_MAP(CMapTool, CDialog)
	ON_WM_DROPFILES()
	ON_LBN_SELCHANGE(IDC_LIST1, &CMapTool::OnLbnSelchangeTileList)
	ON_BN_CLICKED(IDC_BUTTON1, &CMapTool::OnBnClickedSave)
	ON_BN_CLICKED(IDC_BUTTON6, &CMapTool::OnBnClickedLoad)
END_MESSAGE_MAP()


// CMapTool �޽��� ó�����Դϴ�.


void CMapTool::OnDropFiles(HDROP hDropInfo)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CDialog::OnDropFiles(hDropInfo);


	TCHAR szFileFullPath[MAX_STR] = L"";
	TCHAR szFileName[MAX_STR] = L"";

	CString strRelativePath = L"";
	CString strFileName = L"";

	// �� ��° ���� "-1"�̶� Drag & Drop�� ���� ������ ����.
	// HDROP, �ε���, ���ϰ�� �޾ƿ� ��, ���ڿ� ����
	int iCount = DragQueryFile(hDropInfo, -1, nullptr, 0);

	for (int i = 0; i < iCount; ++i)
	{
		DragQueryFile(hDropInfo, i, szFileFullPath, MAX_STR);

		strRelativePath = CFileInfo::ConvertRelativePath(szFileFullPath);

		strFileName = PathFindFileName(strRelativePath);
		lstrcpy(szFileName, strFileName.GetString());

		PathRemoveExtension(szFileName);

		m_ListBox.AddString(szFileName);
		//m_ListBox.AddString(szFileFullPath);
	}

	CreateHorizontalScrollBar();
}


void CMapTool::OnLbnSelchangeTileList()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	int iIndex = m_ListBox.GetCurSel();
	if (iIndex == -1)
	{
		return;
	}

	CString strSelectName = L"";
	// �ش� �ε����� ���ڿ� �޾ƿ�.
	m_ListBox.GetText(iIndex, strSelectName);

	int i = 0;
	for (; i < strSelectName.GetLength(); ++i)
	{
		// ������ ������ �Ǵ��ϱ� ���ؼ�...
		if (isdigit(strSelectName[i]))
		{
			break;
		}
	}

	// ù ���ں��� ���ڰ� ���۵Ǵ� �� �������� ���ڸ� ����.
	strSelectName.Delete(0, i);

	m_byDrawID = _ttoi(strSelectName);
	// _wtoi(), atoi()

	CMainFrame *pFrameWnd = dynamic_cast<CMainFrame *>(::AfxGetApp()->GetMainWnd());
	NULL_CHECK(pFrameWnd);

	CToolView *pToolView = dynamic_cast<CToolView *>(pFrameWnd->getMainSplitt().GetPane(0, 1));
	NULL_CHECK(pToolView);

	// pToolView->set

	const TEXTURE_INFO *pTextureInfo = CTextureManager::getInstance()->getTextureInfo(
		L"Terrain", L"Tile", m_byDrawID
	);
	NULL_CHECK(pTextureInfo);

	CDeviceManager::getInstance()->RenderBegin();

	D3DXMATRIX matScale;
	D3DXMatrixScaling(&matScale, (float)WINSIZE_X / TILESIZE_X, (float)WINSIZE_Y / TILESIZE_Y, 0.0f);

	CDeviceManager::getInstance()->getSprite()->SetTransform(&matScale);
	CDeviceManager::getInstance()->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,
		nullptr,
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);

	CDeviceManager::getInstance()->RenderEnd(m_PictureCtrl.GetSafeHwnd());
	
}


void CMapTool::OnBnClickedSave()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CFileDialog Dlg(
		FALSE,
		L"dat",
		L"�������.dat",
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		L"Data Files(*.dat)|*.dat|Text Files(*.txt)|*.txt||",
		this
	);

	TCHAR szCurrentPath[MAX_STR] = L"";

	GetCurrentDirectory(MAX_STR, szCurrentPath);
	PathRemoveFileSpec(szCurrentPath);
	lstrcat(szCurrentPath, L"\\Data");

	Dlg.m_ofn.lpstrInitialDir = szCurrentPath;

	if (Dlg.DoModal() == IDOK)
	{
		CMainFrame *pFrameWnd = dynamic_cast<CMainFrame *>(::AfxGetApp()->GetMainWnd());
		NULL_CHECK(pFrameWnd);

		CToolView *pToolView = dynamic_cast<CToolView *>(pFrameWnd->getMainSplitt().GetPane(0, 1));
		NULL_CHECK(pToolView);

		const CTerrain *pTerrain = pToolView->getTerrain();
		NULL_CHECK(pTerrain);

		CString strFilePath = Dlg.GetPathName(); // ���̾�α׿��� �޾ƿ� ��.

		HRESULT hr = pTerrain->SaveTile(strFilePath);
		FAILED_CHECK_MSG(hr, L"Tile Save Failed");
	}
}


void CMapTool::OnBnClickedLoad()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CFileDialog Dlg(
		TRUE,
		L"dat",
		L"�������.dat",
		OFN_HIDEREADONLY, //| OFN_OVERWRITEPROMPT,
		L"Data Files(*.dat)|*.dat|Text Files(*.txt)|*.txt||",
		this
	);

	TCHAR szCurrentPath[MAX_STR] = L"";

	GetCurrentDirectory(MAX_STR, szCurrentPath);
	PathRemoveFileSpec(szCurrentPath);
	lstrcat(szCurrentPath, L"\\Data");

	Dlg.m_ofn.lpstrInitialDir = szCurrentPath;

	if (Dlg.DoModal() == IDOK)
	{
		CMainFrame *pFrameWnd = dynamic_cast<CMainFrame *>(::AfxGetApp()->GetMainWnd());
		NULL_CHECK(pFrameWnd);

		CToolView *pToolView = dynamic_cast<CToolView *>(pFrameWnd->getMainSplitt().GetPane(0, 1));
		NULL_CHECK(pToolView);

		const CTerrain *pTerrain = pToolView->getTerrain();


		CString strFilePath = Dlg.GetPathName();
		HRESULT hr = const_cast<CTerrain *>(pTerrain)->LoadTile(strFilePath);
		FAILED_CHECK_MSG(hr, L"Tile Load Failed");

		pToolView->Invalidate(FALSE);
		
	}
}
