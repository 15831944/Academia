#pragma once
#include "afxwin.h"
#ifndef _TILE_TOOL_H_
#define _TILE_TOOL_H_

// CTileTool ��ȭ �����Դϴ�.

class CToolView;
class CTerrain;

class CTileTool : public CDialog
{
	DECLARE_DYNAMIC(CTileTool)

public:
	CTileTool(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CTileTool();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TILETOOL };
#endif

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

public: // Message Function
	DECLARE_MESSAGE_MAP()

	afx_msg void OnBnClickedCreate();
	afx_msg void OnBnClickedDelete();
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedLoad();

	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnLbnSelchangeTileToolListBoxForTile();

private: // User Function
	void CreateHorizontalScrollBar();

private: // Control Variable
	int m_TileRow;
	int m_TileColumn;
	int m_TileWidth;
	int m_TileHeight;

	CButton m_TileToolRadio[4];
	CListBox m_TileToolListBoxForTile;
	CStatic m_TileToolPictureControlForTile;

private: // User Variable
	CToolView *m_pToolView;
	CTerrain *m_pTerrain;

	BYTE m_byDrawID;
	

	
};

#endif