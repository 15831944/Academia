#pragma once
#ifndef _FRAME_MANAGER_H_
#define _FRAME_MANAGER_H_

class CFrameManager
{
	DECLARE_SINGLETON(CFrameManager);

private:
	CFrameManager();
	~CFrameManager();

public:
	void InitTIme();
	bool LimitFrame(float fLimit);
	void RenderFrame();

private:
	CDeviceManager *m_pDeviceManager;

	LARGE_INTEGER m_OldTime;
	LARGE_INTEGER m_CurrentTime;
	LARGE_INTEGER m_CPUTick;

	float m_fTimeCount;
	float m_fLimitCount;
	int m_iFPS;

	TCHAR m_szBuffer[MIN_STR];
};

#endif