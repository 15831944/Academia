#include "stdafx.h"

#include "Obj.h"

#include "ObjManager.h"

IMPLEMENT_SINGLETON(CObjManager);

CObjManager::CObjManager()
{
}


CObjManager::~CObjManager()
{
	Release();
}

void CObjManager::Update()
{
	for (int i = 0; i < OBJ_TYPE::END; ++i)
	{
		auto iter = m_listObj[i].begin();
		for (; iter != m_listObj[i].end(); )
		{
			int iEventNum = (*iter)->Update();

			if (iEventNum == OBJ_DEAD)
			{
				SafeDelete(*iter);
				iter = m_listObj[i].erase(iter);
			}
			else
			{
				++iter;
			}
		}
	}
}

void CObjManager::LateUpdate()
{
	for (int i = 0; i < OBJ_TYPE::END; ++i)
	{
		for (auto &pObj : m_listObj[i])
		{
			pObj->LateUpdate();
		}
	}
}

void CObjManager::Render()
{
	for (int i = 0; i < OBJ_TYPE::END; ++i)
	{
		for (auto &pObj : m_listObj[i])
		{
			pObj->Render();
		}
	}
}

void CObjManager::Release()
{
	for (int i = 0; i < OBJ_TYPE::END; ++i)
	{
		for_each(m_listObj[i].begin(), m_listObj[i].end(), SafeDelete<CObj *>);

		m_listObj[i].clear();
	}
}

HRESULT CObjManager::AddObject(OBJ_TYPE eObjType, CObj *pObj)
{
	NULL_CHECK_RETURN(pObj, E_FAIL);

	m_listObj[eObjType].emplace_back(pObj);
	return S_OK;
}
