#pragma once
#ifndef _PLAYER2_H_
#define _PLAYER2_H_

class CPlayer2
{
private:
	explicit CPlayer2();

public:
	~CPlayer2();

public:
	enum STATE {
		STAND,
		WALK,
		DASH,
		ATTACK,
		END
	};

public:
	int Update();
	void LateUpdate();
	void Render();

private:
	HRESULT Init();
	void Release();

public:


private:
	void MoveFrame();
	void ChangeScene();
	void AdjustFrame();

public:
	static CPlayer2* Create();

private:
	INFO m_tInfo;
	FRAME2 m_tFrame;

	float m_fAngle;
	float m_fRotSpeed;
	float m_fSpeed;

	D3DXVECTOR3 m_vOrigin[4];
	D3DXVECTOR3 m_vConvert[4];

	STATE m_eCurrentState;
	STATE m_eNextState;

	CDeviceManager *m_pDeviceManager;
	CKeyManager *m_pKeyManager;
	CTextureManager *m_pTextureManager;

	bool m_bIsAttack;
	bool m_bIsDashing;

	int m_iDashCheckCount;
	DWORD m_dwDashCheckTime;
	DWORD m_dwDashTick;
};

#endif