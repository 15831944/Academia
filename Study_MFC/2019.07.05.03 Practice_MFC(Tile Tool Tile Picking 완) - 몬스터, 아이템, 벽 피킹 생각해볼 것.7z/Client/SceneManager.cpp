#include "stdafx.h"

#include "Logo.h"
#include "Stage.h"

#include "SceneManager.h"

IMPLEMENT_SINGLETON(CSceneManager);

CSceneManager::CSceneManager()
	: m_pCurScene(nullptr),
	m_eCurSceneType(SCENE_TYPE::END),
	m_eNextSceneType(SCENE_TYPE::END)
{
}


CSceneManager::~CSceneManager()
{
	Release();
}

void CSceneManager::Update()
{
	// ���� Scene�� �ִ������� Ȯ�� !!!!
	NULL_CHECK_MSG(m_pCurScene, L"Current Scene Not Found, CSceneManager::Update()");
	m_pCurScene->Update();
}

void CSceneManager::LateUpdate()
{
	NULL_CHECK_MSG(m_pCurScene, L"Current Scene Not Found, CSceneManager::LateUpdate()");
	m_pCurScene->LateUpdate();
}

void CSceneManager::Render()
{
	NULL_CHECK_MSG(m_pCurScene, L"Current Scene Not Found, CSceneManager::Render()");
	m_pCurScene->Render();
}

void CSceneManager::Release()
{
	SafeDelete(m_pCurScene);
}

HRESULT CSceneManager::ChangeScene(SCENE_TYPE eSceneType)
{
	m_eNextSceneType = eSceneType;

	// ���� Scene�� �ٲ��� �ϴ� Scene�� ������ �ٸ���, Scene ��ȯ�� �߻���.
	if (m_eCurSceneType != m_eNextSceneType)
	{
		SafeDelete(m_pCurScene);

		switch (m_eNextSceneType)
		{
		case CSceneManager::LOGO:
			m_pCurScene = CLogo::Create();
			break;

		case CSceneManager::STAGE:
			m_pCurScene = CStage::Create();
			break;

		default:
			break;
		}

		NULL_CHECK_RETURN(m_pCurScene, E_FAIL);

		m_eCurSceneType = m_eNextSceneType;
	}

	return S_OK;
}
