#pragma once
#ifndef _SCROLL_MANAGER_H_
#define _SCROLL_MANAGER_H_

class CScrollManager
{
private:
	CScrollManager() {}
	~CScrollManager() {}

public:
	static const D3DXVECTOR3& GetScrollPos() { return m_vScroll; }

public:
	static void MoveScrollPos(const D3DXVECTOR3 &vMove) { m_vScroll += vMove; }

private:
	static D3DXVECTOR3 m_vScroll;
};

D3DXVECTOR3 CScrollManager::m_vScroll = {};

#endif