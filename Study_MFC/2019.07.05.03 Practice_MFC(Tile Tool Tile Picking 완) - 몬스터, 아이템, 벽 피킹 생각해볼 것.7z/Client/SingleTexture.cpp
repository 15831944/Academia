#include "stdafx.h"
#include "SingleTexture.h"


CSingleTexture::CSingleTexture()
{
}


CSingleTexture::~CSingleTexture()
{
	Release();
}

void CSingleTexture::Release()
{
	m_pTextureInfo->pTexture->Release();

	SafeDelete(m_pTextureInfo);
}

HRESULT CSingleTexture::LoadTexture(
	const wstring &wstrFilePath,
	const wstring &wstrStateKey /*= L""*/,
	const int &count /*= 0*/)
{
	m_pTextureInfo = new TEXTURE_INFO;
	//NULL_CHECK_MSG_RETURN(m_pTextureInfo, L"TEXTURE_INFO memory allocation Failed, CSingleTexture::LoadTexture()", E_FAIL);

	HRESULT hr = 0;

	hr = D3DXGetImageInfoFromFile(
		wstrFilePath.c_str(),
		&m_pTextureInfo->tImageInfo
	);

	//FAILED_CHECK_MSG_RETURN(hr, L"D3DXGetImageInfoFromFile Failed, CSingleTexture::LoadTexture()", E_FAIL);

	hr = D3DXCreateTextureFromFileEx(
		CDeviceManager::getInstance()->getDevice(),
		wstrFilePath.c_str(),
		m_pTextureInfo->tImageInfo.Width,
		m_pTextureInfo->tImageInfo.Height,
		m_pTextureInfo->tImageInfo.MipLevels,
		0,
		m_pTextureInfo->tImageInfo.Format,
		D3DPOOL_MANAGED,
		D3DX_DEFAULT,
		D3DX_DEFAULT,
		0,
		nullptr,
		nullptr,
		&m_pTextureInfo->pTexture
	);

	//FAILED_CHECK_MSG_RETURN(hr, L"D3DXCreateTextureFromFileEx Failed, CSingleTexture::LoadTexture()", E_FAIL);

	return S_OK;
}

const TEXTURE_INFO* CSingleTexture::getTextureInfo(
	const wstring &wstrStateKey /*= L""*/,
	const int &index /*= 0*/)
{
	return m_pTextureInfo;
}
