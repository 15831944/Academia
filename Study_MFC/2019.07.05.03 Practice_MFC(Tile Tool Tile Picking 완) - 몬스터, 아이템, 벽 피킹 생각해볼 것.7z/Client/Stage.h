#pragma once
#ifndef _STAGE_H_
#define _STAGE_H_

#include "Scene.h"

class CStage : public CScene
{
public:
	CStage();
	virtual ~CStage();

public:
	// CScene��(��) ���� ��ӵ�
	virtual void Update() override;
	virtual void LateUpdate() override;
	virtual void Render() override;

private:
	virtual HRESULT Init() override;
	virtual void Release() override;

public:
	static CStage* Create();
};

#endif