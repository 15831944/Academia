#pragma once
#ifndef _TOOL_TERRAIN_H_
#define _TOOL_TERRAIN_H_

class CToolView;

class CTerrain
{
private:
	explicit CTerrain();

public:
	~CTerrain();

public:
	void Render() const;
	void RenderMiniView() const;
	void Release();

private:
	HRESULT Init();


public:
	void ChangeTile(
		const D3DXVECTOR3 &vPos,
		const BYTE &byDrawID,
		const BYTE &byOption = 0
	);

	HRESULT SaveTile(const TCHAR *pFilePath) const;
	HRESULT LoadTile(const TCHAR *pFilePath);

	HRESULT CreateTile(int row, int column, int sizeX, int sizeY, BYTE byDrawID = 42);


private:
	int GetTileIndex(const D3DXVECTOR3 &vPos);
	bool IsPicking(const D3DXVECTOR3 &vPos, size_t index);

public:
	float getExtenedSizeRateX() const { return m_fExtendedSizeRateX; }
	float getExtenedSizeRateY() const { return m_fExtendedSizeRateY; }

public:
	void setToolView(CToolView *pToolView) { m_pToolView = pToolView; }
	void setMiniViewRate(float fMiniViewRate) { m_fMiniViewRate = fMiniViewRate; }
	void setTileX(int tileX) { m_iTileX = tileX; }

public:
	static CTerrain* Create(CToolView *pToolView);


private:
	vector<TILE_INFO *> m_vecTile;
	vector<TILE_INFO *> m_vecWall; // option : �μ��� �ִ��� �Ǵ�
	vector<TILE_INFO *> m_vecMonster;   //
	vector<TILE_INFO *> m_vecItem;		//

	CToolView *m_pToolView;

	float m_fMiniViewRate;

	float m_fExtendedSizeRateX;
	float m_fExtendedSizeRateY;

	int m_iTileX;
};

#endif