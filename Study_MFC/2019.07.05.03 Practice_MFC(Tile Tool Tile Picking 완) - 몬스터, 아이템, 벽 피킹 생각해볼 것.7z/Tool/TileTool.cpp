// TileTool.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Tool.h"

#include "MainFrm.h"
#include "ToolView.h"

#include "Terrain.h"

#include "FileInfo.h"

#include "TileTool.h"
#include "afxdialogex.h"


// CTileTool ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CTileTool, CDialog)

CTileTool::CTileTool(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_TILETOOL, pParent)
	, m_TileRow(0)
	, m_TileColumn(0)
	, m_TileWidth(0)
	, m_TileHeight(0)
{
	m_byDrawID = 42;
}

CTileTool::~CTileTool()
{
}

void CTileTool::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_TileRow);
	DDX_Text(pDX, IDC_EDIT2, m_TileColumn);
	DDX_Text(pDX, IDC_EDIT3, m_TileWidth);
	DDX_Text(pDX, IDC_EDIT4, m_TileHeight);
	DDX_Control(pDX, IDC_RADIO4, m_TileToolRadio[0]);
	DDX_Control(pDX, IDC_RADIO7, m_TileToolRadio[1]);
	DDX_Control(pDX, IDC_RADIO8, m_TileToolRadio[2]);
	DDX_Control(pDX, IDC_RADIO9, m_TileToolRadio[3]);
	DDX_Control(pDX, IDC_LIST2, m_TileToolListBoxForTile);
	DDX_Control(pDX, IDC_PICTURECTRL2, m_TileToolPictureControlForTile);
}

BOOL CTileTool::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	CMainFrame *pFrameWnd = dynamic_cast<CMainFrame *>(::AfxGetApp()->GetMainWnd());
	NULL_CHECK_MSG_RETURN(pFrameWnd, L"FrameWnd Not Found, CMyMapTool::OnInitDialog()", TRUE);

	m_pToolView = dynamic_cast<CToolView *>(pFrameWnd->getMainSplitt().GetPane(0, 1));
	NULL_CHECK_MSG_RETURN(m_pToolView, L"ToolView Not Found, CMyMapTool::OnInitDialog()", TRUE);

	m_pTerrain = const_cast<CTerrain *>(m_pToolView->getTerrain());
	NULL_CHECK_MSG_RETURN(m_pTerrain, L"Terrain Not Found, CMyMapTool::OnInitDialog()", TRUE);

	m_TileToolRadio[0].SetCheck(TRUE); // �ʱ� Tile ī�װ��� ����.

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BEGIN_MESSAGE_MAP(CTileTool, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &CTileTool::OnBnClickedCreate)
	ON_BN_CLICKED(IDC_BUTTON7, &CTileTool::OnBnClickedDelete)
	ON_BN_CLICKED(IDC_BUTTON8, &CTileTool::OnBnClickedSave)
	ON_BN_CLICKED(IDC_BUTTON9, &CTileTool::OnBnClickedLoad)
	ON_WM_DROPFILES()
	ON_LBN_SELCHANGE(IDC_LIST2, &CTileTool::OnLbnSelchangeTileToolListBoxForTile)
END_MESSAGE_MAP()


// CTileTool �޽��� ó�����Դϴ�.

void CTileTool::OnBnClickedCreate()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	UpdateData(TRUE);

	if (m_TileToolRadio[0].GetCheck())
	{
		m_pTerrain->Release();
		m_pTerrain->CreateTile(
			m_TileRow, m_TileColumn,
			m_TileWidth,
			m_TileHeight
		);
		m_pTerrain->setTileX(m_TileColumn);

		m_pToolView->SetScrollSizes(
			MM_TEXT,
			CSize(m_TileColumn * m_TileWidth / m_pTerrain->getExtenedSizeRateX() + 100,
				m_TileRow * m_TileHeight / m_pTerrain->getExtenedSizeRateY() + 100
			)
		);

		m_pToolView->Invalidate(FALSE);
	}
	else if (m_TileToolRadio[1].GetCheck())
	{

	}
	else if (m_TileToolRadio[2].GetCheck())
	{
		AfxMessageBox(L"2");
	}
	else if (m_TileToolRadio[3].GetCheck())
	{
		AfxMessageBox(L"3");
	}


	UpdateData(FALSE);

}


void CTileTool::OnBnClickedDelete()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	if (m_TileToolRadio[0].GetCheck())
	{
		m_pTerrain->Release();

		m_pToolView->Invalidate(FALSE);
	}
}


void CTileTool::OnBnClickedSave()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CFileDialog Dlg(
		FALSE,
		L"dat",
		L"�������.dat",
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		L"Data Files(*.dat)|*.dat|Text Files(*.txt)|*.txt||",
		this
	);

	TCHAR szCurrentPath[MAX_STR] = L"";

	GetCurrentDirectory(MAX_STR, szCurrentPath);
	PathRemoveFileSpec(szCurrentPath);
	lstrcat(szCurrentPath, L"\\Data");

	Dlg.m_ofn.lpstrInitialDir = szCurrentPath;

	if (Dlg.DoModal() == IDOK)
	{
		CMainFrame *pFrameWnd = dynamic_cast<CMainFrame *>(::AfxGetApp()->GetMainWnd());
		NULL_CHECK(pFrameWnd);

		CToolView *pToolView = dynamic_cast<CToolView *>(pFrameWnd->getMainSplitt().GetPane(0, 1));
		NULL_CHECK(pToolView);

		const CTerrain *pTerrain = pToolView->getTerrain();
		NULL_CHECK(pTerrain);

		CString strFilePath = Dlg.GetPathName(); // ���̾�α׿��� �޾ƿ� ��.

		HRESULT hr = pTerrain->SaveTile(strFilePath);
		FAILED_CHECK_MSG(hr, L"Tile Save Failed");
	}

}


void CTileTool::OnBnClickedLoad()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CFileDialog Dlg(
		TRUE,
		L"dat",
		L"�������.dat",
		OFN_HIDEREADONLY, //| OFN_OVERWRITEPROMPT,
		L"Data Files(*.dat)|*.dat|Text Files(*.txt)|*.txt||",
		this
	);

	TCHAR szCurrentPath[MAX_STR] = L"";

	GetCurrentDirectory(MAX_STR, szCurrentPath);
	PathRemoveFileSpec(szCurrentPath);
	lstrcat(szCurrentPath, L"\\Data");

	Dlg.m_ofn.lpstrInitialDir = szCurrentPath;

	if (Dlg.DoModal() == IDOK)
	{
		CMainFrame *pFrameWnd = dynamic_cast<CMainFrame *>(::AfxGetApp()->GetMainWnd());
		NULL_CHECK(pFrameWnd);

		CToolView *pToolView = dynamic_cast<CToolView *>(pFrameWnd->getMainSplitt().GetPane(0, 1));
		NULL_CHECK(pToolView);

		const CTerrain *pTerrain = pToolView->getTerrain();


		CString strFilePath = Dlg.GetPathName();
		HRESULT hr = const_cast<CTerrain *>(pTerrain)->LoadTile(strFilePath);
		FAILED_CHECK_MSG(hr, L"Tile Load Failed");

		pToolView->Invalidate(FALSE);

	}
}

void CTileTool::CreateHorizontalScrollBar()
{
	CString strFilePath = L"";

	CSize size;
	int iCX = 0;

	CDC *pDC = m_TileToolListBoxForTile.GetDC(); // ListBox�� DC���� �׷�����?!

	for (int i = 0; i < m_TileToolListBoxForTile.GetCount(); ++i)
	{
		m_TileToolListBoxForTile.GetText(i, strFilePath);

		// �ȼ� ���� ũ��� ��ȯ.
		size = pDC->GetTextExtent(strFilePath);

		if (size.cx > iCX)
		{
			iCX = size.cx;
		}
	}

	if (iCX > m_TileToolListBoxForTile.GetHorizontalExtent())
	{
		m_TileToolListBoxForTile.SetHorizontalExtent(iCX);
	}

	m_TileToolListBoxForTile.ReleaseDC(pDC);
}


void CTileTool::OnDropFiles(HDROP hDropInfo)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CDialog::OnDropFiles(hDropInfo);

	TCHAR szFileFullPath[MAX_STR] = L"";
	TCHAR szFileName[MAX_STR] = L"";

	CString strRelativePath = L"";
	CString strFileName = L"";

	// �� ��° ���� "-1"�̶� Drag & Drop�� ���� ������ ����.
	// HDROP, �ε���, ���ϰ�� �޾ƿ� ��, ���ڿ� ����
	int iCount = DragQueryFile(hDropInfo, -1, nullptr, 0);

	for (int i = 0; i < iCount; ++i)
	{
		DragQueryFile(hDropInfo, i, szFileFullPath, MAX_STR);

		strRelativePath = CFileInfo::ConvertRelativePath(szFileFullPath);

		strFileName = PathFindFileName(strRelativePath);
		lstrcpy(szFileName, strFileName.GetString());

		PathRemoveExtension(szFileName);

		m_TileToolListBoxForTile.AddString(szFileName);
		//m_ListBox.AddString(szFileFullPath);
	}

	CreateHorizontalScrollBar();
}


void CTileTool::OnLbnSelchangeTileToolListBoxForTile()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.


	int iIndex = m_TileToolListBoxForTile.GetCurSel();
	if (iIndex == -1)
	{
		return;
	}

	CString strSelectName = L"";
	// �ش� �ε����� ���ڿ� �޾ƿ�.
	m_TileToolListBoxForTile.GetText(iIndex, strSelectName);

	int i = 0;
	for (; i < strSelectName.GetLength(); ++i)
	{
		// ������ ������ �Ǵ��ϱ� ���ؼ�...
		if (isdigit(strSelectName[i]))
		{
			break;
		}
	}

	// ù ���ں��� ���ڰ� ���۵Ǵ� �� �������� ���ڸ� ����.
	strSelectName.Delete(0, i);

	m_byDrawID = _ttoi(strSelectName);
	// _wtoi(), atoi()

	// pToolView->set

	const TEXTURE_INFO *pTextureInfo = CTextureManager::getInstance()->getTextureInfo(
		L"Terrain", L"Tile", m_byDrawID
	);
	NULL_CHECK(pTextureInfo);

	CDeviceManager::getInstance()->RenderBegin();

	D3DXMATRIX matScale;
	D3DXMatrixScaling(&matScale, WINSIZE_X / 72.0f, (float)WINSIZE_Y / 72.0f, 0.0f);

	CDeviceManager::getInstance()->getSprite()->SetTransform(&matScale);
	CDeviceManager::getInstance()->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,
		nullptr,
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);

	CDeviceManager::getInstance()->RenderEnd(m_TileToolPictureControlForTile.GetSafeHwnd());

}
