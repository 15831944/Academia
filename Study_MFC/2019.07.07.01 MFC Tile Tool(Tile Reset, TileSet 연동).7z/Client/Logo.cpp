#include "stdafx.h"
#include "Logo.h"


CLogo::CLogo()
{
}


CLogo::~CLogo()
{
}

void CLogo::Update()
{

}

void CLogo::LateUpdate()
{
	
}

void CLogo::Render()
{
	if (GetAsyncKeyState(VK_RETURN) & 0x8000)
	{
		HRESULT hr = m_pSceneMgr->SceneChange(CSceneMgr::STAGE);
		FAILED_CHECK_MSG(hr, L"Stage Scene Change Failed");

		return;
	}
}

HRESULT CLogo::Initialize()
{
	return S_OK;
}

void CLogo::Release()
{
}

CLogo* CLogo::Create()
{
	CLogo* pInstance = new CLogo;

	if (FAILED(pInstance->Initialize()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}