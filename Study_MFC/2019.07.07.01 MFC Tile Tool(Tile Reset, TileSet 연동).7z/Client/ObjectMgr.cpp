#include "stdafx.h"
#include "ObjectMgr.h"
#include "GameObject.h"

IMPLEMENT_SINGLETON(CObjectMgr)

CObjectMgr::CObjectMgr()
{
}


CObjectMgr::~CObjectMgr()
{
	Release();
}

HRESULT CObjectMgr::AddObject(OBJECT_TYPE eType, CGameObject * pObject)
{
	NULL_CHECK_RETURN(pObject, E_FAIL);
	m_ObjectLst[eType].push_back(pObject);

	return S_OK;
}

void CObjectMgr::Update()
{
	for (int i = 0; i < TYPE_END; ++i)
	{
		auto iter_begin = m_ObjectLst[i].begin();
		auto iter_end = m_ObjectLst[i].end();

		for (; iter_begin != iter_end;)
		{
			int iEvent = (*iter_begin)->Update();

			if (DEAD_OBJ == iEvent)
			{
				SafeDelete(*iter_begin);
				iter_begin = m_ObjectLst[i].erase(iter_begin);
			}
			else
				++iter_begin;
		}
	}
}

void CObjectMgr::LateUpdate()
{
	for (int i = 0; i < TYPE_END; ++i)
	{
		for (auto& pGameObject : m_ObjectLst[i])
			pGameObject->LateUpdate();
	}
}

void CObjectMgr::Render()
{
	for (int i = 0; i < TYPE_END; ++i)
	{
		for (auto& pGameObject : m_ObjectLst[i])
			pGameObject->Render();
	}
}

void CObjectMgr::Release()
{
	for (int i = 0; i < TYPE_END; ++i)
	{
		for_each(
			m_ObjectLst[i].begin(),
			m_ObjectLst[i].end(),
			SafeDelete<CGameObject*>);

		m_ObjectLst[i].clear();
	}
}
