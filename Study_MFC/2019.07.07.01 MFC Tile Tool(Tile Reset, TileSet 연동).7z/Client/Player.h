#pragma once
#include "GameObject.h"
class CPlayer :
	public CGameObject
{
public:
	CPlayer();
	virtual ~CPlayer();

public:
	// CGameObject��(��) ���� ��ӵ�
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render() override;

private:
	virtual HRESULT Initialize() override;
	virtual HRESULT LateInit() override;
	virtual void Release() override;

public:
	static CPlayer* Create();

private:
	void FrameMove(float fSpeed = 1.f);

private:
	INFO	m_tInfo;
	wstring m_wstrObjectKey;
	wstring m_wstrStateKey;
	float	m_fCurrentFrame;
	float	m_fMaxFrameCount;
};

