#pragma once
class CScrollMgr
{
public:
	CScrollMgr();
	~CScrollMgr();

public:
	static const D3DXVECTOR3& GetScrollPos();

public:
	static void SetScrollPos(const D3DXVECTOR3& vMove);

private:
	static D3DXVECTOR3 m_vScroll;
};

