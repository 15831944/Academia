#include "stdafx.h"
#include "Stage.h"
#include "Terrain.h"
#include "Player.h"

CStage::CStage()
{
}


CStage::~CStage()
{
	Release();
}

void CStage::Update()
{
	m_pObjectMgr->Update();
}

void CStage::LateUpdate()
{
	m_pObjectMgr->LateUpdate();
}

void CStage::Render()
{
	m_pObjectMgr->Render();
}

HRESULT CStage::Initialize()
{
	CGameObject* pGameObject = nullptr;
	HRESULT hr = 0;

	// Terrain
	pGameObject = CTerrain::Create();
	NULL_CHECK_MSG_RETURN(pGameObject, L"Terrain Create Failed", E_FAIL);

	hr = m_pObjectMgr->AddObject(CObjectMgr::TERRAIN, pGameObject);
	FAILED_CHECK_MSG_RETURN(hr, L"Terrain AddObject Failed", E_FAIL);

	// Player
	pGameObject = CPlayer::Create();
	NULL_CHECK_MSG_RETURN(pGameObject, L"Player Create Failed", E_FAIL);

	hr = m_pObjectMgr->AddObject(CObjectMgr::PLAYER, pGameObject);
	FAILED_CHECK_MSG_RETURN(hr, L"Player AddObject Failed", E_FAIL);

	return S_OK;
}

void CStage::Release()
{
}

CStage* CStage::Create()
{
	CStage* pInstance = new CStage;

	if (FAILED(pInstance->Initialize()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
