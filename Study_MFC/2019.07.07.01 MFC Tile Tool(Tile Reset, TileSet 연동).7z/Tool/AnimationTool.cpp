// AnimationTool.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Tool.h"
#include "AnimationTool.h"
#include "afxdialogex.h"
#include "Texture.h"
#include "MultiTexture.h"


// CAnimationTool ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CAnimationTool, CDialog)

CAnimationTool::CAnimationTool(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_ANIMATIONTOOL, pParent)
	, m_fFrameSpeed(0)
{

}

CAnimationTool::~CAnimationTool()
{
}

void CAnimationTool::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_vScale.x);
	DDX_Text(pDX, IDC_EDIT2, m_vScale.y);
	DDX_Text(pDX, IDC_EDIT4, m_vScale.z);
	DDX_Text(pDX, IDC_EDIT6, m_vRotZ.x);
	DDX_Text(pDX, IDC_EDIT7, m_vRotZ.y);
	DDX_Text(pDX, IDC_EDIT8, m_vRotZ.z);
	DDX_Text(pDX, IDC_EDIT9, m_vTrans.x);
	DDX_Text(pDX, IDC_EDIT10, m_vTrans.y);
	DDX_Text(pDX, IDC_EDIT11, m_vTrans.z);
	DDX_Text(pDX, IDC_EDIT12, m_vCenter.x);
	DDX_Text(pDX, IDC_EDIT13, m_vCenter.y);
	DDX_Text(pDX, IDC_EDIT14, m_vCenter.z);
	DDX_Control(pDX, IDC_LIST1, m_ObjectListBox);
	DDX_Control(pDX, IDC_LIST2, m_StateListBox);
	DDX_Control(pDX, IDC_LIST3, m_FrameListBox);
	DDX_Control(pDX, IDC_PICTURE_CONTROL, m_PictureCrtl);
	DDX_Text(pDX, IDC_EDIT15, m_fFrameSpeed);
}


BEGIN_MESSAGE_MAP(CAnimationTool, CDialog)
	ON_LBN_SELCHANGE(IDC_LIST3, &CAnimationTool::OnLbnSelchangeFrameList)
	ON_LBN_SELCHANGE(IDC_LIST1, &CAnimationTool::OnLbnSelchangeObjectList)
	ON_LBN_SELCHANGE(IDC_LIST2, &CAnimationTool::OnLbnSelchangeStateList)
	ON_BN_CLICKED(IDC_BUTTON2, &CAnimationTool::OnBnClickedPlay)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON10, &CAnimationTool::OnBnClickedStop)
	ON_BN_CLICKED(IDC_BUTTON1, &CAnimationTool::OnBnClickedApply)
END_MESSAGE_MAP()


BOOL CAnimationTool::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	UpdateData(TRUE);
	m_vScale = { 1.f, 1.f, 0.f };
	m_vRotZ = { 0.f, 0.f, 0.f };
	m_vTrans = { 0.f, 0.f, 0.f };
	m_vCenter = { 0.f, 0.f, 0.f };
	m_fFrameSpeed = 1.f;

	m_pTextureMgr = CTextureMgr::GetInstance();

	m_pTextureMgr->LoadTexture(CTextureMgr::MULTI_TEXTURE, L"../Texture/Stage/Player/Attack/AKIHA_AKI01_00%d.png", L"Player", L"Attack", 6);
	m_pTextureMgr->LoadTexture(CTextureMgr::MULTI_TEXTURE, L"../Texture/Stage/Player/Dash/AKIHA_AKI13_00%d.png", L"Player", L"Dash", 11);
	m_pTextureMgr->LoadTexture(CTextureMgr::MULTI_TEXTURE, L"../Texture/Stage/Player/Stand/AKIHA_AKI00_00%d.png", L"Player", L"Stand", 12);
	m_pTextureMgr->LoadTexture(CTextureMgr::MULTI_TEXTURE, L"../Texture/Stage/Player/Walk/AKIHA_AKI26_00%d.png", L"Player", L"Walk", 13);

	for (auto iter : m_pTextureMgr->GetMapTexture())
	{
		m_ObjectListBox.AddString(iter.first.c_str());

	}

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CAnimationTool::OnLbnSelchangeFrameList()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CDeviceMgr::GetInstance()->Render_Begin();

	CString ObjectKey;
	m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), ObjectKey);

	CString StateKey;
	m_StateListBox.GetText(m_StateListBox.GetCurSel(), StateKey);

	const TEX_INFO* pTexInfo = CTextureMgr::GetInstance()->GetTexInfo(
		(wstring)ObjectKey, (wstring)StateKey, m_FrameListBox.GetCurSel());
	NULL_CHECK(pTexInfo);

	D3DXMATRIX matScale;
	D3DXMATRIX matRotZ;
	D3DXMATRIX matTrans;
	D3DXMATRIX matWorld;

	D3DXMatrixIdentity(&matScale);
	D3DXMatrixIdentity(&matRotZ);
	D3DXMatrixIdentity(&matTrans);
	D3DXMatrixIdentity(&matWorld);

	D3DXMatrixScaling(&matScale, (float)WINCX / pTexInfo->tImgInfo.Width * m_vScale.x, (float)WINCY / pTexInfo->tImgInfo.Height * m_vScale.y, 0 * m_vScale.z);
	D3DXMatrixRotationZ(&matRotZ, D3DXToRadian(0));
	D3DXMatrixTranslation(&matTrans, WINCX / 2, WINCY / 2, 0.f);

	matWorld = matScale * matRotZ * matTrans;

	CDeviceMgr::GetInstance()->GetSprite()->SetTransform(&matWorld);
	CDeviceMgr::GetInstance()->GetSprite()->Draw(pTexInfo->pTexture, nullptr,
		&D3DXVECTOR3(pTexInfo->tImgInfo.Width*0.5f + m_vCenter.x, pTexInfo->tImgInfo.Height*0.5f + m_vCenter.y, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));

	CDeviceMgr::GetInstance()->Render_End(m_PictureCrtl.m_hWnd);
}


void CAnimationTool::OnLbnSelchangeObjectList()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_StateListBox.ResetContent();
	KillTimer(1);

	CString temp;
	m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), temp);
	auto map = dynamic_cast<CMultiTexture*>(m_pTextureMgr->GetMapTextureToIndex((wstring)temp))->GetMapMultiTexture();

	for (auto iter : *map)
	{
		m_StateListBox.AddString(iter.first.c_str());
	}
}


void CAnimationTool::OnLbnSelchangeStateList()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_FrameListBox.ResetContent();
	KillTimer(1);

	CString ObjectKey;
	m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), ObjectKey);

	CString StateKey;
	m_StateListBox.GetText(m_StateListBox.GetCurSel(), StateKey);

	size_t size = dynamic_cast<CMultiTexture*>(m_pTextureMgr->GetMapTextureToIndex((wstring)ObjectKey))->m_mapMultiTexture[wstring(StateKey)].size();

	for (size_t i = 0; i < size; ++i)
	{
		TCHAR Buf[256] = L"%02d";
		swprintf_s(Buf, Buf, i);
		m_FrameListBox.AddString(Buf);
	}
}


void CAnimationTool::OnBnClickedPlay()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	int iCount = m_FrameListBox.GetCount();
	SetTimer(1, 1000/iCount * m_fFrameSpeed, NULL);
}


void CAnimationTool::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CDialog::OnTimer(nIDEvent);
	
	int result = m_FrameListBox.SetCurSel(m_FrameListBox.GetCurSel() + 1);

	if(result == LB_ERR)
		m_FrameListBox.SetCurSel(0);

	OnLbnSelchangeFrameList();
}


void CAnimationTool::OnBnClickedStop()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	KillTimer(1);
}


void CAnimationTool::OnBnClickedApply()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	KillTimer(1);
	ERR_MSG(L"����Ǿ����ϴ�!");
	UpdateData(FALSE);
}
