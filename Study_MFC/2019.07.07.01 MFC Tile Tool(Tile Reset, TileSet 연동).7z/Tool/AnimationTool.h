#pragma once
#include "d3dx9math.h"
#include "afxwin.h"


// CAnimationTool ��ȭ �����Դϴ�.

class CAnimationTool : public CDialog
{
	DECLARE_DYNAMIC(CAnimationTool)

public:
	CAnimationTool(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CAnimationTool();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ANIMATIONTOOL };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
public:
	afx_msg void OnLbnSelchangeFrameList();
	afx_msg void OnLbnSelchangeObjectList();
	afx_msg void OnLbnSelchangeStateList();
	afx_msg void OnBnClickedPlay();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedStop();
public:
	CTextureMgr* m_pTextureMgr;
	D3DXVECTOR3 m_vScale;
	D3DXVECTOR3 m_vRotZ;
	D3DXVECTOR3 m_vTrans;
	D3DXVECTOR3 m_vCenter;

	CListBox m_ObjectListBox;
	CListBox m_StateListBox;
	CListBox m_FrameListBox;
	CStatic m_PictureCrtl;

	float m_fFrameSpeed;
	afx_msg void OnBnClickedApply();
};
