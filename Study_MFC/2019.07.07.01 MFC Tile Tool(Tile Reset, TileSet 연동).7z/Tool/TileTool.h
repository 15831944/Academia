#pragma once
#ifndef _TILE_TOOL_H_
#define _TILE_TOOL_H_
#include "afxcmn.h"

// CTileTool ��ȭ �����Դϴ�.
class CToolView;
class CTerrain;

class CTileToolTabTile;
class CTileToolTabWall;

class CTileTool : public CDialog
{
	DECLARE_DYNAMIC(CTileTool)

public:
	CTileTool(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CTileTool();

	// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TILETOOL };
#endif

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);


public: // Message Function
	DECLARE_MESSAGE_MAP()
	afx_msg void OnTcnSelchangeTiletoolTab(NMHDR *pNMHDR, LRESULT *pResult);


private: // Control Variable
	CTabCtrl m_TileToolTab;

private: // User Variable
	CToolView *m_pToolView;
	CTerrain *m_pTerrain;

	CTileToolTabTile *m_pTileToolTabTile;
	CTileToolTabWall *m_pTileToolTabWall;

public:
};


#endif