#pragma once
#ifndef _TILE_TOOL_TAB_TILE_H_
#define _TILE_TOOL_TAB_TILE_H_

#include "afxwin.h"


// CTileToolTabTile ��ȭ �����Դϴ�.
class CToolView;
class CMiniView;
class CTerrain;

class CTileToolTabTile : public CDialogEx
{
	DECLARE_DYNAMIC(CTileToolTabTile)

public:
	CTileToolTabTile(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CTileToolTabTile();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TILETOOL_DIALOG1 };
#endif

public: // Enum Variable
	enum LAYOUT_TYPE {
		TILE = 0,
		COLLISION,
		LAYOUT_END
	};

	enum ATTRIBUTE_TYPE {
		DRAWID = 0,
		OPTION,
		ATTRIBUTE_END
	};

public: // User Function


private:
	void CreateHorizontalScrollForListBox(CListBox *pListBox);
	void RenewTileToolRenderState();

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);


public: // Message Function
	DECLARE_MESSAGE_MAP()
	afx_msg void OnLbnSelchangeTiletoolTileListForDrawID();
	afx_msg void OnLbnSelchangeTiletoolTileListForOption();
	afx_msg void OnBnClickedTiletoolTileSave();
	afx_msg void OnBnClickedTiletoolTileLoad();
	afx_msg void OnBnClickedTiletoolTileHelp();
	afx_msg void OnBnClickedTiletoolTileCreateTile();
	afx_msg void OnBnClickedTiletoolTileResetTile();
	afx_msg void OnBnClickedTiletoolTileAttributeClear();
	afx_msg void OnBnClickedTiletoolTileDeleteTileSet();
	afx_msg void OnBnClickedTiletoolTileResetTileSet();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnBnClickedTiletoolTileLayoutTile();
	afx_msg void OnBnClickedTiletoolTileLayoutCollision();
	afx_msg void OnBnClickedTiletoolTileSelectDrawID();
	afx_msg void OnBnClickedTiletoolTileSelectOption();


private: // Control Variable
	CListBox m_TileToolListBoxForTileSet;
	CListBox m_TileToolListBoxForOption;
	CButton m_TileToolCheckBoxForLayout[LAYOUT_TYPE::LAYOUT_END];
	CButton m_TileToolCheckBoxForAttribute[ATTRIBUTE_TYPE::ATTRIBUTE_END];

	CStatic m_TileToolPictureCtrlForTileSet;
	CStatic m_TileToolPictureCtrlForOption;

private: // User Variable
	CToolView *m_pToolView;
	CMiniView *m_pMiniView;
	CTerrain *m_pTerrain;

	CDeviceMgr *m_pDeviceManager;
	CTextureMgr *m_pTextureManager;

	BYTE m_byTileToolDrawID;
	BYTE m_byTileToolOption;

public:
	
	int m_iTileToolTileX;
	int m_iTileToolTileY;
	int m_iTileToolTileSizeX;
	int m_iTileToolTileSizeY;
	
	
	
};

#endif