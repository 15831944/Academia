// TileToolTabWall.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Tool.h"
#include "TileToolTabWall.h"
#include "afxdialogex.h"


// CTileToolTabWall ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CTileToolTabWall, CDialogEx)

CTileToolTabWall::CTileToolTabWall(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_TILETOOL_DIALOG2, pParent)
{

}

CTileToolTabWall::~CTileToolTabWall()
{
}

void CTileToolTabWall::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CTileToolTabWall, CDialogEx)
END_MESSAGE_MAP()


// CTileToolTabWall �޽��� ó�����Դϴ�.
