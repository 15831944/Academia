#include "stdafx.h"
#include "Scene.h"


CScene::CScene()
	: m_pObjectMgr(CObjectMgr::GetInstance()),
	m_pSceneMgr(CSceneMgr::GetInstance())
{
}


CScene::~CScene()
{
}
