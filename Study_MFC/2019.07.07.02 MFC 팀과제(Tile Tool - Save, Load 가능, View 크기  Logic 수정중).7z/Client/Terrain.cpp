#include "stdafx.h"
#include "Terrain.h"
#include "ScrollMgr.h"


CTerrain::CTerrain()
{
}


CTerrain::~CTerrain()
{
	Release();
}

int CTerrain::Update()
{
	CGameObject::LateInit();

	POINT pt = {};
	GetCursorPos(&pt);
	ScreenToClient(g_hWnd, &pt);

	float fDeltaTime = m_pTimeMgr->GetDeltaTime();

	if (0 > pt.x)
		CScrollMgr::SetScrollPos(D3DXVECTOR3(-100.f * fDeltaTime, 0.f, 0.f));
	if (WINCX < pt.x)
		CScrollMgr::SetScrollPos(D3DXVECTOR3(100.f * fDeltaTime, 0.f, 0.f));
	if (0 > pt.y)
		CScrollMgr::SetScrollPos(D3DXVECTOR3(0.f, -100.f * fDeltaTime, 0.f));
	if (WINCY < pt.y)
		CScrollMgr::SetScrollPos(D3DXVECTOR3(0.f, 100.f * fDeltaTime, 0.f));

	return NO_EVENT;
}

void CTerrain::LateUpdate()
{
}

void CTerrain::Render()
{
	D3DXMATRIX matScale, matTrans, matWorld;	

	TCHAR szIndex[MIN_STR] = L"";

	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		D3DXMatrixScaling(&matScale, 
			m_vecTile[i]->vSize.x, 
			m_vecTile[i]->vSize.y, 
			0.f);
		D3DXMatrixTranslation(&matTrans, 
			m_vecTile[i]->vPos.x - CScrollMgr::GetScrollPos().x, 
			m_vecTile[i]->vPos.y - CScrollMgr::GetScrollPos().y,
			0.f);

		matWorld = matScale * matTrans;

		m_pDeviceMgr->GetSprite()->SetTransform(&matWorld);

		const TEX_INFO* pTexInfo = m_pTextureMgr->GetTexInfo(
			L"Terrain", L"Tile", m_vecTile[i]->byDrawID);
		NULL_CHECK(pTexInfo);

		float fCenterX = pTexInfo->tImgInfo.Width * 0.5f;
		float fCenterY = pTexInfo->tImgInfo.Height * 0.5f;

		m_pDeviceMgr->GetSprite()->Draw(pTexInfo->pTexture, nullptr,
			&D3DXVECTOR3(fCenterX, fCenterY, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));
	
	}
}

HRESULT CTerrain::Initialize()
{
	HRESULT hr = LoadTile(L"../Data/MapData.dat");
	FAILED_CHECK_MSG_RETURN(hr, L"MapData.dat Load Failed", E_FAIL);

	return S_OK;
}

HRESULT CTerrain::LateInit()
{
	return S_OK;
}

void CTerrain::Release()
{
	for_each(m_vecTile.begin(), m_vecTile.end(), SafeDelete<TILE_INFO*>);
	m_vecTile.clear();
	m_vecTile.shrink_to_fit();
}

CTerrain* CTerrain::Create()
{
	CTerrain* pInstance = new CTerrain;

	if (FAILED(pInstance->Initialize()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}	

	return pInstance;
}

HRESULT CTerrain::LoadTile(const TCHAR * pFilePath)
{
	HANDLE hFile = CreateFile(pFilePath, GENERIC_READ, 0, 0,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);

	if (INVALID_HANDLE_VALUE == hFile)
		return E_FAIL;

	if (!m_vecTile.empty())
		Release();

	DWORD dwBytes = 0;
	TILE_INFO* pTile = nullptr;
	TILE_INFO tReadTile = {};

	while (true)
	{
		ReadFile(hFile, &tReadTile, sizeof(TILE_INFO), &dwBytes, nullptr);

		if (0 == dwBytes)
			break;

		pTile = new TILE_INFO(tReadTile);
		m_vecTile.push_back(pTile);
	}

	CloseHandle(hFile);

	return S_OK;
}