#pragma once

#include "GameObject.h"

class CTerrain : public CGameObject
{
private:
	explicit CTerrain();

public:
	~CTerrain();

public:
	virtual int Update();
	virtual void LateUpdate();
	virtual void Render();

private:
	virtual HRESULT Initialize();
	virtual HRESULT LateInit();
	virtual void Release();

public:
	static CTerrain* Create();

private:
	HRESULT LoadTile(const TCHAR * pFilePath);

private:
	vector<TILE_INFO*>	m_vecTile;

};

