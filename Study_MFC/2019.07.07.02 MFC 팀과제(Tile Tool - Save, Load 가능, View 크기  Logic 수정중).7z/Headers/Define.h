#pragma once

#ifndef __DEFINE_H__

#define NO_EVENT 0
#define DEAD_OBJ 1

#define WINCX 800
#define WINCY 600

#define TILECX 130
#define TILECY 68

#define TILEX 20
#define TILEY 30

#define MIN_STR 64
#define MID_STR 128
#define MAX_STR 256

#define RUBY		0x0001
#define SAPPHIRE	0x0002
#define DIAMOND		0x0004

// ##########################################################################
#define TILETOOL_TILESIZE_X 24
#define TILETOOL_TILESIZE_Y 24

// ##########################################################################

#ifdef CLIENT
#define ERR_MSG(msg)	\
MessageBox(nullptr, msg, L"System Error", MB_OK)
#else
#define ERR_MSG(msg)	\
AfxMessageBox(msg)
#endif

#define NULL_CHECK(ptr)	\
if(nullptr == (ptr))	\
	return;

#define NULL_CHECK_MSG(ptr, msg)	\
if(nullptr == (ptr))				\
{									\
	ERR_MSG(msg);					\
	return;							\
}

#define NULL_CHECK_RETURN(ptr, returnVal)	\
if(nullptr == (ptr))						\
	return returnVal;

#define NULL_CHECK_MSG_RETURN(ptr, msg, returnVal)	\
if(nullptr == (ptr))								\
{													\
	ERR_MSG(msg);									\
	return returnVal;								\
}

#define FAILED_CHECK(hr)	\
if(FAILED(hr))				\
	return;

#define FAILED_CHECK_MSG(hr, msg)	\
if(FAILED(hr))						\
{									\
	ERR_MSG(msg);					\
	return;							\
}

#define FAILED_CHECK_RETURN(hr, returnVal)	\
if(FAILED(hr))								\
	return returnVal;

#define FAILED_CHECK_MSG_RETURN(hr, msg, returnVal)	\
if(FAILED(hr))										\
{													\
	ERR_MSG(msg);									\
	return returnVal;								\
}

#define NO_COPY(ClassName)						\
private:										\
	ClassName(const ClassName&);				\
	ClassName& operator=(const ClassName&);

#define DECLARE_SINGLETON(ClassName)			\
		NO_COPY(ClassName)						\
public:											\
	static ClassName* GetInstance();			\
	void DestroyInstance();						\
private:										\
	static ClassName* m_pInstance;

#define IMPLEMENT_SINGLETON(ClassName)			\
ClassName* ClassName::m_pInstance = nullptr;	\
ClassName* ClassName::GetInstance()				\
{												\
	if(nullptr == m_pInstance)					\
		m_pInstance = new ClassName;			\
	return m_pInstance;							\
}												\
void ClassName::DestroyInstance()				\
{												\
	if(m_pInstance)								\
	{											\
		delete m_pInstance;						\
		m_pInstance = nullptr;					\
	}											\
}

#define __DEFINE_H__
#endif