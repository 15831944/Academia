#pragma once

#ifndef __STRUCT_H__

typedef struct tagInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vDir;
	D3DXVECTOR3 vLook;
	D3DXVECTOR3 vSize;

	D3DXMATRIX matWorld;
}INFO;

typedef struct tagUnitData
{
#ifdef CLIENT
	wstring strName = L"";
#else
	CString strName = L"";
#endif
	int iAtt = 0;
	int iDef = 0;
	int iJobIndex = 0;
	int iItem = 0;
}UNIT_DATA;

typedef struct tagAnimInfo
{
	D3DXMATRIX matScale;
	D3DXMATRIX matRotZ;
	D3DXMATRIX matTrans;
	D3DXMATRIX matWorld;

	float m_fFrameSpeed;
}ANIM_INFO;

typedef struct tagTextureInfo
{
	LPDIRECT3DTEXTURE9	pTexture;	// Texture Com��ü
	D3DXIMAGE_INFO		tImgInfo;	// Texture�� ���� ����.
	ANIM_INFO			tAnimInfo;
}TEX_INFO;

typedef struct tagTileInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vSize;
	BYTE		byDrawID;
	BYTE		byOption;
}TILE_INFO;

typedef struct tagTileToolTerrainInfo
{
	tagTileToolTerrainInfo(int tileX, int tileY, int tileWidth, int tileHeight)
		: iTileX(tileX), iTileY(tileY),
		iTileSizeX(tileWidth), iTileSizeY(tileHeight)
	{

	}

	int iTileX;
	int iTileY;
	int iTileSizeX;
	int iTileSizeY;
} TILETOOL_TERRAIN_INFO;



#define __STRUCT_H__
#endif