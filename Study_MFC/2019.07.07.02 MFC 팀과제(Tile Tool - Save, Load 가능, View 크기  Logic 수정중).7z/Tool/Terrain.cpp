#include "..\Client\Terrain.h"
#include "stdafx.h"
#include "Terrain.h"
#include "ToolView.h"

CTerrain::CTerrain()
{

}


CTerrain::~CTerrain()
{
	Release();
}

void CTerrain::SetToolView(CToolView * pView)
{
	m_pToolView = pView;
}

void CTerrain::Render()
{
	D3DXMATRIX matScale, matTrans, matWorld;

	TCHAR szIndex[MIN_STR] = L"";

	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		if (m_bIsCheckedLayout[LAYOUT_TYPE::TILE])
		{
			D3DXMatrixScaling(
				&matScale,
				m_vecTile[i]->vSize.x,
				m_vecTile[i]->vSize.y,
				0.f
			);
			D3DXMatrixTranslation(
				&matTrans,
				m_vecTile[i]->vPos.x - m_pToolView->GetScrollPos(0),
				m_vecTile[i]->vPos.y - m_pToolView->GetScrollPos(1),
				0.f
			);

			matWorld = matScale * matTrans;

			CDeviceMgr::GetInstance()->GetSprite()->SetTransform(&matWorld);

			const TEX_INFO* pTexInfo = CTextureMgr::GetInstance()->GetTexInfo(
				L"Terrain", L"Tile", m_vecTile[i]->byDrawID);
			NULL_CHECK(pTexInfo);

			float fCenterX = pTexInfo->tImgInfo.Width * 0.5f;
			float fCenterY = pTexInfo->tImgInfo.Height * 0.5f;

			CDeviceMgr::GetInstance()->GetSprite()->Draw(pTexInfo->pTexture, nullptr,
				&D3DXVECTOR3(fCenterX, fCenterY, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));
		}


		if (m_bIsCheckedLayout[LAYOUT_TYPE::COLLISION])
		{
			D3DXMatrixScaling(&matScale, m_vecTile[i]->vSize.x, m_vecTile[i]->vSize.y, 0.f);
			D3DXMatrixTranslation(&matTrans,
				m_vecTile[i]->vPos.x - m_pToolView->GetScrollPos(0),
				m_vecTile[i]->vPos.y - m_pToolView->GetScrollPos(1),
				0.f);

			matWorld = matScale * matTrans;

			CDeviceMgr::GetInstance()->GetSprite()->SetTransform(&matWorld);

			const TEX_INFO* pTexInfo = CTextureMgr::GetInstance()->GetTexInfo(
				L"Terrain", L"Option", m_vecTile[i]->byOption);
			NULL_CHECK(pTexInfo);

			float fCenterX = pTexInfo->tImgInfo.Width * 0.5f;
			float fCenterY = pTexInfo->tImgInfo.Height * 0.5f;

			CDeviceMgr::GetInstance()->GetSprite()->Draw(pTexInfo->pTexture, nullptr,
				&D3DXVECTOR3(fCenterX, fCenterY, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255)
			);

		}

	}

	if (m_bIsCheckedLayout[LAYOUT_TYPE::TILE]
		|| m_bIsCheckedLayout[LAYOUT_TYPE::COLLISION])
	{
		for (size_t i = 0; i < m_vecTile.size(); ++i)
		{
			D3DXMatrixScaling(
				&matScale,
				m_vecTile[i]->vSize.x,
				m_vecTile[i]->vSize.y,
				0.f
			);
			D3DXMatrixTranslation(
				&matTrans,
				m_vecTile[i]->vPos.x - m_pToolView->GetScrollPos(0),
				m_vecTile[i]->vPos.y - m_pToolView->GetScrollPos(1),
				0.f
			);

			// ��Ʈ ���
			swprintf_s(szIndex, L"%d", i);

			CDeviceMgr::GetInstance()->GetSprite()->SetTransform(&matTrans);

			CDeviceMgr::GetInstance()->GetFont()->DrawTextW(
				CDeviceMgr::GetInstance()->GetSprite(), /* ���̷�Ʈ ��Ʈ�� ����� ������ �ؽ�ó ���� */
				szIndex, /* ����� �ؽ�Ʈ */
				lstrlen(szIndex), /* �ؽ�Ʈ ���� */
				nullptr, /* �簢�� ���� */
				0,
				D3DCOLOR_ARGB(255, 255, 255, 255) /* ��� ���� */
			);
		}
	}
}

void CTerrain::MiniRender()
{
	D3DXMATRIX matScale, matTrans, matWorld;

	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		if (m_bIsCheckedLayout[LAYOUT_TYPE::TILE])
		{
			D3DXMatrixScaling(&matScale,
				m_vecTile[i]->vSize.x * 0.3f,
				m_vecTile[i]->vSize.y * 0.3f,
				0.f);
			D3DXMatrixTranslation(&matTrans,
				m_vecTile[i]->vPos.x * 0.3f,
				m_vecTile[i]->vPos.y * 0.3f,
				0.f);

			matWorld = matScale * matTrans;

			CDeviceMgr::GetInstance()->GetSprite()->SetTransform(&matWorld);

			const TEX_INFO* pTexInfo = CTextureMgr::GetInstance()->GetTexInfo(
				L"Terrain", L"Tile", m_vecTile[i]->byDrawID);
			NULL_CHECK(pTexInfo);

			float fCenterX = pTexInfo->tImgInfo.Width * 0.5f;
			float fCenterY = pTexInfo->tImgInfo.Height * 0.5f;

			CDeviceMgr::GetInstance()->GetSprite()->Draw(pTexInfo->pTexture, nullptr,
				&D3DXVECTOR3(fCenterX, fCenterY, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));
		}

		if (m_bIsCheckedLayout[LAYOUT_TYPE::COLLISION])
		{
			D3DXMatrixScaling(&matScale,
				m_vecTile[i]->vSize.x * 0.3f,
				m_vecTile[i]->vSize.y * 0.3f,
				0.f);
			D3DXMatrixTranslation(&matTrans,
				m_vecTile[i]->vPos.x * 0.3f,
				m_vecTile[i]->vPos.y * 0.3f,
				0.f);

			matWorld = matScale * matTrans;

			CDeviceMgr::GetInstance()->GetSprite()->SetTransform(&matWorld);

			const TEX_INFO* pTexInfo = CTextureMgr::GetInstance()->GetTexInfo(
				L"Terrain", L"Option", m_vecTile[i]->byOption);
			NULL_CHECK(pTexInfo);

			float fCenterX = pTexInfo->tImgInfo.Width * 0.5f;
			float fCenterY = pTexInfo->tImgInfo.Height * 0.5f;

			CDeviceMgr::GetInstance()->GetSprite()->Draw(pTexInfo->pTexture, nullptr,
				&D3DXVECTOR3(fCenterX, fCenterY, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));
		}


	}
}

void CTerrain::TileChange(
	const D3DXVECTOR3& vPos,
	const BYTE& byDrawID,
	const BYTE& byOption)
{
	int iIndex = GetTileIndex(vPos);

	if (0 > iIndex || m_vecTile.size() <= (size_t)iIndex)
		return;

	if (m_bIsCheckedAttribute[ATTRIBUTE_TYPE::DRAWID])
	{
		m_vecTile[iIndex]->byDrawID = byDrawID;
	}

	if (m_bIsCheckedAttribute[ATTRIBUTE_TYPE::OPTION])
	{
		m_vecTile[iIndex]->byOption = byOption;
	}
}

HRESULT CTerrain::SaveTile(const TCHAR * pFilePath)
{
	HANDLE hFile = CreateFile(pFilePath, GENERIC_WRITE, 0, 0,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);

	if (INVALID_HANDLE_VALUE == hFile)
		return E_FAIL;

	DWORD dwBytes = 0;

	// ################################################################################
	// ũ�� ������ ���� !!!!
	WriteFile(hFile, &m_iTileX, sizeof(int), &dwBytes, nullptr);
	WriteFile(hFile, &m_iTileY, sizeof(int), &dwBytes, nullptr);
	WriteFile(hFile, &m_iTileSizeX, sizeof(int), &dwBytes, nullptr);
	WriteFile(hFile, &m_iTileSizeY, sizeof(int), &dwBytes, nullptr);

	// ################################################################################

	for (auto& pTile : m_vecTile)
		WriteFile(hFile, pTile, sizeof(TILE_INFO), &dwBytes, nullptr);

	CloseHandle(hFile);

	return S_OK;
}

HRESULT CTerrain::LoadTile(const TCHAR * pFilePath)
{
	HANDLE hFile = CreateFile(pFilePath, GENERIC_READ, 0, 0,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);

	if (INVALID_HANDLE_VALUE == hFile)
		return E_FAIL;

	if (!m_vecTile.empty())
		Release();

	DWORD dwBytes = 0;
	TILE_INFO* pTile = nullptr;
	TILE_INFO tReadTile = {};

	// ###########################################################################
	// ������ ��, m_iTileX, m_iTileY, m_iTileSizeX, m_iTileSizeY ��������� �մϴ�.
	// Initial Setting
	// ###########################################################################

	ReadFile(hFile, &m_iTileX, sizeof(int), &dwBytes, nullptr);
	ReadFile(hFile, &m_iTileY, sizeof(int), &dwBytes, nullptr);
	ReadFile(hFile, &m_iTileSizeX, sizeof(int), &dwBytes, nullptr);
	ReadFile(hFile, &m_iTileSizeY, sizeof(int), &dwBytes, nullptr);

	while (true)
	{
		ReadFile(hFile, &tReadTile, sizeof(TILE_INFO), &dwBytes, nullptr);

		if (0 == dwBytes)
			break;

		pTile = new TILE_INFO(tReadTile);
		m_vecTile.push_back(pTile);
	}

	CloseHandle(hFile);

	return S_OK;
}

void CTerrain::Release()
{
	for_each(m_vecTile.begin(), m_vecTile.end(), SafeDelete<TILE_INFO*>);
	m_vecTile.clear();
	m_vecTile.shrink_to_fit();
}

HRESULT CTerrain::Initialize()
{
	/*
	m_vecTile.reserve(TILEX * TILEY);

	TILE_INFO* pTile = nullptr;

	for (int i = 0; i < TILEY; ++i)
	{
		for (int j = 0; j < TILEX; ++j)
		{
			pTile = new TILE_INFO;

			pTile->vPos.x = (j * TILECX) + (i % 2) * (TILECX * 0.5f);
			pTile->vPos.y = i * (TILECY * 0.5f);
			pTile->vSize = { 1.f, 1.f, 0.f };
			pTile->byDrawID = 2;
			pTile->byOption = 0;

			m_vecTile.push_back(pTile);
		}
	}
	*/


	m_bIsCheckedLayout[LAYOUT_TYPE::TILE] = true;
	m_bIsCheckedLayout[LAYOUT_TYPE::COLLISION] = false;

	m_bIsCheckedAttribute[ATTRIBUTE_TYPE::DRAWID] = true;
	m_bIsCheckedAttribute[ATTRIBUTE_TYPE::OPTION] = true;

	m_vecTile.reserve(20 * 20); // �׳� Default

	return CTerrain::CreateTile(20, 20, 24, 24);
}



int CTerrain::GetTileIndex(const D3DXVECTOR3& vPos)
{
	/*
	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		if (IsPicking(vPos, i))
			return (int)i;
	}

	return -1;
	*/

	if (vPos.x < 0
		|| vPos.x >= m_iTileSizeX * m_iTileX
		|| vPos.y < 0
		|| vPos.y >= m_iTileSizeY * m_iTileY)
	{
		return -1;
	}

	int x = (int)vPos.x / m_iTileSizeX;
	int y = (int)vPos.y / m_iTileSizeY;

	return (m_iTileX * y) + x;
}

//bool CTerrain::IsPicking(const D3DXVECTOR3& vPos, size_t index)
//{
//	// ���� (��ī��Ʈ ����)
//
//	// 12, 3, 6, 9�� ������
//	D3DXVECTOR3 vPoint[4] =
//	{
//		{ m_vecTile[index]->vPos.x, m_vecTile[index]->vPos.y + TILECY * 0.5f, 0.f },
//		{ m_vecTile[index]->vPos.x + TILECX * 0.5f, m_vecTile[index]->vPos.y, 0.f },
//		{ m_vecTile[index]->vPos.x, m_vecTile[index]->vPos.y - TILECY * 0.5f, 0.f },
//		{ m_vecTile[index]->vPos.x - TILECX * 0.5f, m_vecTile[index]->vPos.y, 0.f }
//	};
//
//	// �ð���� ����
//	D3DXVECTOR3 vDir[4] =
//	{
//		vPoint[1] - vPoint[0],
//		vPoint[2] - vPoint[1],
//		vPoint[3] - vPoint[2],
//		vPoint[0] - vPoint[3]
//	};
//
//	// �� ���⺤���� ��������
//	D3DXVECTOR3 vNormal[4] = {};
//
//	for (int i = 0; i < 4; ++i)
//		D3DXVec3Cross(&vNormal[i], &D3DXVECTOR3(0.f, 0.f, 1.f), &vDir[i]);
//
//	// �������� ���콺��ǥ�� ���⺤��
//	D3DXVECTOR3 vMouseDir[4] =
//	{
//		vPos - vPoint[0],
//		vPos - vPoint[1],
//		vPos - vPoint[2],
//		vPos - vPoint[3]
//	};
//
//	// vNormal�� vMouseDir�� ������ ���ؼ� ��� ������ ������ True
//	for (int i = 0; i < 4; ++i)
//	{
//		if (0 < D3DXVec3Dot(&vMouseDir[i], &vNormal[i]))
//			return false;
//	}
//
//	return true;
//}

HRESULT CTerrain::CreateTile(int tileX, int tileY, int sizeX, int sizeY, BYTE drawID /*= 0*/, BYTE option /*= 0*/)
{
	for (int i = 0; i < tileY; ++i)
	{
		for (int j = 0; j < tileX; ++j)
		{
			TILE_INFO *pTile = new TILE_INFO;
			NULL_CHECK_MSG_RETURN(pTile, L"TILE_INFO memory allocation Failed, CTerrain::CreateTile()", E_FAIL);

			float m_fExtendedSizeRateX = sizeX / (float)TILETOOL_TILESIZE_X;
			float m_fExtendedSizeRateY = sizeY / (float)TILETOOL_TILESIZE_Y;

			pTile->vSize = {
				m_fExtendedSizeRateX,
				m_fExtendedSizeRateY,
				0.0f
			};

			pTile->vPos.x = (sizeX * j) + (sizeX * 0.5f);
			pTile->vPos.y = (sizeY * i) + (sizeY * 0.5f);


			pTile->byDrawID = drawID;
			pTile->byOption = option;

			m_vecTile.emplace_back(pTile);
		}
	}

	m_iTileX = tileX;
	m_iTileY = tileY;
	m_iTileSizeX = sizeX;
	m_iTileSizeY = sizeY;

	return S_OK;
}

void CTerrain::ResetTileAttribute()
{
	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		m_vecTile[i]->byDrawID = 0;
		m_vecTile[i]->byOption = 0;
	}
}

CTerrain* CTerrain::Create(CToolView * pView)
{
	CTerrain* pInstance = new CTerrain;

	if (FAILED(pInstance->Initialize()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	pInstance->SetToolView(pView);

	return pInstance;
}
