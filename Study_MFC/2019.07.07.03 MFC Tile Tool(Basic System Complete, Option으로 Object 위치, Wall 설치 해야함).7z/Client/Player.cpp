#include "stdafx.h"
#include "Player.h"


CPlayer::CPlayer()
{
	ZeroMemory(&m_tInfo, sizeof(INFO));
	D3DXMatrixIdentity(&m_tInfo.matWorld);
}


CPlayer::~CPlayer()
{
	Release();
}

int CPlayer::Update()
{
	CGameObject::LateInit();
	FrameMove(1.5f);

	D3DXMATRIX matScale, matTrans;
	D3DXMatrixScaling(&matScale, m_tInfo.vSize.x, m_tInfo.vSize.y, 0.f);
	D3DXMatrixTranslation(&matTrans, m_tInfo.vPos.x, m_tInfo.vPos.y, 0.f);

	m_tInfo.matWorld = matScale * matTrans;

	cout << m_tInfo.vPos.x << '\t' << m_tInfo.vPos.y << endl;
	return NO_EVENT;
}

void CPlayer::LateUpdate()
{
}

void CPlayer::Render()
{
	const TEX_INFO* pTexInfo = m_pTextureMgr->GetTexInfo(
		m_wstrObjectKey, m_wstrStateKey, (int)m_fCurrentFrame);
	NULL_CHECK(pTexInfo);

	float fCenterX = pTexInfo->tImgInfo.Width * 0.5f;
	float fCenterY = pTexInfo->tImgInfo.Height * 0.5f;

	m_pDeviceMgr->GetSprite()->SetTransform(&m_tInfo.matWorld);
	m_pDeviceMgr->GetSprite()->Draw(pTexInfo->pTexture, nullptr,
		&D3DXVECTOR3(fCenterX, fCenterY, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));
}

HRESULT CPlayer::Initialize()
{
	m_tInfo.vPos = { 400.f, 300.f, 0.f };
	m_tInfo.vSize = { 1.f, 1.f, 0.f };

	m_wstrObjectKey = L"Player";
	m_wstrStateKey = L"Stand";
	m_fCurrentFrame = 0.f;
	m_fMaxFrameCount = 12.f;

	return S_OK;
}

HRESULT CPlayer::LateInit()
{
	return S_OK;
}

void CPlayer::Release()
{
}

CPlayer* CPlayer::Create()
{
	CPlayer* pInstance = new CPlayer;

	if (FAILED(pInstance->Initialize()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}

void CPlayer::FrameMove(float fSpeed/* = 1.f*/)
{
	m_fCurrentFrame += m_fMaxFrameCount * m_pTimeMgr->GetDeltaTime() * fSpeed;

	if (m_fCurrentFrame >= m_fMaxFrameCount)
		m_fCurrentFrame = 0.f;
}
