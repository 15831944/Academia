#pragma once

#ifndef __EXTERN_H__

extern HWND g_hWnd;

#define __EXTERN_H__
#endif