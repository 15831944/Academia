#pragma once

class CToolView;
class CTerrain
{
private:
	explicit CTerrain();

public:
	~CTerrain();

public:
	enum LAYOUT_TYPE {
		TILE = 0,
		COLLISION,
		LAYOUT_END
	};
	enum ATTRIBUTE_TYPE {
		DRAWID = 0,
		OPTION,
		ATTRIBUTE_END
	};

public:
	void SetToolView(CToolView* pView);

public:
	void Render();
	void MiniRender();
	void TileChange(
		const D3DXVECTOR3& vPos,
		const BYTE& byDrawID,
		const BYTE& byOption = 0);
	HRESULT SaveTile(const TCHAR* pFilePath);
	HRESULT LoadTile(const TCHAR* pFilePath);

	void AdjustMiniViewRenderRate(const TILETOOL_TERRAIN_INFO &terrainInfo);

	void Release();

private:
	HRESULT Initialize();
	int GetTileIndex(const D3DXVECTOR3& vPos);
	//bool IsPicking(const D3DXVECTOR3& vPos, size_t index);

	// ###########################################
public: // �߰��� ��.
	bool IsTileVecEmpty() const { return m_vecTile.empty(); }
	HRESULT CreateTile(int tileX, int tileY, int sizeX, int sizeY, BYTE drawID = 0, BYTE option = 0); // ����ִ� Ÿ�� + ������ �� ����.(����, ������ ���� �ǹ̰� �޶���.)
	void ResetTileAttribute();

public:
	const TILETOOL_TERRAIN_INFO getTerrainTileInfo() { return TILETOOL_TERRAIN_INFO(m_iTileX, m_iTileY, m_iTileSizeX, m_iTileSizeY); }

public:
	void setIsCheckedLayout(CTerrain::LAYOUT_TYPE eLayoutType, bool isTrue) { m_bIsCheckedLayout[eLayoutType] = isTrue; }
	void setIsCheckedAttribute(CTerrain::ATTRIBUTE_TYPE eAttributeType, bool isTrue) { m_bIsCheckedAttribute[eAttributeType] = isTrue; }
	// ###########################################


public:
	static CTerrain* Create(CToolView* pView);

private:
	vector<TILE_INFO*>	m_vecTile;
	CToolView*			m_pToolView;

	// ###########################################
	int m_iTileX;
	int m_iTileY;
	int m_iTileSizeX;
	int m_iTileSizeY;

	bool m_bIsCheckedLayout[CTerrain::LAYOUT_TYPE::LAYOUT_END];
	bool m_bIsCheckedAttribute[CTerrain::ATTRIBUTE_TYPE::ATTRIBUTE_END];

	float m_fMiniViewRateX;
	float m_fMiniViewRateY;

	float m_fExtendedSizeRateX;
	float m_fExtendedSizeRateY;
	// ###########################################

};

