#pragma once
class CFrameMgr
{
	DECLARE_SINGLETON(CFrameMgr)

private:
	CFrameMgr();
	~CFrameMgr();

public:
	void InitTime();
	bool LimitFrame(float fLimit);
	void RenderFrame(CDeviceMgr* pDeviceMgr);

private:
	LARGE_INTEGER	m_OldTime;
	LARGE_INTEGER	m_CurTime;
	LARGE_INTEGER	m_CPUTick;

	float			m_fTimeCount = 0.f;
	float			m_fLimitCount = 0.f;
	int				m_iFPS_Count = 0;

	TCHAR			m_szBuffer[MIN_STR] = L"";
};

