#include "stdafx.h"
#include "Maingame.h"


CMaingame::CMaingame()
	: m_pDeviceMgr(CDeviceMgr::GetInstance()),
	m_pTextureMgr(CTextureMgr::GetInstance()),
	m_pObjectMgr(CObjectMgr::GetInstance()),
	m_pSceneMgr(CSceneMgr::GetInstance()),
	m_pTimeMgr(CTimeMgr::GetInstance()),
	m_pFrameMgr(CFrameMgr::GetInstance())
{
}


CMaingame::~CMaingame()
{
	Release();
}

void CMaingame::Update()
{
	m_pTimeMgr->UpdateTime();
	m_pSceneMgr->Update();
}

void CMaingame::LateUpdate()
{
	m_pSceneMgr->LateUpdate();
}

void CMaingame::Render()
{
	m_pDeviceMgr->Render_Begin();

	m_pSceneMgr->Render();
	m_pFrameMgr->RenderFrame(m_pDeviceMgr);

	m_pDeviceMgr->Render_End();
}

HRESULT CMaingame::Initialize()
{
	HRESULT hr = 0;

	m_pTimeMgr->InitTime();
	m_pFrameMgr->InitTime();

	hr = m_pDeviceMgr->InitDevice(g_hWnd, WINCX, WINCY, CDeviceMgr::MODE_WIN);
	FAILED_CHECK_MSG_RETURN(hr, L"InitDevice Failed", E_FAIL);

	hr = m_pTextureMgr->LoadTexture(
		CTextureMgr::MULTI_TEXTURE, L"../Texture/Stage/Terrain/Tile/Tile%d.png",
		L"Terrain", L"Tile", 38);
	FAILED_CHECK_MSG_RETURN(hr, L"Tile Texture Load Failed", E_FAIL);

	hr = m_pTextureMgr->LoadTexture(
		CTextureMgr::MULTI_TEXTURE, L"../Texture/Stage/Player/Dash/AKIHA_AKI13_00%d.png",
		L"Player", L"Dash", 11);
	FAILED_CHECK_MSG_RETURN(hr, L"Player Dash Texture Load Failed", E_FAIL);

	hr = m_pTextureMgr->LoadTexture(
		CTextureMgr::MULTI_TEXTURE, L"../Texture/Stage/Player/Stand/AKIHA_AKI00_00%d.png",
		L"Player", L"Stand", 12);
	FAILED_CHECK_MSG_RETURN(hr, L"Player Stand Texture Load Failed", E_FAIL);

	hr = m_pSceneMgr->SceneChange(CSceneMgr::LOGO);
	FAILED_CHECK_MSG_RETURN(hr, L"Logo Scene Change Failed", E_FAIL);

	return S_OK;
}

void CMaingame::Release()
{
	m_pFrameMgr->DestroyInstance();
	m_pTimeMgr->DestroyInstance();
	m_pSceneMgr->DestroyInstance();
	m_pObjectMgr->DestroyInstance();
	m_pTextureMgr->DestroyInstance();
	m_pDeviceMgr->DestroyInstance();
}

CMaingame* CMaingame::Create()
{
	CMaingame* pInstance = new CMaingame;

	if (FAILED(pInstance->Initialize()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
