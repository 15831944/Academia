#pragma once

class CGameObject;
class CObjectMgr
{
	DECLARE_SINGLETON(CObjectMgr)

public:
	enum OBJECT_TYPE { TERRAIN, PLAYER, MONSTER, TYPE_END };

private:
	CObjectMgr();
	~CObjectMgr();

public:
	HRESULT AddObject(OBJECT_TYPE eType, CGameObject* pObject);
	void Update();
	void LateUpdate();
	void Render();

private:
	void Release();

private:
	list<CGameObject*>	m_ObjectLst[TYPE_END];
};

