#include "stdafx.h"
#include "ScrollMgr.h"

D3DXVECTOR3 CScrollMgr::m_vScroll = {};

CScrollMgr::CScrollMgr()
{
}


CScrollMgr::~CScrollMgr()
{
}

const D3DXVECTOR3 & CScrollMgr::GetScrollPos()
{
	// TODO: ���⿡ ��ȯ ������ �����մϴ�.
	return m_vScroll;
}

void CScrollMgr::SetScrollPos(const D3DXVECTOR3& vMove)
{
	m_vScroll += vMove;
}
