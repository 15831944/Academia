// AnimationTool.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Tool.h"
#include "AnimationTool.h"
#include "afxdialogex.h"
#include "Texture.h"
#include "MultiTexture.h"


// CAnimationTool ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CAnimationTool, CDialog)

CAnimationTool::CAnimationTool(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_ANIMATIONTOOL, pParent)
	, m_fFrameSpeed(0)
{

}

CAnimationTool::~CAnimationTool()
{
}

void CAnimationTool::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_vScale.x);
	DDX_Text(pDX, IDC_EDIT2, m_vScale.y);
	DDX_Text(pDX, IDC_EDIT4, m_vScale.z);
	DDX_Text(pDX, IDC_EDIT6, m_vRotZ.x);
	DDX_Text(pDX, IDC_EDIT7, m_vRotZ.y);
	DDX_Text(pDX, IDC_EDIT8, m_vRotZ.z);
	DDX_Text(pDX, IDC_EDIT9, m_vTrans.x);
	DDX_Text(pDX, IDC_EDIT10, m_vTrans.y);
	DDX_Text(pDX, IDC_EDIT11, m_vTrans.z);
	DDX_Text(pDX, IDC_EDIT12, m_vCenter.x);
	DDX_Text(pDX, IDC_EDIT13, m_vCenter.y);
	DDX_Text(pDX, IDC_EDIT14, m_vCenter.z);
	DDX_Control(pDX, IDC_LIST1, m_ObjectListBox);
	DDX_Control(pDX, IDC_LIST2, m_StateListBox);
	DDX_Control(pDX, IDC_LIST3, m_FrameListBox);
	DDX_Control(pDX, IDC_PICTURE_CONTROL, m_PictureCrtl);
	DDX_Text(pDX, IDC_EDIT15, m_fFrameSpeed);
}


BEGIN_MESSAGE_MAP(CAnimationTool, CDialog)
	ON_LBN_SELCHANGE(IDC_LIST3, &CAnimationTool::OnLbnSelchangeFrameList)
	ON_LBN_SELCHANGE(IDC_LIST1, &CAnimationTool::OnLbnSelchangeObjectList)
	ON_LBN_SELCHANGE(IDC_LIST2, &CAnimationTool::OnLbnSelchangeStateList)
	ON_BN_CLICKED(IDC_BUTTON2, &CAnimationTool::OnBnClickedPlay)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON10, &CAnimationTool::OnBnClickedStop)
	ON_BN_CLICKED(IDC_BUTTON1, &CAnimationTool::OnBnClickedApply)
	ON_BN_CLICKED(IDC_BUTTON9, &CAnimationTool::OnBnClickedSave)
	ON_BN_CLICKED(IDC_BUTTON8, &CAnimationTool::OnBnClickedLoad)
END_MESSAGE_MAP()


BOOL CAnimationTool::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	UpdateData(TRUE);
	m_vScale = { 1.f, 1.f, 0.f };
	m_vRotZ = { 0.f, 0.f, 0.f };
	m_vTrans = { 0.f, 0.f, 0.f };
	m_vCenter = { 0.f, 0.f, 0.f };
	m_fFrameSpeed = 1.f;

	m_pTextureMgr = CTextureMgr::GetInstance();

	ANIM_INFO* pAnim = new ANIM_INFO(L"../Texture/Stage/Player/Attack/AKIHA_AKI01_00%d.png", L"Player", L"Attack", 6);
	m_vecAnimInfo.push_back(pAnim);

	pAnim = new ANIM_INFO(L"../Texture/Stage/Player/Dash/AKIHA_AKI13_00%d.png", L"Player", L"Dash", 11);
	m_vecAnimInfo.push_back(pAnim);

	pAnim = new ANIM_INFO(L"../Texture/Stage/Player/Stand/AKIHA_AKI00_00%d.png", L"Player", L"Stand", 12);
	m_vecAnimInfo.push_back(pAnim);

	pAnim = new ANIM_INFO(L"../Texture/Stage/Player/Walk/AKIHA_AKI26_00%d.png", L"Player", L"Walk", 13);
	m_vecAnimInfo.push_back(pAnim);

	for (size_t i = 0; i < m_vecAnimInfo.size(); ++i)
	{
		m_pTextureMgr->LoadTexture(CTextureMgr::MULTI_TEXTURE, m_vecAnimInfo[i]->wstrFilePath, m_vecAnimInfo[i]->wstrObjectKey, m_vecAnimInfo[i]->wstrStateKey, m_vecAnimInfo[i]->iFrameEnd);
	}

	for (auto iter : m_pTextureMgr->GetMapTexture())
	{
		m_ObjectListBox.AddString(iter.first.c_str());
	}

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CAnimationTool::OnLbnSelchangeFrameList()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CDeviceMgr::GetInstance()->Render_Begin();

	CString ObjectKey;
	m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), ObjectKey);

	CString StateKey;
	m_StateListBox.GetText(m_StateListBox.GetCurSel(), StateKey);

	UpdateData(TRUE);
	for (size_t i = 0; i < m_vecAnimInfo.size(); ++i)
	{
		CString ObjTmp;
		m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), ObjTmp);
		CString StatTmp;
		m_StateListBox.GetText(m_StateListBox.GetCurSel(), StatTmp);

		if (!lstrcmp(m_vecAnimInfo[i]->wstrObjectKey.c_str(), ObjTmp) &&
			!lstrcmp(m_vecAnimInfo[i]->wstrStateKey.c_str(), StatTmp))
		{
			m_fFrameSpeed = m_vecAnimInfo[i]->fFrameSpeed;
			m_vScale = m_vecAnimInfo[i]->m_tImgInfo[m_FrameListBox.GetCurSel()].vScale;
			m_vRotZ = m_vecAnimInfo[i]->m_tImgInfo[m_FrameListBox.GetCurSel()].vRotZ;
			m_vTrans = m_vecAnimInfo[i]->m_tImgInfo[m_FrameListBox.GetCurSel()].vTrans;
			m_vCenter = m_vecAnimInfo[i]->m_tImgInfo[m_FrameListBox.GetCurSel()].vCenter;
		}
	}
	UpdateData(FALSE);

	const TEX_INFO* pTexInfo = CTextureMgr::GetInstance()->GetTexInfo(
		(wstring)ObjectKey, (wstring)StateKey, m_FrameListBox.GetCurSel());
	NULL_CHECK(pTexInfo);

	D3DXMATRIX matScale;
	D3DXMATRIX matRotZ;
	D3DXMATRIX matTrans;
	D3DXMATRIX matWorld;

	D3DXMatrixIdentity(&matScale);
	D3DXMatrixIdentity(&matRotZ);
	D3DXMatrixIdentity(&matTrans);
	D3DXMatrixIdentity(&matWorld);

	D3DXMatrixScaling(&matScale, (float)WINCX / pTexInfo->tImgInfo.Width * m_vScale.x, (float)WINCY / pTexInfo->tImgInfo.Height * m_vScale.y, 0 * m_vScale.z);
	D3DXMatrixRotationZ(&matRotZ, D3DXToRadian(-m_vRotZ.x));
	D3DXMatrixTranslation(&matTrans, WINCX / 2, WINCY / 2, 0.f);

	matWorld = matScale * matRotZ * matTrans;

	CDeviceMgr::GetInstance()->GetSprite()->SetTransform(&matWorld);
	CDeviceMgr::GetInstance()->GetSprite()->Draw(pTexInfo->pTexture, nullptr,
		&D3DXVECTOR3(pTexInfo->tImgInfo.Width*0.5f + m_vCenter.x, pTexInfo->tImgInfo.Height*0.5f + m_vCenter.y, 0.f), nullptr, D3DCOLOR_ARGB(255, 255, 255, 255));

	CDeviceMgr::GetInstance()->Render_End(m_PictureCrtl.m_hWnd);
}


void CAnimationTool::OnLbnSelchangeObjectList()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_StateListBox.ResetContent();
	KillTimer(1);

	CString temp;
	m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), temp);
	auto map = dynamic_cast<CMultiTexture*>(m_pTextureMgr->GetMapTextureToIndex((wstring)temp))->GetMapMultiTexture();

	for (auto iter : *map)
	{
		m_StateListBox.AddString(iter.first.c_str());
	}
}


void CAnimationTool::OnLbnSelchangeStateList()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	m_FrameListBox.ResetContent();
	KillTimer(1);

	CString ObjectKey;
	m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), ObjectKey);

	CString StateKey;
	m_StateListBox.GetText(m_StateListBox.GetCurSel(), StateKey);

	size_t size = dynamic_cast<CMultiTexture*>(m_pTextureMgr->GetMapTextureToIndex((wstring)ObjectKey))->m_mapMultiTexture[wstring(StateKey)].size();

	for (size_t i = 0; i < size; ++i)
	{
		TCHAR Buf[256] = L"%02d";
		swprintf_s(Buf, Buf, i);
		m_FrameListBox.AddString(Buf);
	}
}


void CAnimationTool::OnBnClickedPlay()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	int iCount;

	for (size_t i = 0; i < m_vecAnimInfo.size(); ++i)
	{
		CString ObjTmp;
		m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), ObjTmp);
		CString StatTmp;
		m_StateListBox.GetText(m_StateListBox.GetCurSel(), StatTmp);

		if (!lstrcmp(m_vecAnimInfo[i]->wstrObjectKey.c_str(), ObjTmp.GetString()) &&
			!lstrcmp(m_vecAnimInfo[i]->wstrStateKey.c_str(), StatTmp.GetString()))
		{
			m_fFrameSpeed = m_vecAnimInfo[i]->fFrameSpeed;
			iCount = m_vecAnimInfo[i]->iFrameEnd;
		}
	}

	SetTimer(1, 1000/iCount * m_fFrameSpeed, NULL);
}


void CAnimationTool::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CDialog::OnTimer(nIDEvent);
	
	int result = m_FrameListBox.SetCurSel(m_FrameListBox.GetCurSel() + 1);

	if(result == LB_ERR)
		m_FrameListBox.SetCurSel(0);

	OnLbnSelchangeFrameList();
}


void CAnimationTool::OnBnClickedStop()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	KillTimer(1);
}


void CAnimationTool::OnBnClickedApply()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(TRUE);
	KillTimer(1);
	ERR_MSG(L"����Ǿ����ϴ�!");

	for (size_t i = 0; i < m_vecAnimInfo.size(); ++i)
	{
		CString ObjTmp;
		m_ObjectListBox.GetText(m_ObjectListBox.GetCurSel(), ObjTmp);
		CString StatTmp;
		m_StateListBox.GetText(m_StateListBox.GetCurSel(), StatTmp);

		if (!lstrcmp(m_vecAnimInfo[i]->wstrObjectKey.c_str(), ObjTmp.GetString()) &&
			!lstrcmp(m_vecAnimInfo[i]->wstrStateKey.c_str(), StatTmp.GetString()))
		{
			m_vecAnimInfo[i]->fFrameSpeed = m_fFrameSpeed;
			m_vecAnimInfo[i]->m_tImgInfo[m_FrameListBox.GetCurSel()].vScale = m_vScale;
			m_vecAnimInfo[i]->m_tImgInfo[m_FrameListBox.GetCurSel()].vRotZ = m_vRotZ;
			m_vecAnimInfo[i]->m_tImgInfo[m_FrameListBox.GetCurSel()].vTrans = m_vTrans;
			m_vecAnimInfo[i]->m_tImgInfo[m_FrameListBox.GetCurSel()].vCenter = m_vCenter;
		}
	}
	UpdateData(FALSE);
}


void CAnimationTool::OnBnClickedSave()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CFileDialog Dlg(
		FALSE, /* ���� TRUE, ���� FALSE */
		L"dat", /* ����Ʈ Ȯ���� */
		L"�������.dat", /* ����Ʈ ���ϸ� */
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		L"Data Files(*.dat)|*.dat|Text Files(*.txt)|*.txt||", /* ���� & ���� ����  */
		this /* �θ� ������ */);

	TCHAR szCurPath[MAX_STR] = L"";

	GetCurrentDirectory(MAX_STR, szCurPath);
	PathRemoveFileSpec(szCurPath);
	lstrcat(szCurPath, L"\\Data");

	Dlg.m_ofn.lpstrInitialDir = szCurPath;

	if (IDOK == Dlg.DoModal())
	{
		CString strFilePath = Dlg.GetPathName();
		SaveData(strFilePath);
	}
}


void CAnimationTool::OnBnClickedLoad()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CFileDialog Dlg(
		TRUE, /* ���� TRUE, ���� FALSE */
		L"dat", /* ����Ʈ Ȯ���� */
		L"�������.dat", /* ����Ʈ ���ϸ� */
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		L"Data Files(*.dat)|*.dat|Text Files(*.txt)|*.txt||", /* ���� & ���� ����  */
		this /* �θ� ������ */);

	TCHAR szCurPath[MAX_STR] = L"";

	GetCurrentDirectory(MAX_STR, szCurPath);
	PathRemoveFileSpec(szCurPath);
	lstrcat(szCurPath, L"\\Data");

	Dlg.m_ofn.lpstrInitialDir = szCurPath;

	if (IDOK == Dlg.DoModal())
	{
		CString strFilePath = Dlg.GetPathName();
		LoadData(strFilePath);
	}

	m_ObjectListBox.SetCurSel(0);
}

void CAnimationTool::SaveData(const TCHAR * pFilePath)
{
	HANDLE hFile = CreateFile(pFilePath, GENERIC_WRITE, 0, 0,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);

	if (INVALID_HANDLE_VALUE == hFile)
	{
		ERR_MSG(L"���� ����!!");
		return;
	}

	DWORD dwBytes = 0;

	TCHAR szFilePath[MAX_STR] = L"";
	TCHAR szObjectKey[MAX_STR] = L"";
	TCHAR szStateKey[MAX_STR] = L"";

	int size = m_vecAnimInfo.size();
	WriteFile(hFile, &size, sizeof(size_t), &dwBytes, nullptr);			//vector ������

	for (auto& pInfo : m_vecAnimInfo)
	{
		WriteFile(hFile, &pInfo->iFrameStart, sizeof(int), &dwBytes, nullptr);
		WriteFile(hFile, &pInfo->iFrameEnd, sizeof(int), &dwBytes, nullptr);
		WriteFile(hFile, &pInfo->fFrameSpeed, sizeof(float), &dwBytes, nullptr);

		lstrcpy(szFilePath, pInfo->wstrFilePath.c_str());
		int pathSize = pInfo->wstrFilePath.length() + 1;
		WriteFile(hFile, &pathSize, sizeof(int), &dwBytes, nullptr);
		WriteFile(hFile, szFilePath, sizeof(TCHAR) * pathSize, &dwBytes, nullptr);

		lstrcpy(szObjectKey, pInfo->wstrObjectKey.c_str());
		int ObjKeySize = pInfo->wstrObjectKey.length() + 1;
		WriteFile(hFile, &ObjKeySize, sizeof(int), &dwBytes, nullptr);
		WriteFile(hFile, szObjectKey, sizeof(TCHAR) * ObjKeySize, &dwBytes, nullptr);

		lstrcpy(szStateKey, pInfo->wstrStateKey.c_str());
		int statKeySize = pInfo->wstrStateKey.length() + 1;
		WriteFile(hFile, &statKeySize, sizeof(size_t), &dwBytes, nullptr);
		WriteFile(hFile, szStateKey, sizeof(TCHAR) * statKeySize, &dwBytes, nullptr);
		
		for (int i = 0; i < pInfo->iFrameEnd; ++i)
		{
			WriteFile(hFile, &pInfo->m_tImgInfo[i], sizeof(IMG_INFO), &dwBytes, nullptr);
		}
	}

	CloseHandle(hFile);
}

void CAnimationTool::LoadData(const TCHAR * pFilePath)
{
	HANDLE hFile = CreateFile(pFilePath, GENERIC_READ, 0, 0,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);

	if (INVALID_HANDLE_VALUE == hFile)
	{
		ERR_MSG(L"�ҷ����� ����!!");
		return;
	}

	DWORD dwBytes = 0;
	ANIM_INFO* pAnimTemp;
	int vecSize = 0;

	ReadFile(hFile, &vecSize, sizeof(size_t), &dwBytes, nullptr);

	for (int i = 0; i < vecSize; ++i)
	{
		pAnimTemp = new ANIM_INFO;
		ReadFile(hFile, &pAnimTemp->iFrameStart, sizeof(int), &dwBytes, nullptr);
		ReadFile(hFile, &pAnimTemp->iFrameEnd, sizeof(int), &dwBytes, nullptr);
		ReadFile(hFile, &pAnimTemp->fFrameSpeed, sizeof(float), &dwBytes, nullptr);

		int PathSize = 0;
		ReadFile(hFile, &PathSize, sizeof(int), &dwBytes, nullptr);
		TCHAR* szPath = new TCHAR[PathSize];
		ReadFile(hFile, szPath, sizeof(TCHAR) * PathSize, &dwBytes, nullptr);
		pAnimTemp->wstrFilePath = szPath;

		int ObjKeySize = 0;
		ReadFile(hFile, &ObjKeySize, sizeof(int), &dwBytes, nullptr);
		TCHAR* szObjKey = new TCHAR[ObjKeySize];
		ReadFile(hFile, szObjKey, sizeof(TCHAR) * ObjKeySize, &dwBytes, nullptr);
		pAnimTemp->wstrObjectKey = szObjKey;

		int StatKeySize = 0;
		ReadFile(hFile, &StatKeySize, sizeof(int), &dwBytes, nullptr);
		TCHAR* szStatKey = new TCHAR[StatKeySize];
		ReadFile(hFile, szStatKey, sizeof(TCHAR) * StatKeySize, &dwBytes, nullptr);
		pAnimTemp->wstrStateKey = szStatKey;

		pAnimTemp->m_tImgInfo = new IMG_INFO[pAnimTemp->iFrameEnd];
		for (int j = 0; j < pAnimTemp->iFrameEnd; ++j)
		{
			ReadFile(hFile, &pAnimTemp->m_tImgInfo[j], sizeof(IMG_INFO), &dwBytes, nullptr);
		}

		m_vecAnimInfo.push_back(pAnimTemp);
	}

	CloseHandle(hFile);
}
