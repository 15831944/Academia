//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Tool.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ToolTYPE                    130
#define IDD_MYFORM                      310
#define IDD_UNITTOOL                    311
#define IDD_MAPTOOL                     312
#define IDD_ANIMATIONTOOL               313
#define IDD_TILETOOL                    314
#define IDC_BUTTON1                     1001
#define IDC_EDIT1                       1002
#define IDC_BUTTON6                     1002
#define IDC_EDIT2                       1003
#define IDC_BUTTON7                     1003
#define IDC_EDIT3                       1004
#define IDC_BUTTON8                     1004
#define IDC_EDIT4                       1005
#define IDC_EDIT5                       1006
#define IDC_BUTTON9                     1006
#define IDC_BUTTON2                     1007
#define IDC_LIST1                       1008
#define IDC_RADIO1                      1009
#define IDC_LIST2                       1009
#define IDC_RADIO2                      1010
#define IDC_LIST3                       1010
#define IDC_RADIO3                      1011
#define IDC_BUTTON10                    1011
#define IDC_EDIT6                       1012
#define IDC_BUTTON3                     1013
#define IDC_EDIT7                       1013
#define IDC_BUTTON4                     1014
#define IDC_EDIT8                       1014
#define IDC_BUTTON5                     1015
#define IDC_EDIT9                       1015
#define IDC_CHECK1                      1016
#define IDC_EDIT10                      1016
#define IDC_CHECK2                      1017
#define IDC_PICTURE                     1017
#define IDC_EDIT11                      1017
#define IDC_CHECK3                      1018
#define IDC_EDIT12                      1018
#define IDC_EDIT13                      1019
#define IDC_EDIT14                      1020
#define IDC_EDIT15                      1021
#define IDC_PICTURE_CONTROL             1029
#define IDC_TILETOOL_TAB1               24000
#define IDD_TILETOOL_DIALOG1            24001
#define IDD_TILETOOL_DIALOG2            24002
#define IDD_TILETOOL_DIALOG3            24003
#define IDC_TILETOOL_TILE_EDIT1         24004
#define IDC_TILETOOL_TILE_EDIT2         24005
#define IDC_TILETOOL_TILE_EDIT3         24006
#define IDC_TILETOOL_TILE_EDIT4         24007
#define IDC_TILETOOL_TILE_LIST1         24008
#define IDC_TILETOOL_TILE_LIST2         24009
#define IDC_TILETOOL_TILE_BUTTON1       24010
#define IDC_TILETOOL_TILE_BUTTON2       24011
#define IDC_TILETOOL_TILE_BUTTON3       24012
#define IDC_TILETOOL_TILE_BUTTON4       24013
#define IDC_TILETOOL_TILE_CHECK1        24014
#define IDC_TILETOOL_TILE_CHECK2        24015
#define IDC_TILETOOL_PICTURECTRL1       24016
#define IDC_TILETOOL_PICTURECTRL2       24017
#define IDC_TILETOOL_TILE_CHECK3        24018
#define IDC_TILETOOL_TILE_CHECK4        24019
#define IDC_TILETOOL_TILE_BUTTON5       24020
#define IDC_TILETOOL_TILE_EDIT5         24021
#define IDC_TILETOOL_TILE_BUTTON6       24022
#define IDC_TILETOOL_TILE_BUTTON7       24023
#define IDC_TILETOOL_TILE_BUTTON8       24024
#define IDC_TILETOOL_TILE_BUTTON9       24025
#define IDC_TILETOOL_TILE_BUTTON10      24026
#define IDC_TILETOOL_TILE_CHECK5        24027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        322
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           315
#endif
#endif
