#include "stdafx.h"
#include "TextureMgr.h"
#include "SingleTexture.h"
#include "MultiTexture.h"

IMPLEMENT_SINGLETON(CTextureMgr)

CTextureMgr::CTextureMgr()
{
}


CTextureMgr::~CTextureMgr()
{
	Release();
}

const TEX_INFO* CTextureMgr::GetTexInfo(
	const wstring& wstrObjectKey,
	const wstring& wstrStateKey,
	const int& iIndex)
{
	auto iter_find = m_mapTexture.find(wstrObjectKey);

	if (m_mapTexture.end() == iter_find)
		return nullptr;

	return iter_find->second->GetTexInfo(wstrStateKey, iIndex);
}

HRESULT CTextureMgr::LoadTexture(
	TEXTURE_TYPE eTextureType, 
	const wstring& wstrFilePath,
	const wstring& wstrObjectKey,
	const wstring& wstrStateKey,
	const int& iCount)
{
	CTexture* pTexture = nullptr;

	auto iter_find = m_mapTexture.find(wstrObjectKey);

	switch (eTextureType)
	{
	case SINGLE_TEXTURE:
		if (m_mapTexture.end() != iter_find)
			return E_FAIL;

		pTexture = new CSingleTexture;
		m_mapTexture[wstrObjectKey] = pTexture;
		break;
	case MULTI_TEXTURE:
		if (m_mapTexture.end() == iter_find)
		{
			pTexture = new CMultiTexture;
			m_mapTexture[wstrObjectKey] = pTexture;
		}
		break;
	}

	m_mapTexture[wstrObjectKey]->LoadTexture(wstrFilePath, wstrStateKey, iCount);

	return S_OK;
}

void CTextureMgr::Release()
{
	for (auto& MyPair : m_mapTexture)
		SafeDelete(MyPair.second);

	m_mapTexture.clear();
}
