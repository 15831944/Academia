#include "stdafx.h"
#include "Player.h"


Player::Player()
{
}


Player::~Player()
{
	Release();
}

void Player::Update()
{
	// ������ ����(D3DXVECTOR3 ����ü�� ����� float ��)
	mtInfo.vPos += mtInfo.vDir;

	//// Ǯ� ����...
	//mtInfo.vPos.x += mtInfo.vDir.x;
	//mtInfo.vPos.y += mtInfo.vDir.y;
	//mtInfo.vPos.z += mtInfo.vDir.z;


}

void Player::LateUpdate()
{
}

void Player::Render(HDC hDC)
{
	RECT renderRect = {
		LONG(mtInfo.vPos.x - mtInfo.vSize.x * 0.5f),
		LONG(mtInfo.vPos.y - mtInfo.vSize.y * 0.5f),
		LONG(mtInfo.vPos.x + mtInfo.vSize.x * 0.5f),
		LONG(mtInfo.vPos.y + mtInfo.vSize.y * 0.5f)
	};

	Rectangle(hDC, renderRect.left, renderRect.top, renderRect.right, renderRect.bottom);
}

void Player::Init()
{
	mtInfo.vPos = {
		WINSIZE_X / 2.0f,
		WINSIZE_Y / 2.0f,
		0.0f
	};
	mtInfo.vDir = { 0.0f, -1.0f, 0.0f };
	mtInfo.vSize = { 100.0f, 100.0f, 0.0f }; // "����, ���� 1.0f"�� ���� 100�� Ű�� �� !!!!
}

void Player::Release()
{
}

Player * Player::Create()
{
	Player *pInstance = new Player; // Encapsulation (Singleton ������ �ƴ�.)
	if (pInstance)
	{
		pInstance->Init();
	}

	return pInstance;
}
