#include "stdafx.h"

#include "Mouse.h"

#include "Player.h"


Player::Player()
{
}


Player::~Player()
{
	Release();
}

void Player::Update()
{
	InputKeyboard();

	// ####################################################################################################################
	// 2019.07.18.01 Rotation Z-Axis

	// Cartesian Coordinate ���� !!!!

	// ########################
	// Rotation Matrix ����
	//  cosA -sinA
	//  sinA  cosA
	// ########################

	for (int i = 0; i < 4; ++i)
	{
		// Rotation(����)�� �̵�(Translation) ���� ������ �������� ȸ���ϴ� ���� ���մϴ�.
		mvConvert[i].x =
			mvOrigin[i].x * cosf(D3DXToRadian(mAngle)) - mvOrigin[i].y * (-sinf(D3DXToRadian(mAngle)));

		mvConvert[i].y =
			mvOrigin[i].x * (-sinf(D3DXToRadian(mAngle))) + mvOrigin[i].y * cosf(D3DXToRadian(mAngle));


		// Rotation ��, �̵�(Translation) - ����� �ش� ��ġ���� ȸ���� ��ó�� ���̰� �˴ϴ�.
		mvConvert[i] += mtInfo.vPos;
	}

	
	// ���� ���� ����
	mtInfo.vDir.x =
		mtInfo.vDirOrigin.x  * cosf(D3DXToRadian(mAngle)) - mtInfo.vDirOrigin.y * (-sinf(D3DXToRadian(mAngle)));

	mtInfo.vDir.y =
		mtInfo.vDirOrigin.x * (-sinf(D3DXToRadian(mAngle))) + mtInfo.vDirOrigin.y * cosf(D3DXToRadian(mAngle));

	// D3DXVec3Normalize() - ���� ����ȭ �Լ� !!!!
	D3DXVec3Normalize(&mtInfo.vDir, &mtInfo.vDir);

}

void Player::LateUpdate()
{
}

void Player::Render(HDC hDC)
{
	MoveToEx(hDC, (int)mvConvert[0].x, (int)mvConvert[0].y, nullptr);
	LineTo(hDC, (int)mvConvert[1].x, (int)mvConvert[1].y);
	LineTo(hDC, (int)mvConvert[2].x, (int)mvConvert[2].y);
	LineTo(hDC, (int)mvConvert[3].x, (int)mvConvert[3].y);
	LineTo(hDC, (int)mvConvert[0].x, (int)mvConvert[0].y);

	// ####################################################################
	// �� 2���� ��ġ Render
	// ��(Vertex - 0) ��(Vertex - 1)
	for (int i = 0; i < 2; ++i)
	{
		Ellipse(hDC,
			(int)mvConvert[i].x - 10, (int)mvConvert[i].y - 10,
			(int)mvConvert[i].x + 10, (int)mvConvert[i].y + 10
		);
	}
}

void Player::Init()
{
	mtInfo.vPos = {
		WINSIZE_X / 2.0f,
		WINSIZE_Y / 2.0f,
		0.0f
	};
	mtInfo.vDirOrigin = { 0.0f, -1.0f, 0.0f };	// vDirOrigin - ���� ���� ����
												// vDir - ��ȯ�� ���� ����
	mtInfo.vSize = { 1.0f, 1.0f, 0.0f };

	mAngle = 0.0f; // Degree Unit(Measure)

	// ����(Vertex) �ʱ� ��ġ
	// 0 1
	// 3 2

	mvOrigin[0] = { -50.0f, -50.0f, 0.0f };
	mvOrigin[1] = {  50.0f, -50.0f, 0.0f };
	mvOrigin[2] = {  50.0f,  50.0f, 0.0f };
	mvOrigin[3] = { -50.0f,  50.0f, 0.0f };

}

void Player::Release()
{
}

void Player::InputKeyboard()
{
	// VK_LEFT
	if (GetAsyncKeyState('A') & 0x8000)
	{
		mAngle += 3.0f; // CCW - Positive
	}
	if (GetAsyncKeyState('D') & 0x8000)
	{
		mAngle += (-3.0f); // CW - Negative
	}

	if (GetAsyncKeyState('W') & 0x8000)
	{
		mtInfo.vPos += mtInfo.vDir * 2.0f;
	}
	if (GetAsyncKeyState('S') & 0x8000)
	{
		mtInfo.vPos += mtInfo.vDir * (-2.0f);
	}
}

Player * Player::Create()
{
	Player *pInstance = new Player; // Encapsulation (Singleton ������ �ƴ�.)
	if (pInstance)
	{
		pInstance->Init();
	}

	return pInstance;
}
