#pragma once
#ifndef _PLAYER_H_
#define _PLAYER_H_

class Player
{
private:
	explicit Player();

public:
	virtual ~Player();

public:
	void Update();
	void LateUpdate();
	void Render(HDC hDC);

private:
	void Init();
	void Release();

public:
	static Player* Create();

private:
	INFO mtInfo;
};

#endif