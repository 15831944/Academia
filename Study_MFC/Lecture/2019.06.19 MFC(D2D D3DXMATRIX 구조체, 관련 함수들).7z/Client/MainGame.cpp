#include "stdafx.h"

#include "Player.h"

#include "MainGame.h"


MainGame::MainGame()
	: mpPlayer(nullptr)
{
}


MainGame::~MainGame()
{
	Release();
}

void MainGame::Init()
{
	mhDC = GetDC(ghWnd);

	mpPlayer = Player::Create();
}

void MainGame::Update()
{
	mpPlayer->Update();
}

void MainGame::LateUpdate()
{
	mpPlayer->LateUpdate();
}

void MainGame::Render()
{
	Rectangle(mhDC, 0, 0, WINSIZE_X, WINSIZE_Y);

	mpPlayer->Render(mhDC);
}

void MainGame::Release()
{
	ReleaseDC(ghWnd, mhDC);

	SafeDelete(mpPlayer);
}

