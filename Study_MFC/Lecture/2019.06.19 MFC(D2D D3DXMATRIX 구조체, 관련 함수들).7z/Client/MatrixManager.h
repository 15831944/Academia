#pragma once
#ifndef _MATRIX_MANAGER_H_
#define _MATRIX_MANAGER_H_

class MatrixManager
{
private:
	MatrixManager();
	~MatrixManager();

public:
	static void D3DXMatrixIdentity(D3DXMATRIX *pMatrix);
	static void D3DXMatrixScaling(D3DXMATRIX *pMatrix, float x, float y, float z);
	static void D3DXMatrixRotationZ(D3DXMATRIX *pMatrix, float radian);
	static void D3DXMatrixTranslation(D3DXMATRIX *pMatrix, float x, float y, float z);
	static void D3DXVec3TransformCoord(D3DXVECTOR3 *pOut, const D3DXVECTOR3 *pIn, const D3DXMATRIX *pMatrix);
	static void D3DXVec3TransformNormal(D3DXVECTOR3 *pOut, const D3DXVECTOR3 *pIn, const D3DXMATRIX *pMatrix);
};

#endif