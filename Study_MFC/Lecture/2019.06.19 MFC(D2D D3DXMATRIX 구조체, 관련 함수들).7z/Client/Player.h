#pragma once
#ifndef _PLAYER_H_
#define _PLAYER_H_

class Player
{
private:
	explicit Player();

public:
	virtual ~Player();

public:
	void Update();
	void LateUpdate();
	void Render(HDC hDC);

private:
	void Init();
	void Release();
	void InputKeyboard();

public:
	static Player* Create();

private:
	INFO mtInfo;
	float mAngle;

	D3DXVECTOR3 mvOrigin[4];	// �� P(ó�� ��ġ)
	D3DXVECTOR3 mvConvert[4];	// �� Q(��ȯ�� ��ġ)
};

#endif