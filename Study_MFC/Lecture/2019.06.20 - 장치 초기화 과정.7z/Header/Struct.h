#pragma once
#ifndef _STRUCT_H_
#define _STRUCT_H_



#endif