#include "stdafx.h"
#include "Terrain.h"


Terrain::Terrain()
{
}


Terrain::~Terrain()
{
	Release();
}

void Terrain::Render()
{
	D3DXMATRIX matScale, matTrans, matWorld;

	for (size_t i = 0; i < mVecTile.size(); ++i)
	{
		const TEXTURE_INFO *pTextureInfo = TextureManager::getInstance()->getTextureInfo(
			L"Terrain", L"Tile", mVecTile[i]->byDrawID
		);
		NULL_CHECK(pTextureInfo);

		D3DXMatrixScaling(&matScale, mVecTile[i]->vSize.x, mVecTile[i]->vSize.y, 0.0f);
		D3DXMatrixTranslation(&matTrans, mVecTile[i]->vPos.x, mVecTile[i]->vPos.y, 0.0f);

		matWorld = matScale * matTrans;

		float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
		float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

		DeviceManager::getInstance()->getSprite()->SetTransform(&matWorld);
		DeviceManager::getInstance()->getSprite()->Draw(
			pTextureInfo->pTexture,
			nullptr,
			&D3DXVECTOR3(centerX, centerY, 0.0f),
			nullptr,
			D3DCOLOR_ARGB(255, 255, 255, 255)
		);
	}
}

HRESULT Terrain::Init()
{
	TILE_INFO *pTile = nullptr;

	for (int i = 0; i < TILE_Y; ++i)
	{
		for (int j = 0; j < TILE_X; ++j)
		{
			pTile = new TILE_INFO;
			NULL_CHECK_MSG_RETURN(pTile, L"TILE_INFO memory allocation Failed, Terrain::Init()", E_FAIL);
			ZeroMemory(pTile, sizeof(TILE_INFO));

			pTile->vPos.x = (TILESIZE_X * j) + (i % 2) * (TILESIZE_X * 0.5f);
			pTile->vPos.y = (TILESIZE_Y * 0.5f) * i;

			pTile->vSize = { 1.0f, 1.0f, 0.0f };

			pTile->byDrawID = 2;
			pTile->byOption = 0;

			mVecTile.emplace_back(pTile);
		}
	}

	return S_OK;
}

void Terrain::Release()
{
	for_each(mVecTile.begin(), mVecTile.end(), SafeDelete<TILE_INFO *>);

	mVecTile.clear();
	mVecTile.shrink_to_fit();
}

void Terrain::ChangeTile(
	const D3DXVECTOR3 &vPos,
	const BYTE &byDrawID,
	const BYTE &byOption)
{
	int index = GetTileIndex(vPos); // ���� ó���Ϸ��� int ��(-1 ��)
	if (index < 0
		|| (size_t)index >= mVecTile.size())
	{
		return;
	}

	mVecTile[index]->byDrawID = byDrawID;
	mVecTile[index]->byOption = byOption;
}

int Terrain::GetTileIndex(const D3DXVECTOR3 & vPos)
{
	for (size_t i = 0; i < mVecTile.size(); ++i)
	{
		if (IsPicking(vPos, i))
		{
			return (int)i;
		}
	}

	return -1; // ���� ��, "-1" ��ȯ
}

bool Terrain::IsPicking(const D3DXVECTOR3 & vPos, size_t index)
{
	// ####################
	// Cartesian Coordinate
	//
	// Linear Equation
	// ####################
	//
	// y = a * x + b
	// 0 = a * x + b - y ���·� �ٲ� �� �ִ�.
	// ���ϴ� ��ǥ (x, y)�� �Է� �޾��� ��...
	// ############################################
	// Cartesian Coordinate ����
	// ############################################
	// "0"�� ����	: ������ ������.  ex. 0 = x - y (=> y = x)
	// "0"���� ŭ	: �Ʒ��� ��ġ��.
	// "0"���� ����	: ���� ��ġ��. 
	// #############################################
	// ��ǥ�� �����̴� ���� �ƴϱ� ������, ���ϴ� ������ ����ȴ�.
	// - Window ��ǥ�� Cartesian ��ǥ��� X-Axis ��Ī !!!!
	//  (Symmetry about the X-Axis)
	// #############################################

	// Gradient ����
	// 0 1
	// 3 2

	float gradient[4] = {
		(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		-(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		-(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
	};

	// Vertex ����
	//   0
	// 3   1
	//   2

	D3DXVECTOR3 vVertex[4] = {
		{ mVecTile[index]->vPos.x, mVecTile[index]->vPos.y + TILESIZE_Y * 0.5f, 0.0f },	// 12��
		{ mVecTile[index]->vPos.x + TILESIZE_X * 0.5f, mVecTile[index]->vPos.y, 0.0f },	// 03��
		{ mVecTile[index]->vPos.x, mVecTile[index]->vPos.y - TILESIZE_Y * 0.5f, 0.0f },	// 06��
		{ -mVecTile[index]->vPos.x - TILESIZE_X * 0.5f, mVecTile[index]->vPos.y, 0.0f }	// 09��
	};

	// 0 = a * x + b - y
	// b = y - a * x

	float b[4] = {
		vVertex[0].y - gradient[0] * vVertex[0].x,
		vVertex[1].y - gradient[1] * vVertex[1].x,
		vVertex[2].y - gradient[2] * vVertex[2].x,
		vVertex[3].y - gradient[3] * vVertex[3].x
	};


	return (gradient[0] * vPos.x + b[0] - vPos.y > 0
		&& gradient[1] * vPos.x + b[1] - vPos.y > 0
		&& gradient[2] * vPos.x + b[2] - vPos.y < 0
		&& gradient[3] * vPos.x + b[3] - vPos.y < 0
	);
}

Terrain * Terrain::Create()
{
	Terrain *pInstance = new Terrain;

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
