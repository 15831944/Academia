#pragma once
#ifndef _TEXTURE_MANAGER_H_
#define _TEXTURE_MANAGER_H_

class Texture;

class TextureManager
{
	DECLARE_SINGLETON(TextureManager);

private:
	TextureManager();
	~TextureManager();

public:
	enum TEXTURE {
		SINGLE,
		MULTI,
		END
	};

public:
	void Release();

public:
	HRESULT LoadTexture(
		TEXTURE eTextureType,
		const wstring &wstrFilePath,
		const wstring &wstrObjectKey,
		const wstring &wstrStateKey = L"",
		const int &imageCount = 0
	);

public:
	const TEXTURE_INFO* getTextureInfo(
		const wstring &wstrObjectKey,
		const wstring &wstrStateKey = L"",
		const int &imageIndex = 0
	);

private:
	map<const wstring, Texture *> mMapTexture;

};

#endif