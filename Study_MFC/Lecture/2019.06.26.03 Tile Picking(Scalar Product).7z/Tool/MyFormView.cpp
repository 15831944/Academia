// MyFormView.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Tool.h"
#include "MyFormView.h"


// MyFormView

IMPLEMENT_DYNCREATE(MyFormView, CFormView)

MyFormView::MyFormView()
	: CFormView(IDD_MYFORMVIEW)
{

}

MyFormView::~MyFormView()
{
}

void MyFormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(MyFormView, CFormView)
END_MESSAGE_MAP()


// MyFormView �����Դϴ�.

#ifdef _DEBUG
void MyFormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void MyFormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG


// MyFormView �޽��� ó�����Դϴ�.
