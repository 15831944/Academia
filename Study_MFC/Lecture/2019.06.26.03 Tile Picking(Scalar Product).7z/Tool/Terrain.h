#pragma once
#ifndef _TERRAIN_H_
#define _TERRAIN_H_

class Terrain
{
private:
	explicit Terrain();

public:
	~Terrain();

public:
	void Render();

private:
	HRESULT Init();
	void Release();

public:
	void ChangeTile(
		const D3DXVECTOR3 &vPos,
		const BYTE &byDrawID,
		const BYTE &byOption = 0
	);

private:
	int GetTileIndex(const D3DXVECTOR3 &vPos);
	bool IsPicking(const D3DXVECTOR3 &vPos, size_t index);
	bool IsPickingWithScalarProduct(const D3DXVECTOR3 &vPos, size_t index);

public:
	static Terrain* Create();

private:
	vector<TILE_INFO *> mVecTile;
};

#endif