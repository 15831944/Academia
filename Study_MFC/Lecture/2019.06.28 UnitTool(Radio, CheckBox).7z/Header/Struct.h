#pragma once
#ifndef _STRUCT_H_
#define _STRUCT_H_


// ##################################################################################################

typedef struct tagTextureInfo
{
	LPDIRECT3DTEXTURE9	pTexture;		// Texture COM ��ü(Texture ����)
	D3DXIMAGE_INFO		tImageInfo;		// Texture�� ���� �̹��� ����

} TEXTURE_INFO;

// ##################################################################################################
typedef struct tagTileInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vSize;
	BYTE		byDrawID;
	BYTE		byOption;
} TILE_INFO;

// ##################################################################################################
typedef struct tagUnitData
{
	tagUnitData()
		: strName(L""),
		attackDamage(0), defense(0),
		classIndex(0), genderIndex(0),
		item(0)
	{

	}

	CString strName;
	int attackDamage;
	int defense;
	int classIndex;
	int genderIndex;
	int item;
} UNIT_DATA;

#endif