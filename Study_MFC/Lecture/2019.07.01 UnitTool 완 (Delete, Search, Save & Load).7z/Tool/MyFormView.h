#pragma once
#ifndef _MY_FORM_VIEW_H_
#define _MY_FORM_VIEW_H_


// #############################################################################
// MyFormView �� ���Դϴ�.
#include "UnitTool.h"


class MyFormView : public CFormView
{
	DECLARE_DYNCREATE(MyFormView)

protected:
	MyFormView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~MyFormView();

public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MYFORMVIEW };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

public: // Message Function
	DECLARE_MESSAGE_MAP()



private:
	// MFC���� �����ϴ� CFont ��ü
	CFont		mFont;
	UnitTool	mUnitTool;

public:
	virtual void OnInitialUpdate();
	afx_msg void OnBnClickedUnitTool();
};


#endif