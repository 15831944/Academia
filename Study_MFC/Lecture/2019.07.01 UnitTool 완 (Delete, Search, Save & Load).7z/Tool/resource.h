//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Tool.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ToolTYPE                    130
#define IDD_MYFORMVIEW                  310
#define IDD_UNITTOOL                    311
#define IDC_MYFORMVIEW_BUTTON1          1000
#define IDC_MYFORMVIEW_BUTTON2          1001
#define IDC_UNITTOOL_EDIT1              2000
#define IDC_UNITTOOL_EDIT2              2001
#define IDC_UNITTOOL_BUTTON1            2002
#define IDC_UNITTOOL_EDIT3              2003
#define IDC_UNITTOOL_EDIT4              2004
#define IDC_UNITTOOL_EDIT5              2005
#define IDC_UNITTOOL_RADIO1             2006
#define IDC_UNITTOOL_RADIO2             2007
#define IDC_UNITTOOL_RADIO3             2008
#define IDC_UNITTOOL_EDIT6              2009
#define IDC_UNITTOOL_LIST1              2010
#define IDC_UNITTOOL_BUTTON2            2011
#define IDC_UNITTOOL_BUTTON3            2012
#define IDC_UNITTOOL_BUTTON4            2013
#define IDC_UNITTOOL_BUTTON5            2014
#define IDC_UNITTOOL_RADIO4             2015
#define IDC_UNITTOOL_RADIO5             2016
#define IDC_UNITTOOL_RADIO6             2017
#define IDC_UNITTOOL_CHECK1             2018
#define IDC_UNITTOOL_CHECK2             2019
#define IDC_UNITTOOL_CHECK3             2020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           312
#endif
#endif
