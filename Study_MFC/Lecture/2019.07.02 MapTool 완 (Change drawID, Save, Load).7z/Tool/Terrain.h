#pragma once
#ifndef _TERRAIN_H_
#define _TERRAIN_H_

class CToolView;

class Terrain
{
private:
	explicit Terrain();

public:
	~Terrain();

public:
	void Render() const;
	void RenderMiniView() const;

private:
	HRESULT Init();
	void Release();

public:
	void ChangeTile(
		const D3DXVECTOR3 &vPos,
		const BYTE &byDrawID,
		const BYTE &byOption = 0
	);

	HRESULT SaveTile(const TCHAR *pFilePath) const;
	HRESULT LoadTile(const TCHAR *pFilePath);

private:
	int GetTileIndex(const D3DXVECTOR3 &vPos);
	bool IsPicking(const D3DXVECTOR3 &vPos, size_t index);
	bool IsPickingWithScalarProduct(const D3DXVECTOR3 &vPos, size_t index);

public:
	static Terrain* Create(CToolView *pToolView);

public:
	void setToolView(CToolView *pToolView) { mpToolView = pToolView; }

private:
	vector<TILE_INFO *> mVecTile;

	CToolView *mpToolView; // Scroll ���� �޾ƿ��� ���ؼ�...
};

#endif