#include "stdafx.h"
#include "MultiTexture.h"


MultiTexture::MultiTexture()
{
}


MultiTexture::~MultiTexture()
{
	Release();
}

void MultiTexture::Release()
{
	for (auto &MyPair : mMapMultiTexture)
	{
		for (auto &pTextureInfo : MyPair.second)
		{
			pTextureInfo->pTexture->Release();
			SafeDelete(pTextureInfo);
		}

		MyPair.second.clear();
		MyPair.second.shrink_to_fit();
	}

	mMapMultiTexture.clear();
}

HRESULT MultiTexture::LoadTexture(
	const wstring &wstrFilePath,
	const wstring &wstrStateKey /*= L""*/,
	const int &imageCount /*= 0*/)
{
	auto iterFind = mMapMultiTexture.find(wstrStateKey);
	if (iterFind != mMapMultiTexture.end())
	{
		return E_FAIL;
	}

	HRESULT hr = 0;

	TCHAR szFileFullPath[MAX_STR] = L"";

	for (int i = 0; i < imageCount; ++i)
	{
		swprintf_s(szFileFullPath, wstrFilePath.c_str(), i);

		TEXTURE_INFO *pTextureInfo = new TEXTURE_INFO;
		ZeroMemory(pTextureInfo, sizeof(TEXTURE_INFO));

		hr = D3DXGetImageInfoFromFile(szFileFullPath, &(pTextureInfo->tImageInfo));
		FAILED_CHECK_MSG_RETURN(hr, L"D3DXGetImageInfoFromFile Failed, MultiTexture::LoadTexture()", E_FAIL);

		hr = D3DXCreateTextureFromFileEx(
			DeviceManager::getInstance()->getDevice(),
			szFileFullPath,
			pTextureInfo->tImageInfo.Width,
			pTextureInfo->tImageInfo.Height,
			pTextureInfo->tImageInfo.MipLevels,
			0,
			pTextureInfo->tImageInfo.Format,
			D3DPOOL_MANAGED,
			D3DX_DEFAULT,
			D3DX_DEFAULT,
			0,
			nullptr,
			nullptr,
			&(pTextureInfo->pTexture)
		);
		FAILED_CHECK_MSG_RETURN(hr, L"D3DXCreateTextureFromFileEx Failed, MultiTexture::LoadTexture()", E_FAIL);

		mMapMultiTexture[wstrStateKey].emplace_back(pTextureInfo);
	}

	return S_OK;
}

const TEXTURE_INFO* MultiTexture::getTextureInfo(
	const wstring &wstrStateKey /*= L""*/,
	const int &imageIndex /*= 0*/)
{
	auto iterFind = mMapMultiTexture.find(wstrStateKey);
	if (iterFind == mMapMultiTexture.end())
	{
		return nullptr;
	}

	return iterFind->second[imageIndex];
}
