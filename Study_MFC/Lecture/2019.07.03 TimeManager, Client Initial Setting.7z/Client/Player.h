#pragma once
#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "Obj.h"

class Player : public Obj
{
public:
	Player();
	virtual ~Player();
};

#endif