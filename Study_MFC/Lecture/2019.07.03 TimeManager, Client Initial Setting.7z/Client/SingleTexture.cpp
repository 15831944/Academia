#include "stdafx.h"
#include "SingleTexture.h"


SingleTexture::SingleTexture()
	: mpTextureInfo(nullptr)
{
}


SingleTexture::~SingleTexture()
{
	Release();
}

void SingleTexture::Release()
{
	if (mpTextureInfo->pTexture->Release())
	{
		ERR_MSG(L"LPDIRECT3DTEXTURE9 Release Failed, SingleTexture::Release()");
	}

	SafeDelete(mpTextureInfo);
}

HRESULT SingleTexture::LoadTexture(
	const wstring &wstrFilePath,
	const wstring &wstrStateKey /*= L""*/,
	const int &imageCount /*= 0*/)
{
	mpTextureInfo = new TEXTURE_INFO;
	ZeroMemory(mpTextureInfo, sizeof(TEXTURE_INFO));

	HRESULT hr = 0;

	hr = D3DXGetImageInfoFromFile(
		wstrFilePath.c_str(), &(mpTextureInfo->tImageInfo)
	);
	FAILED_CHECK_MSG_RETURN(hr, L"D3DXGetImageInfoFromFile Failed, SingleTexture::LoadTexture()", E_FAIL);

	hr = D3DXCreateTextureFromFileEx(
		DeviceManager::getInstance()->getDevice(),
		wstrFilePath.c_str(),
		mpTextureInfo->tImageInfo.Width,
		mpTextureInfo->tImageInfo.Height,
		mpTextureInfo->tImageInfo.MipLevels,
		0,
		mpTextureInfo->tImageInfo.Format,
		D3DPOOL_MANAGED,
		D3DX_DEFAULT,
		D3DX_DEFAULT,
		0, // ������ ����
		nullptr,
		nullptr,
		&(mpTextureInfo->pTexture)
	);
	FAILED_CHECK_MSG_RETURN(hr, L"D3DXCreateTextureFromFileEx Failed, SingleTexture::LoadTexture()", E_FAIL);

	return S_OK;
}

const TEXTURE_INFO* SingleTexture::getTextureInfo(
	const wstring &wstrStateKey /*= L""*/,
	const int &imageIndex /*= 0*/)
{
	return mpTextureInfo;
}
