#pragma once
#ifndef _TERRAIN_H_
#define _TERRAIN_H_

#include "Obj.h"

class Terrain : public Obj
{
public:
	Terrain();
	virtual ~Terrain();

public:
	// Obj��(��) ���� ��ӵ�
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render() override;

private:
	virtual HRESULT Init() override;
	virtual HRESULT LateInit();
	virtual void Release() override;

public:
	HRESULT LoadTile(const TCHAR *pFilePath);

public:
	static Terrain* Create();

private:
	vector<TILE_INFO *> mVecTile;
};

#endif