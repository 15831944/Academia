#pragma once
#ifndef _FILE_INFO_H_
#define _FILE_INFO_H_

class FileInfo
{
private:
	FileInfo();
	~FileInfo();

public:
	static CString ConvertRelativePath(const CString strFullPath);
};

#endif