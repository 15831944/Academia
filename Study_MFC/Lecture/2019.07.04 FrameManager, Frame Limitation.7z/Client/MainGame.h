#pragma once
#ifndef _MAIN_GAME_H_
#define _MAIN_GAME_H_

class MainGame
{
private:
	explicit MainGame();

public:
	~MainGame();

public:
	void Update();
	void LateUpdate();
	void Render();

private:
	HRESULT Init();
	void Release();

public:
	static MainGame *Create();

private:
	DeviceManager	*mpDeviceManager;
	TextureManager	*mpTextureManager;
	ObjManager		*mpObjManager;
	SceneManager	*mpSceneManager;
	TimeManager		*mpTimeManager;
	FrameManager	*mpFrameManager;
};

#endif