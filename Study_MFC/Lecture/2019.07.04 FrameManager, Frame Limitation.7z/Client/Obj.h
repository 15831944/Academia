#pragma once
#ifndef _OBJ_H_
#define _OBJ_H_

class Obj
{
protected:
	explicit Obj();

public:
	virtual ~Obj();

public:
	virtual int Update() PURE;
	virtual void LateUpdate() PURE;
	virtual void Render() PURE;

protected:
	virtual HRESULT Init() PURE;
	virtual HRESULT LateInit();
	virtual void Release() PURE;

protected:
	DeviceManager	*mpDeviceManager;
	TextureManager	*mpTextureManager;
	TimeManager		*mpTimeManager;

	bool mIsInit;
};

#endif