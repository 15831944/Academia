#include "stdafx.h"

#include "Obj.h"

#include "ObjManager.h"

IMPLEMENT_SINGLETON(ObjManager);

ObjManager::ObjManager()
{
}


ObjManager::~ObjManager()
{
	Release();
}

void ObjManager::Update()
{
	for (int i = 0; i < OBJ_TYPE_END; ++i)
	{
		auto iter = mListObj[i].begin();
		for (; iter != mListObj[i].end(); )
		{
			int eventNum = (*iter)->Update();

			if (eventNum == OBJ_DEAD)
			{
				SafeDelete(*iter);
				iter = mListObj[i].erase(iter);
			}
			else
			{
				++iter;
			}
		}
	}
}

void ObjManager::LateUpdate()
{
	for (int i = 0; i < OBJ_TYPE_END; ++i)
	{
		for (auto &pObj : mListObj[i])
		{
			pObj->LateUpdate();
		}
	}
}

void ObjManager::Render()
{
	for (int i = 0; i < OBJ_TYPE_END; ++i)
	{
		for (auto &pObj : mListObj[i])
		{
			pObj->Render();
		}
	}
}

void ObjManager::Release()
{
	for (int i = 0; i < OBJ_TYPE_END; ++i)
	{
		for_each(mListObj[i].begin(), mListObj[i].end(), SafeDelete<Obj *>);

		mListObj[i].clear();
	}
}

HRESULT ObjManager::AddObject(OBJ_TYPE eObjType, Obj * pObj)
{
	NULL_CHECK_RETURN(pObj, E_FAIL);

	mListObj[eObjType].emplace_back(pObj);

	return S_OK;
}
