#pragma once
#ifndef _SCENE_MANAGER_H_
#define _SCENE_MANAGER_H_

class Scene;

class SceneManager
{
	DECLARE_SINGLETON(SceneManager);

private:
	SceneManager();
	~SceneManager();

public:
	enum SCENE_TYPE
	{
		LOGO = 0,
		STAGE,
		SCENE_TYPE_END
	};

public:
	void Update();
	void LateUpdate();
	void Render();

private:
	void Release();

public:
	HRESULT ChangeScene(SceneManager::SCENE_TYPE eSceneType);

private:
	Scene		*mpCurrentScene;	// ���� Scene

	SCENE_TYPE	meCurrentSceneType;	// ���� Scene type
	SCENE_TYPE	meNextSceneType;	// ���� Scene type
};

#endif