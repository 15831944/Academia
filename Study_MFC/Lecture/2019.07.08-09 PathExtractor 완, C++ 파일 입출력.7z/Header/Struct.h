#pragma once
#ifndef _STRUCT_H_
#define _STRUCT_H_

// ##################################################################################################
// ##################################################################################################
// Client
typedef struct tagInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vDir;
	D3DXVECTOR3 vDirOrigin;
	D3DXVECTOR3 vSize;
	D3DXMATRIX matWorld;
} INFO;


// ##################################################################################################
// ##################################################################################################
// MFC
typedef struct tagTextureInfo
{
	LPDIRECT3DTEXTURE9	pTexture;		// Texture COM ��ü(Texture ����)
	D3DXIMAGE_INFO		tImageInfo;		// Texture�� ���� �̹��� ����

} TEXTURE_INFO;

// ##################################################################################################
typedef struct tagTileInfo
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vSize;
	BYTE		byDrawID;
	BYTE		byOption;
} TILE_INFO;

// ##################################################################################################
typedef struct tagUnitData
{
	tagUnitData()
		: strName(L""),
		attackDamage(0), defense(0),
		classIndex(0), genderIndex(0),
		item(0)
	{

	}

#ifdef CLIENT
	wstring strName;
#else
	CString strName;
#endif
	int attackDamage;
	int defense;
	int classIndex;
	int genderIndex;
	int item;
} UNIT_DATA;

// ##################################################################################################
typedef struct tagPathInfo
{
	tagPathInfo()
		: wstrRelativePath(L""),
		wstrObjectKey(L""), wstrStateKey(L""),
		imageCount(0)
	{

	}

	wstring wstrRelativePath;
	wstring wstrObjectKey;
	wstring wstrStateKey;
	int imageCount;

} PATH_INFO;


#endif