#pragma once
#ifndef _MAP_TOOL_H_
#define _MAP_TOOL_H_

#include "afxwin.h"


// MapTool ��ȭ �����Դϴ�.
class CToolView;
class MiniView;

class MapTool : public CDialog
{
	DECLARE_DYNAMIC(MapTool)

public:
	MapTool(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~MapTool();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MAPTOOL };
#endif

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();


public: // Message Function
	DECLARE_MESSAGE_MAP()

	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnLbnSelchangeTileList();
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedLoad();

private: // Control Variable
	CListBox mListBox;
	CStatic mPictureCtrl;

public: // User Function
	void CreateHorizontalScrollForListBox();

private: // User Variable
	BYTE mbyDrawID;

	CToolView *mpToolView;
	MiniView *mpMiniView;

public:
};

#endif