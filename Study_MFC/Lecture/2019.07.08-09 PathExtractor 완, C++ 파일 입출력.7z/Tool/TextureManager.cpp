#include "..\Client\TextureManager.h"
#include "stdafx.h"

#include "SingleTexture.h"
#include "MultiTexture.h"

#include "TextureManager.h"

IMPLEMENT_SINGLETON(TextureManager);

TextureManager::TextureManager()
{
}


TextureManager::~TextureManager()
{
	Release();
}

void TextureManager::Release()
{
	for (auto &MyPair : mMapTexture)
	{
		SafeDelete(MyPair.second);
	}

	mMapTexture.clear();
}

HRESULT TextureManager::LoadTexture(
	TEXTURE eTextureType,
	const wstring &wstrFilePath,
	const wstring &wstrObjectKey,
	const wstring &wstrStateKey,
	const int &imageCount)
{
	Texture *pTexture = nullptr;

	auto iterFind = mMapTexture.find(wstrObjectKey);

	switch (eTextureType)
	{
	case TextureManager::SINGLE:
		// Single Texture - Object Key�� �̹� �����ϸ� ���� !!!!
		if (iterFind != mMapTexture.end())
		{
			return E_FAIL;
		}

		pTexture = new SingleTexture;
		mMapTexture.emplace(wstrObjectKey, pTexture);
		break;

	case TextureManager::MULTI:
		// MultiTexture - Object Key�� ���� ���� �� �� �� ���� !!!!
		if (iterFind == mMapTexture.end())
		{

			pTexture = new MultiTexture;
			mMapTexture.insert(map<const wstring, Texture *>::value_type(wstrObjectKey, pTexture));
			//mMapTexture.insert(std::pair<const wstring, Texture *>(wstrObjectKey, pTexture));
			//mMapTexture.insert(std::make_pair(wstrObjectKey, pTexture));
			//mMapTexture.emplace(wstrObjectKey, pTexture);
			//mMapTexture.insert({ wstrObjectKey, pTexture });
		}
		break;

	default:
		break;
	}

	return mMapTexture[wstrObjectKey]->LoadTexture(wstrFilePath, wstrStateKey, imageCount);
}

const TEXTURE_INFO* TextureManager::getTextureInfo(
	const wstring &wstrObjectKey,
	const wstring &wstrStateKey,
	const int &imageIndex)
{
	auto iterFind = mMapTexture.find(wstrObjectKey);
	if (iterFind == mMapTexture.end())
	{
		return nullptr;
	}

	//return mMapTexture[wstrObjectKey]->getTextureInfo(wstrStateKey, imageIndex);
	return iterFind->second->getTextureInfo(wstrStateKey, imageIndex);
}
