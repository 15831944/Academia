#include "stdafx.h"
#include "MainGame.h"


MainGame::MainGame()
	: mpDeviceManager(DeviceManager::getInstance()),
	mpTextureManager(TextureManager::getInstance()),
	mpObjManager(ObjManager::getInstance()),
	mpSceneManager(SceneManager::getInstance()),
	mpTimeManager(TimeManager::getInstance()),
	mpFrameManager(FrameManager::getInstance()),
	mpKeyManager(KeyManager::getInstance())
{
	
}


MainGame::~MainGame()
{
	Release();
}

void MainGame::Update()
{
	// ####################################
	// �Ź� Frame���� �ɸ� �ð��� ���� !!!!
	// ####################################
	mpTimeManager->UpdateTimer();

	mpKeyManager->UpdateKeyState();

	mpSceneManager->Update();
}

void MainGame::LateUpdate()
{
	mpSceneManager->LateUpdate();
}

void MainGame::Render()
{
	mpDeviceManager->RenderBegin();

	mpSceneManager->Render();

	mpFrameManager->RenderFrame(mpDeviceManager);

	mpDeviceManager->RenderEnd();
}

HRESULT MainGame::Init()
{
	HRESULT hr = 0;

	mpTimeManager->InitTimer();
	mpFrameManager->InitTimer();

	hr = mpDeviceManager->InitDevice(
		ghWnd,
		WINSIZE_X, WINSIZE_Y,
		DeviceManager::SCREEN_TYPE::WINDOWED
	);
	FAILED_CHECK_MSG_RETURN(hr, L"InitDevice() Failed, MainGame::Init()", E_FAIL);

	hr = mpTextureManager->LoadTextureFromImagePathFile(L"../Data/ImagePath.txt");
	FAILED_CHECK_MSG_RETURN(hr, L"LoadTextureFromImagePathFile() Failed, MainGame::Init()", E_FAIL);

	hr = mpSceneManager->ChangeScene(SceneManager::SCENE_TYPE::LOGO);
	FAILED_CHECK_MSG_RETURN(hr, L"ChangeScene() Failed, MainGame::Init()", E_FAIL);

	return S_OK;
}

void MainGame::Release()
{
	mpFrameManager->DestroyInstance();
	mpTimeManager->DestroyInstance();
	mpSceneManager->DestroyInstance();
	mpObjManager->DestroyInstance();

	// COM ��ü �Ҹ� ������, ���� ���Ѿ���
	mpTextureManager->DestroyInstance();
	mpDeviceManager->DestroyInstance();
}

MainGame* MainGame::Create()
{
	MainGame *pInstance = new MainGame;

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
