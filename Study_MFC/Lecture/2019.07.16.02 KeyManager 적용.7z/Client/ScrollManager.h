#pragma once
#ifndef _SCROLL_MANAGER_H_
#define _SCROLL_MANAGER_H_


class ScrollManager
{
private:
	ScrollManager();
	~ScrollManager();

public:
	static void MoveScrollPos(const D3DXVECTOR3 &vMove) { mvScroll += vMove; }

public:
	static const D3DXVECTOR3& getScrollPos() { return mvScroll; }

public:
	static void setScrollPos(const D3DXVECTOR3 &vScrollPos) { mvScroll = vScrollPos; }

private:
	static D3DXVECTOR3 mvScroll;

};
#endif