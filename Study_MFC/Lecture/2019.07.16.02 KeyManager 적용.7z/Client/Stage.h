#pragma once
#ifndef _STAGE_H_
#define _STAGE_H_

#include "Scene.h"

class Stage : public Scene
{
public:
	Stage();
	virtual ~Stage();

public:
	// Scene��(��) ���� ��ӵ�
	virtual void Update() override;
	virtual void LateUpdate() override;
	virtual void Render() override;

private:
	virtual HRESULT Init() override;
	virtual void Release() override;

public:
	static Stage* Create();
};

#endif