#pragma once
#ifndef _PATH_EXTRACTOR_H_
#define _PATH_EXTRACTOR_H_

#include "afxwin.h"


// PathExtractor ��ȭ �����Դϴ�.

class PathExtractor : public CDialog
{
	DECLARE_DYNAMIC(PathExtractor)

public:
	PathExtractor(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~PathExtractor();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PATHEXTRACTOR };
#endif

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

public: // Message Function
	DECLARE_MESSAGE_MAP()
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedLoad();

private: // User Function
	void CreateHorizontalScrollForListBox();

private: // Control Variable
	CListBox mListBox;

private: // User Variable
	list<PATH_INFO *> mListPathInfo;

};

#endif