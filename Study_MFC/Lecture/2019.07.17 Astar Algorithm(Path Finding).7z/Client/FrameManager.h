#pragma once
#ifndef _FRAME_MANAGER_H_
#define _FRAME_MANAGER_H_

class FrameManager
{
	DECLARE_SINGLETON(FrameManager);

private:
	FrameManager();
	~FrameManager();

public:
	void InitTimer();
	bool LimitFrame(float frameLimit);
	void RenderFrame(DeviceManager *pDeviceManager);

private:
	LARGE_INTEGER	mOldTime;
	LARGE_INTEGER	mCurrentTime;
	LARGE_INTEGER	mCPUTick;

	float	mRenderTimeCount;	// "1��"���� FPS Rendering
	float	mFrameTimeCount;	// "1/���ѵ� ������ ��" �ð�(��) üũ
	int	mFPSCount;			// FPS ����ġ

	TCHAR	mszBuffer[MIN_STR];
};

#endif