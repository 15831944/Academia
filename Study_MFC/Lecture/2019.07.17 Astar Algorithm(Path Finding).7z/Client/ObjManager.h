#pragma once
#ifndef _OBJ_MANAGER_H_
#define _OBJ_MANAGER_H_

class Obj;

class ObjManager
{
	DECLARE_SINGLETON(ObjManager);

private:
	ObjManager();
	~ObjManager();

public:
	enum OBJ_TYPE
	{
		TERRAIN = 0,
		PLAYER,
		MONSTER,
		OBJ_TYPE_END
	};

public:
	void Update();
	void LateUpdate();
	void Render();

private:
	void Release();

public:
	HRESULT AddObject(ObjManager::OBJ_TYPE eObjType, Obj *pObj);

public:
	const Obj* getObject(ObjManager::OBJ_TYPE eObjType);

private:
	list<Obj *> mListObj[OBJ_TYPE_END];
};

#endif