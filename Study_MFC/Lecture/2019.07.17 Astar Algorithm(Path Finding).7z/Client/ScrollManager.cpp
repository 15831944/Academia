#include "stdafx.h"
#include "ScrollManager.h"

D3DXVECTOR3 ScrollManager::mvScroll = {0.0f, 0.0f, 0.0f};

ScrollManager::ScrollManager()
{
}

ScrollManager::~ScrollManager()
{
}
