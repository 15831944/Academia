#include "stdafx.h"
#include "AnimationImp.h"


AnimationImp::AnimationImp(
	wstring wstrObjectKey, wstring wstrStateKey,
	float startFrameNum, float maxFrameNum)
	: mwstrObjectKey(wstrObjectKey), mwstrStateKey(wstrStateKey),
	mStartFrameNum(startFrameNum), mMaxFrameNum(maxFrameNum)
{
}

AnimationImp::~AnimationImp()
{
	Release();
}

int AnimationImp::Update()
{
	EffectImp::LateInit();

	mStartFrameNum += mMaxFrameNum * mpTimeManager->getDeltaTime();

	if (mStartFrameNum >= mMaxFrameNum)
	{
		return OBJ_DEAD;
	}

	return OBJ_NOEVENT;
}

void AnimationImp::LateUpdate()
{
}

void AnimationImp::Render(const D3DXMATRIX &matWorld)
{
	const TEXTURE_INFO *pTextureInfo = mpTextureManager->getTextureInfo(
		mwstrObjectKey, mwstrStateKey, (int)mStartFrameNum
	);
	NULL_CHECK(pTextureInfo);

	float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

	mpDeviceManager->getSprite()->SetTransform(&matWorld);
	mpDeviceManager->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,
		&D3DXVECTOR3(centerX, centerY, 0.0f),
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);
}

HRESULT AnimationImp::Init()
{
	return S_OK;
}

HRESULT AnimationImp::LateInit()
{
	return S_OK;
}

void AnimationImp::Release()
{
}

AnimationImp* AnimationImp::Create(
	wstring wstrObjectKey, wstring wstrStateKey,
	float startFrameNum, float maxFrameNum)
{
	AnimationImp *pInstance = new AnimationImp(
		wstrObjectKey, wstrStateKey, startFrameNum, maxFrameNum
	);

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
