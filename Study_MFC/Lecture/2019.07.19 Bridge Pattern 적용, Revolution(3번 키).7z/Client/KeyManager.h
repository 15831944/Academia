#pragma once
#ifndef _KEY_MANAGER_H_
#define _KEY_MANAGER_H_

const DWORD KEY_UP		= 0x00000001;
const DWORD KEY_DOWN	= 0x00000002;
const DWORD KEY_LEFT	= 0x00000004;
const DWORD KEY_RIGHT	= 0x00000008;

const DWORD KEY_RETURN	= 0x00000010; // 16
const DWORD KEY_SPACE	= 0x00000020; // 32

const DWORD KEY_LBUTTON = 0x00000040; // 64
const DWORD KEY_RBUTTON	= 0x00000080; // 128

const DWORD KEY_1		= 0x00000100; // 256
const DWORD KEY_2		= 0x00000200; // 512
const DWORD KEY_3		= 0x00000400; // 1024
const DWORD KEY_4		= 0x00000800; // 2048

class KeyManager
{
	DECLARE_SINGLETON(KeyManager);

public:
	KeyManager();
	~KeyManager();

public:
	void UpdateKeyState();

public:
	bool IsKeyDown(DWORD dwKey);
	bool IsKeyUp(DWORD dwKey);
	bool IsKeyPressing(DWORD dwKey);
	// ex) Ctrl + c, Ctrl + v
	bool IsKeyCombined(DWORD dwFirst, DWORD dwSecond);

private:
	DWORD mdwKey; // ���� ���� Ű.
	DWORD mdwKeyDown;	// KeyDown() �Լ����� ���Ǵ� ���� ���� ����
	DWORD mdwKeyUp;		// KeyUp() �Լ����� ���Ǵ� ���� ���� ����
};

#endif