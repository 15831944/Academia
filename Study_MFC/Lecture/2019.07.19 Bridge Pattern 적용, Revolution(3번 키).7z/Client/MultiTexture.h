#pragma once
#ifndef _MULTI_TEXTURE_H_
#define _MULTI_TEXTURE_H_

#include "Texture.h"

class MultiTexture : public Texture
{
public:
	MultiTexture();
	virtual ~MultiTexture();

public:
	// Texture��(��) ���� ��ӵ�
	virtual void Release() override;

public:
	virtual HRESULT LoadTexture(
		const wstring &wstrFilePath,
		const wstring &wstrStateKey = L"",
		const int &imageCount = 0
	) override;

public:
	virtual const TEXTURE_INFO* getTextureInfo(
		const wstring &wstrStateKey = L"",
		const int &imageIndex = 0
	) override;

private:
	typedef vector<TEXTURE_INFO *>					VEC_TEXTUREINFO;
	typedef map<const wstring, VEC_TEXTUREINFO>		MAP_MULTITEXTURE;
	MAP_MULTITEXTURE mMapMultiTexture;
};

#endif