#pragma once
#ifndef _NO_ANIMATION_IMP_H_
#define _NO_ANIMATION_IMP_H_

#include "EffectImp.h"

// ##########################################
// "Single Texture"�� �̿��� �ִϸ��̼�
// ##########################################
class NoAnimationImp : public EffectImp
{
private:
	explicit NoAnimationImp(
		wstring wstrObjectKey, wstring wstrStateKey, float lifeTime
	);

public:
	virtual ~NoAnimationImp();

public:
	// EffectImp��(��) ���� ��ӵ�
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(const D3DXMATRIX &matWorld) override;

private:
	virtual HRESULT Init() override;
	virtual HRESULT LateInit();
	virtual void Release() override;

public:
	static NoAnimationImp* Create(
		wstring wstrObjectKey, wstring wstrStateKey, float lifeTime
	);

private:
	wstring mwstrObjectKey;
	wstring mwstrStateKey;	// MultiTexture�� ���̴� �̹����� ����� �� �ֵ���...
	float mLifeTime;
	float mTimeCount;
};

#endif