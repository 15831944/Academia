#include "stdafx.h"

#include "EffectImp.h"

#include "NormalEffect.h"


NormalEffect::NormalEffect(EffectImp *pImp)
	: Effect(pImp)
{
}


NormalEffect::~NormalEffect()
{
	Release();
}

int NormalEffect::Update()
{
	Obj::LateInit();

	D3DXMATRIX matScale, matTrans;
	
	D3DXMatrixScaling(&matScale,
		mtInfo.vSize.x,
		mtInfo.vSize.y,
		0.0f
	);
	D3DXMatrixTranslation(&matTrans,
		mtInfo.vPos.x - ScrollManager::getScrollPos().x,
		mtInfo.vPos.y - ScrollManager::getScrollPos().y,
		0.0f
	);

	mtInfo.matWorld = matScale * matTrans;

	return mpImplementor->Update();
}

void NormalEffect::LateUpdate()
{
	mpImplementor->LateUpdate();
}

void NormalEffect::Render()
{
	// ###############################################
	// Implementer�� �ڽ��� World Matrix�� �Ѱ���.
	// ###############################################
	mpImplementor->Render(mtInfo.matWorld);
}

HRESULT NormalEffect::Init()
{
	mtInfo.vSize = { 1.0f, 1.0f, 0.0f };
	mtInfo.vDirOrigin = { 1.0f, 0.0f, 0.0f };

	return S_OK;
}

HRESULT NormalEffect::LateInit()
{
	return S_OK;
}

void NormalEffect::Release()
{
}

NormalEffect* NormalEffect::Create(EffectImp *pImp, const D3DXVECTOR3 &vPos)
{
	NULL_CHECK_RETURN(pImp, nullptr);

	NormalEffect *pInstance = new NormalEffect(pImp);

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pImp);
		return nullptr;
	}

	pInstance->SetPos(vPos);

	return pInstance;
}
