#pragma once
#ifndef _FILE_INFO_H_
#define _FILE_INFO_H_

class FileInfo
{
private:
	FileInfo();
	~FileInfo();

public:
	static CString ConvertRelativePath(const CString strFullPath);

	static void ExtractDirectoryInfo(const TCHAR *pFileFullPath, list<PATH_INFO *> *pListPathInfo);
	static int ExtractImageFileCount(const TCHAR *pFileFullPath);
};

#endif