#include "stdafx.h"
#include "EffectImp.h"


EffectImp::EffectImp()
	: mpDeviceManager(DeviceManager::getInstance()),
	mpTextureManager(TextureManager::getInstance()),
	mpTimeManager(TimeManager::getInstance()),
	mIsInit(false)
{
}

EffectImp::~EffectImp()
{
}

HRESULT EffectImp::LateInit()
{
	if (!(mIsInit))
	{
		this->LateInit();
		mIsInit = true;
	}

	return S_OK;
}
