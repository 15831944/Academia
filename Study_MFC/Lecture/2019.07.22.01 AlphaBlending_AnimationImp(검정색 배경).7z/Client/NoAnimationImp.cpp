#include "stdafx.h"
#include "NoAnimationImp.h"


NoAnimationImp::NoAnimationImp(
	wstring wstrObjectKey, wstring wstrStateKey,
	float lifeTime)
	: mwstrObjectKey(wstrObjectKey), mwstrStateKey(wstrStateKey),
	mLifeTime(lifeTime), mTimeCount(0.0f)
{
}


NoAnimationImp::~NoAnimationImp()
{
	Release();
}

int NoAnimationImp::Update()
{
	mTimeCount += mpTimeManager->getDeltaTime();

	if (mTimeCount >= mLifeTime)
	{
		return OBJ_DEAD;
	}

	return OBJ_NOEVENT;
}

void NoAnimationImp::LateUpdate()
{
}

void NoAnimationImp::Render(const D3DXMATRIX &matWorld)
{
	const TEXTURE_INFO *pTextureInfo = mpTextureManager->getTextureInfo(
		mwstrObjectKey, mwstrStateKey, 7
	);
	NULL_CHECK(pTextureInfo);

	float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
	float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

	mpDeviceManager->getSprite()->SetTransform(&matWorld);
	mpDeviceManager->getSprite()->Draw(
		pTextureInfo->pTexture,
		nullptr,
		&D3DXVECTOR3(centerX, centerY, 0.0f),
		nullptr,
		D3DCOLOR_ARGB(255, 255, 255, 255)
	);
}

HRESULT NoAnimationImp::Init()
{
	return S_OK;
}

HRESULT NoAnimationImp::LateInit()
{
	return S_OK;
}

void NoAnimationImp::Release()
{
}

NoAnimationImp* NoAnimationImp::Create(
	wstring wstrObjectKey, wstring wstrStateKey,
	float lifeTime)
{
	NoAnimationImp *pInstance = new NoAnimationImp(
		wstrObjectKey, wstrStateKey, lifeTime
	);

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
