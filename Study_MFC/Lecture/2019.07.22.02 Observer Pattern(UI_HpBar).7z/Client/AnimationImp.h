#pragma once
#ifndef _ANIMATION_IMP_H_
#define _ANIMATION_IMP_H_

#include "EffectImp.h"

// ##########################################
// "MultiTexture"�� �̿��� �ִϸ��̼�
// ##########################################
class AnimationImp : public EffectImp
{
private:
	explicit AnimationImp(
	wstring wstrObjectKey, wstring wstrStateKey,
		float startFrameNum, float maxFrameNum);

public:
	virtual ~AnimationImp();

public:
	// EffectImp��(��) ���� ��ӵ�
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(const D3DXMATRIX & matWorld) override;

private:
	virtual HRESULT Init() override;
	virtual HRESULT LateInit();
	virtual void Release() override;

public:
	// Implementor ���� ��, Texture ��¿� �ʿ��� �������� ���� �ް� �ֽ��ϴ�.
	static AnimationImp* Create(
		wstring wstrObjectKey, wstring wstrStateKey,
		float startFrameNum, float maxFrameNum
	);

private:
	wstring mwstrObjectKey;
	wstring mwstrStateKey;
	float mStartFrameNum;
	float mMaxFrameNum;
};

#endif