#include "stdafx.h"
#include "DataSubject.h"

IMPLEMENT_SINGLETON(DataSubject);

DataSubject::DataSubject()
{
}


DataSubject::~DataSubject()
{
}

void DataSubject::RegisterData(int message, void *pData)
{
	NULL_CHECK(pData);

	mMapData.insert(map<int, void *>::value_type(message, pData));

	// ó������ ���� ����� ����� ��, Notify�� �˷���� �մϴ�.
	Subject::Notify(message);
}

void DataSubject::RemoveData(int message)
{
	auto iterFind = mMapData.find(message);
	if (iterFind == mMapData.end())
	{
		return;
	}

	mMapData.erase(message);
}

void* DataSubject::GetMessageData(int message)
{
	auto iterFind = mMapData.find(message);
	if (iterFind == mMapData.end())
	{
		return nullptr;
	}

	return iterFind->second;
}