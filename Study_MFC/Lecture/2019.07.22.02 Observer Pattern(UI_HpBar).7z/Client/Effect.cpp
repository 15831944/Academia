#include "stdafx.h"

#include "EffectImp.h"

#include "Effect.h"


Effect::Effect(EffectImp *pImp)
	: mpImplementor(pImp)
{
}


Effect::~Effect()
{
	Release();
}

void Effect::Release()
{
	SafeDelete(mpImplementor);
}
