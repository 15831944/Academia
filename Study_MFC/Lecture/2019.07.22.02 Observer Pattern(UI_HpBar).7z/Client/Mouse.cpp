#include "stdafx.h"
#include "Mouse.h"


Mouse::Mouse()
{
}


Mouse::~Mouse()
{
}

const D3DXVECTOR3 Mouse::getMousePos()
{
	POINT pt = {};
	GetCursorPos(&pt);
	ScreenToClient(ghWnd, &pt);

	return D3DXVECTOR3(
		pt.x + ScrollManager::getScrollPos().x,
		pt.y + ScrollManager::getScrollPos().y,
		0.f
	);
}
