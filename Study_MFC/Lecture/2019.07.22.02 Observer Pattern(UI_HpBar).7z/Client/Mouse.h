#pragma once
#ifndef _MOUSE_H_
class Mouse
{
private:
	Mouse();
	~Mouse();

public:
	static const D3DXVECTOR3 getMousePos();
};

#endif

