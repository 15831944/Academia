#include "stdafx.h"
#include "Obj.h"


Obj::Obj()
	: mpDeviceManager(DeviceManager::getInstance()),
	mpObjManager(ObjManager::getInstance()),
	mpTextureManager(TextureManager::getInstance()),
	mpTimeManager(TimeManager::getInstance()),
	mIsInit(false)
{
}


Obj::~Obj()
{
}

HRESULT Obj::LateInit()
{
	if (mIsInit == false)
	{
		this->LateInit();
		mIsInit = true;
	}

	return S_OK;
}
