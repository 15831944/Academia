#pragma once
#ifndef _OBJ_H_
#define _OBJ_H_

class Obj
{
protected:
	explicit Obj();

public:
	virtual ~Obj();

public:
	virtual int Update() PURE;
	virtual void LateUpdate() PURE;
	virtual void Render() PURE;

protected:
	virtual HRESULT Init() PURE;
	virtual HRESULT LateInit();
	virtual void Release() PURE;

public:
	const INFO& getInfo() const { return mtInfo; }

public:
	void SetPos(const D3DXVECTOR3 &vPos) { mtInfo.vPos = vPos; }

protected:
	DeviceManager	*mpDeviceManager;
	ObjManager		*mpObjManager;
	TextureManager	*mpTextureManager;
	TimeManager		*mpTimeManager;

	bool mIsInit;

	INFO mtInfo;

};

#endif