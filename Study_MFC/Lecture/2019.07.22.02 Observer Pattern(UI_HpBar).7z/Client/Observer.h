#pragma once
#ifndef _OBSERVER_H_
#define _OBSERVER_H_

class Observer
{
public:
	Observer();
	virtual ~Observer();

public:
	virtual void Update(int message) PURE;
};

#endif