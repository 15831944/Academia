#include "stdafx.h"
#include "Scene.h"


Scene::Scene()
	: mpObjManager(ObjManager::getInstance()),
	mpSceneManager(SceneManager::getInstance())
{
}


Scene::~Scene()
{
}
