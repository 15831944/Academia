#pragma once
#ifndef _SCENE_H_
#define _SCENE_H_

class Scene
{
protected:
	explicit Scene();

public:
	virtual ~Scene();

public:
	virtual void Update() PURE;
	virtual void LateUpdate() PURE;
	virtual void Render() PURE;

protected:
	virtual HRESULT Init() PURE;
	virtual void Release() PURE;

protected:
	ObjManager		*mpObjManager;
	SceneManager	*mpSceneManager;
};

#endif