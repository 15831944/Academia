#include "stdafx.h"

#include "Logo.h"
#include "Stage.h"

#include "SceneManager.h"

IMPLEMENT_SINGLETON(SceneManager);

SceneManager::SceneManager()
	: mpCurrentScene(nullptr),
	meCurrentSceneType(SCENE_TYPE_END),
	meNextSceneType(SCENE_TYPE_END)
{
}


SceneManager::~SceneManager()
{
	Release();
}

void SceneManager::Update()
{
	// ���� Scene�� �ִ������� Ȯ�� !!!
	NULL_CHECK_MSG(mpCurrentScene, L"mpCurrentScene Not Found, SceneManager::Update()");
	mpCurrentScene->Update();
}

void SceneManager::LateUpdate()
{
	NULL_CHECK_MSG(mpCurrentScene, L"mpCurrentScene Not Found, SceneManager::LateUpdate()");
	mpCurrentScene->LateUpdate();
}

void SceneManager::Render()
{
	NULL_CHECK_MSG(mpCurrentScene, L"mpCurrentScene Not Found, SceneManager::Render()");
	mpCurrentScene->Render();
}

void SceneManager::Release()
{
	SafeDelete(mpCurrentScene);
}

HRESULT SceneManager::ChangeScene(SceneManager::SCENE_TYPE eSceneType)
{
	meNextSceneType = eSceneType;
	// ���� Scene�� �ٲ��� �ϴ� Scene�� ������ �ٸ���, Scene ��ȯ�� �߻���.
	if (meNextSceneType != meCurrentSceneType)
	{
		SafeDelete(mpCurrentScene);

		switch (meNextSceneType)
		{
		case SceneManager::LOGO:
			mpCurrentScene = Logo::Create();
			break;

		case SceneManager::STAGE:
			mpCurrentScene = Stage::Create();
			break;

		default:
			break;
		}

		NULL_CHECK_RETURN(mpCurrentScene, E_FAIL);

		meCurrentSceneType = meNextSceneType;
	}

	return S_OK;
}
