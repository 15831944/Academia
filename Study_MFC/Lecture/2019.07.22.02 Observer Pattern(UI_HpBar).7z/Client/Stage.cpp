#include "stdafx.h"

#include "Terrain.h"
#include "Player.h"
#include "HpBar.h"

#include "Stage.h"


Stage::Stage()
{
}


Stage::~Stage()
{
	Release();
}

void Stage::Update()
{
	mpObjManager->Update();
}

void Stage::LateUpdate()
{
	mpObjManager->LateUpdate();
}

void Stage::Render()
{
	mpObjManager->Render();
}

HRESULT Stage::Init()
{
	Obj *pObj = nullptr;
	HRESULT hr = 0;

	// Terrain
	pObj = Terrain::Create();
	NULL_CHECK_MSG_RETURN(pObj, L"Terrain Create Failed, Stage::Init()", E_FAIL);

	hr = mpObjManager->AddObject(ObjManager::OBJ_TYPE::TERRAIN, pObj);
	FAILED_CHECK_MSG_RETURN(hr, L"Terrain AddObject() Failed, Stage::Init()", E_FAIL);

	// Player
	pObj = Player::Create();
	NULL_CHECK_MSG_RETURN(pObj, L"Player Create Failed, Stage::Init()", E_FAIL);

	hr = mpObjManager->AddObject(ObjManager::OBJ_TYPE::PLAYER, pObj);
	FAILED_CHECK_MSG_RETURN(hr, L"Player AddObject() Failed, Stage::Init()", E_FAIL);

	// HpBar
	pObj = HpBar::Create();
	NULL_CHECK_MSG_RETURN(pObj, L"HpBar Create Failed, Stage::Init()", E_FAIL);

	hr = mpObjManager->AddObject(ObjManager::OBJ_TYPE::PLAYER, pObj);
	FAILED_CHECK_MSG_RETURN(hr, L"HpBar AddObject() Failed, Stage::Init()", E_FAIL);




	return S_OK;
}

void Stage::Release()
{
}

Stage* Stage::Create()
{
	Stage *pInstance = new Stage;

	if (FAILED(pInstance->Init()))
	{
		SafeDelete(pInstance);
		return nullptr;
	}

	return pInstance;
}
