#include "stdafx.h"

#include "Observer.h"

#include "Subject.h"


Subject::Subject()
{
}


Subject::~Subject()
{
	Release();
}

void Subject::Subscribe(Observer *pObserver)
{
	NULL_CHECK(pObserver);

	mListObserver.emplace_back(pObserver);
}

void Subject::UnSubscribe(Observer *pObserver)
{
	auto iterFind = find(mListObserver.begin(), mListObserver.end(), pObserver);
	if (iterFind == mListObserver.end())
	{
		return;
	}

	mListObserver.erase(iterFind);
}

void Subject::Notify(int message)
{
	// Message ��ȣ�� ���ؼ� ���� ������ �˷��ݴϴ�.
	for (auto &pObserver : mListObserver)
	{
		pObserver->Update(message);
	}
}

void Subject::Release()
{
	mListObserver.clear();
}
