#pragma once
#ifndef _TEXTURE_MANAGER_H_
#define _TEXTURE_MANAGER_H_

class Texture;

class TextureManager
{
	DECLARE_SINGLETON(TextureManager);

private:
	TextureManager();
	~TextureManager();

public:
	enum TEXTURE_TYPE
	{
		SINGLE = 0,
		MULTI
	};

public:
	void Release();

public:
	HRESULT LoadTexture(
		TextureManager::TEXTURE_TYPE eTextureType,
		const wstring &wstrFilePath,
		const wstring &wstrObjectKey,
		const wstring &wstrStateKey = L"",
		const int &imageCount = 0
	);
	HRESULT LoadTextureFromImagePathFile(const wstring &wstrFilePath);

public:
	const TEXTURE_INFO* getTextureInfo(
		const wstring &wstrObjectKey,
		const wstring &wstrStateKey = L"",
		const int &imageIndex = 0
	);

private:
	map<const wstring, Texture *> mMapTexture;
};

#endif