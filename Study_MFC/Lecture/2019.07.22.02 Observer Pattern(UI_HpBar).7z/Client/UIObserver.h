#pragma once
#ifndef _UI_OBSERVER_H_
#define _UI_OBSERVER_H_

#include "Observer.h"

class UIObserver : public Observer
{
public:
	UIObserver();
	virtual ~UIObserver();

public:
	// Observer��(��) ���� ��ӵ�
	virtual void Update(int message) override;

public:
	int getPlayerHp() const { return mPlayerHp; }

public:
	static UIObserver* Create();

private:
	DataSubject	*mpDataSubject;
	int			mPlayerHp;
};

#endif