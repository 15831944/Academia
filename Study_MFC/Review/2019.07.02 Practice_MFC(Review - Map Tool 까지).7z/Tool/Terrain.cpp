#include "stdafx.h"

#include "MainFrm.h"
#include "ToolView.h"

#include "Terrain.h"

CTerrain::CTerrain()
{
}

CTerrain::~CTerrain()
{
	Release();
}

void CTerrain::Render() const
{
	D3DXMATRIX matScale, matTrans, matWorld;

	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		D3DXMatrixScaling(&matScale, m_vecTile[i]->vSize.x, m_vecTile[i]->vSize.y, 0.0f);
		D3DXMatrixTranslation(
			&matTrans,
			m_vecTile[i]->vPos.x - m_pToolView->GetScrollPos(0),
			m_vecTile[i]->vPos.y - m_pToolView->GetScrollPos(1),
			0.0f
		);

		matWorld = matScale * matTrans;

		const TEXTURE_INFO *pTextureInfo = CTextureManager::getInstance()->getTextureInfo(
			L"Terrain", L"Tile", m_vecTile[i]->byDrawID
		);

		float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
		float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

		CDeviceManager::getInstance()->getSprite()->SetTransform(&matWorld);
		CDeviceManager::getInstance()->getSprite()->Draw(
			pTextureInfo->pTexture,
			nullptr,
			&D3DXVECTOR3(centerX, centerY, 0.0f),
			nullptr,
			D3DCOLOR_ARGB(255, 255, 255, 255)
		);

	}
}

void CTerrain::RenderMiniView() const
{
	D3DXMATRIX matScale, matTrans, matWorld;

	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		D3DXMatrixScaling(
			&matScale,
			m_vecTile[i]->vSize.x * 0.3f,
			m_vecTile[i]->vSize.y * 0.3f,
			0.0f
		);

		D3DXMatrixTranslation(
			&matTrans,
			m_vecTile[i]->vPos.x * 0.3f,
			m_vecTile[i]->vPos.y * 0.3f,
			0.0f
		);

		matWorld = matScale * matTrans;

		const TEXTURE_INFO *pTextureInfo = CTextureManager::getInstance()->getTextureInfo(
			L"Terrain", L"Tile", m_vecTile[i]->byDrawID
		);

		float centerX = pTextureInfo->tImageInfo.Width * 0.5f;
		float centerY = pTextureInfo->tImageInfo.Height * 0.5f;

		CDeviceManager::getInstance()->getSprite()->SetTransform(&matWorld);
		CDeviceManager::getInstance()->getSprite()->Draw(
			pTextureInfo->pTexture,
			nullptr,
			&D3DXVECTOR3(centerX, centerY, 0.0f),
			nullptr,
			D3DCOLOR_ARGB(255, 255, 255, 255)
		);
	}
}


HRESULT CTerrain::Init()
{
	for (int i = 0; i < TILE_Y; ++i)
	{
		for (int j = 0; j < TILE_X; ++j)
		{
			TILE_INFO *pTile = new TILE_INFO;
			NULL_CHECK_MSG_RETURN(pTile, L"TILE_INFO memory allocation Failed, CTerrain::Init()", E_FAIL);

			pTile->vPos.x = (j * TILESIZE_X) + (i % 2) * (TILESIZE_X * 0.5f);
			pTile->vPos.y = i * (TILESIZE_Y * 0.5f);
			pTile->vSize = { 1.0f, 1.0f, 0.0f };

			pTile->byDrawID = 9;
			pTile->byOption = 0;

			m_vecTile.emplace_back(pTile);
		}
	}

	return S_OK;
}


void CTerrain::Release()
{
	for_each(m_vecTile.begin(), m_vecTile.end(), SafeDelete<TILE_INFO *>);

	m_vecTile.clear();
	m_vecTile.shrink_to_fit();
}

void CTerrain::ChangeTile(
	const D3DXVECTOR3 &vPos,
	const BYTE &byDrawID,
	const BYTE &byOption)
{
	int index = GetTileIndex(vPos);

	if (index < 0
		|| (size_t)index >= m_vecTile.size())
	{
		return;
	}

	m_vecTile[(size_t)index]->byDrawID = byDrawID;
	m_vecTile[(size_t)index]->byOption = byOption;
}

HRESULT CTerrain::SaveTile(const TCHAR *pFilePath) const
{
	HANDLE hFile = CreateFile(
		pFilePath,
		GENERIC_WRITE,
		0,
		0,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		nullptr
	);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return E_FAIL;
	}

	DWORD dwByte = 0;

	for (auto &pTile : m_vecTile)
	{
		WriteFile(hFile, pTile, sizeof(TILE_INFO), &dwByte, nullptr);
	}

	CloseHandle(hFile);

	return S_OK;
}

HRESULT CTerrain::LoadTile(const TCHAR *pFilePath)
{
	HANDLE hFile = CreateFile(
		pFilePath,
		GENERIC_READ,
		0,
		0,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		nullptr
	);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return E_FAIL;
	}

	if (!(m_vecTile.empty()))
	{
		Release();
	}

	DWORD dwByte = 0;
	TILE_INFO *pTileInfo = nullptr;
	TILE_INFO tReadTileInfo = {};

	while (true)
	{
		ReadFile(hFile, &tReadTileInfo, sizeof(TILE_INFO), &dwByte, nullptr);

		if (dwByte == 0)
		{
			break;
		}

		pTileInfo = new TILE_INFO(tReadTileInfo);
		m_vecTile.emplace_back(pTileInfo);
	}

	CloseHandle(hFile);

	return S_OK;
}



int CTerrain::GetTileIndex(const D3DXVECTOR3 &vPos)
{
	for (size_t i = 0; i < m_vecTile.size(); ++i)
	{
		/*if (IsPicking(vPos, i))
		{
			return (int)i;
		}*/

		if (IsPickingWithScalar(vPos, i))
		{
			return (int)i;
		}
	}
	return -1;
}

bool CTerrain::IsPicking(const D3DXVECTOR3 &vPos, size_t index)
{
	// Cartesian Coordinate
	// - Linear Equation

	D3DXVECTOR3 vVertex[4] = {
		{ m_vecTile[index]->vPos.x, m_vecTile[index]->vPos.y + (TILESIZE_Y * 0.5f), 0.0f },	// direction to 12 o'clock
		{ m_vecTile[index]->vPos.x + (TILESIZE_X * 0.5f), m_vecTile[index]->vPos.y, 0.0f },	// direction to 03 o'clock
		{ m_vecTile[index]->vPos.x, m_vecTile[index]->vPos.y - (TILESIZE_Y * 0.5f), 0.0f },	// direction to 06 o'clock
		{ m_vecTile[index]->vPos.x - (TILESIZE_X * 0.5f), m_vecTile[index]->vPos.y, 0.0f }	// direction to 09 o'clock
	};

	float gradient[4] = {
		(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		-(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f),
		-(TILESIZE_Y * 0.5f) / (TILESIZE_X * 0.5f)
	};

	float b[4] = {
		vVertex[0].y - gradient[0] * vVertex[0].x,
		vVertex[1].y - gradient[1] * vVertex[1].x,
		vVertex[2].y - gradient[2] * vVertex[2].x,
		vVertex[3].y - gradient[3] * vVertex[3].x
	};

	return (gradient[0] * vPos.x + b[0] - vPos.y > 0
		&& gradient[1] * vPos.x + b[1] - vPos.y > 0
		&& gradient[2] * vPos.x + b[2] - vPos.y < 0
		&& gradient[3] * vPos.x + b[3] - vPos.y < 0);
}

bool CTerrain::IsPickingWithScalar(const D3DXVECTOR3 &vPos, size_t index)
{
	D3DXVECTOR3 vVertex[4] = {
		{ m_vecTile[index]->vPos.x, m_vecTile[index]->vPos.y + (TILESIZE_Y * 0.5f), 0.0f },	// direction to 12 o'clock
		{ m_vecTile[index]->vPos.x + (TILESIZE_X * 0.5f), m_vecTile[index]->vPos.y, 0.0f },	// direction to 03 o'clock
		{ m_vecTile[index]->vPos.x, m_vecTile[index]->vPos.y - (TILESIZE_Y * 0.5f), 0.0f },	// direction to 06 o'clock
		{ m_vecTile[index]->vPos.x - (TILESIZE_X * 0.5f), m_vecTile[index]->vPos.y, 0.0f }	// direction to 09 o'clock
	};

	D3DXVECTOR3 vRhombusDir[4] = {
		vVertex[1] - vVertex[0],
		vVertex[2] - vVertex[1],
		vVertex[3] - vVertex[2],
		vVertex[0] - vVertex[3]
	};

	D3DXVECTOR3 vNormal[4] = {};

	for (int i = 0; i < 4; ++i)
	{
		D3DXVec3Cross(&vNormal[i], &D3DXVECTOR3(0.0f, 0.0f, 1.0f), &vRhombusDir[i]);
	}

	D3DXVECTOR3 vMouseDir[4] = {
		vPos - vVertex[0],
		vPos - vVertex[1],
		vPos - vVertex[2],
		vPos - vVertex[3]
	};


	for (int i = 0; i < 4; ++i)
	{
		if (D3DXVec3Dot(&vNormal[i], &vMouseDir[i]) > 0)
		{
			return false;
		}
	}

	return true;
}

CTerrain* CTerrain::Create(CToolView *pToolView)
{
	CTerrain *pInstance = new CTerrain;

	if (pInstance->Init())
	{
		delete pInstance;
		return nullptr;
	}

	pInstance->setToolView(pToolView);

	return pInstance;
}
