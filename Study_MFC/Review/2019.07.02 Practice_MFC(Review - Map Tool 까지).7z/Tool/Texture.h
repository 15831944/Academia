#pragma once
#ifndef _TEXTURE_H_
#define _TEXTURE_H_

class CTexture
{
public:
	CTexture();
	virtual ~CTexture();

public:
	virtual void Release() PURE;

public:
	virtual HRESULT LoadTexture(
		const wstring &wstrFilePath,
		const wstring &wstrStateKey = L"",
		const int &count = 0
	) PURE;

public:
	virtual const TEXTURE_INFO* getTextureInfo(
		const wstring &wstrStateKey = L"",
		const int &index = 0
	) PURE;
};

#endif