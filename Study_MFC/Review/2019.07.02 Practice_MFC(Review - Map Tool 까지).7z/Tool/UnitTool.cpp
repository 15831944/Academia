// UnitTool.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Tool.h"
#include "UnitTool.h"
#include "afxdialogex.h"


// CUnitTool ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CUnitTool, CDialog)

CUnitTool::CUnitTool(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_UNITTOOL, pParent)
	, m_strInput(_T(""))
	, m_strOutput(_T(""))
	, m_strName(_T(""))
	, m_iAttackDamage(0)
	, m_iDefense(0)
	, m_strSearchName(_T(""))
{

}

CUnitTool::~CUnitTool()
{
	for (auto &MyPair : m_mapUnitData)
	{
		SafeDelete(MyPair.second);
	}
	m_mapUnitData.clear();
}

void CUnitTool::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_strInput);
	DDX_Text(pDX, IDC_EDIT2, m_strOutput);
	DDX_Text(pDX, IDC_EDIT3, m_strName);
	DDX_Text(pDX, IDC_EDIT4, m_iAttackDamage);
	DDX_Text(pDX, IDC_EDIT5, m_iDefense);
	DDX_Control(pDX, IDC_RADIO1, m_Radio[0]);
	DDX_Control(pDX, IDC_RADIO2, m_Radio[1]);
	DDX_Control(pDX, IDC_RADIO3, m_Radio[2]);
	DDX_Control(pDX, IDC_LIST1, m_ListBox);
	DDX_Text(pDX, IDC_EDIT6, m_strSearchName);
}


BOOL CUnitTool::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	m_Radio[0].SetCheck(TRUE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CUnitTool, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &CUnitTool::OnBnClickedPush)
	ON_BN_CLICKED(IDC_BUTTON2, &CUnitTool::OnBnClickedAdd)
	ON_LBN_SELCHANGE(IDC_LIST1, &CUnitTool::OnLbnSelchangeUnitData)
	ON_EN_CHANGE(IDC_EDIT6, &CUnitTool::OnEnChangeSearch)
	ON_BN_CLICKED(IDC_BUTTON3, &CUnitTool::OnBnClickedDelete)
	ON_BN_CLICKED(IDC_BUTTON4, &CUnitTool::OnBnClickedSave)
	ON_BN_CLICKED(IDC_BUTTON5, &CUnitTool::OnBnClickedLoad)
END_MESSAGE_MAP()


// CUnitTool �޽��� ó�����Դϴ�.


void CUnitTool::OnBnClickedPush()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	// ############################################################################
	UpdateData(TRUE); // Control -> Variable

	m_strOutput = m_strInput;

	UpdateData(FALSE); // Variable -> Control
	// ############################################################################
}


void CUnitTool::OnBnClickedAdd()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	UpdateData(TRUE);

	auto iterFind = m_mapUnitData.find(m_strName);
	if (iterFind != m_mapUnitData.end())
	{
		return;
	}

	UNIT_DATA *pUnitData = new UNIT_DATA;
	NULL_CHECK(pUnitData);

	pUnitData->strName = m_strName;
	pUnitData->iAttackDamage = m_iAttackDamage;
	pUnitData->iDefense = m_iDefense;

	for (int i = 0; i < 3; ++i)
	{
		if (m_Radio[i].GetCheck())
		{
			pUnitData->iClassIndex = i;
			break;
		}
	}

	m_mapUnitData.emplace(m_strName, pUnitData);

	// ############################################################################
	m_ListBox.AddString(m_strName);
	// ############################################################################

	m_ListBox.SetCurSel(m_ListBox.GetCount() - 1);

	cout << m_ListBox.GetCount() << endl;

	OnLbnSelchangeUnitData();

	UpdateData(FALSE);
}


void CUnitTool::OnLbnSelchangeUnitData()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	UpdateData(TRUE);

	int iIndex = m_ListBox.GetCurSel();
	if (iIndex == -1)
	{
		return;
	}

	CString strSelectName = L"";

	// ############################################################################
	m_ListBox.GetText(iIndex, strSelectName);
	// ############################################################################

	auto iterFind = m_mapUnitData.find(strSelectName);
	if (iterFind == m_mapUnitData.end())
	{
		return;
	}

	//m_strName = iterFind->second->strName;
	//m_iAttackDamage = iterFind->second->iAttackDamage;
	//m_iDefense = iterFind->second->iDefense;

	m_strName = m_mapUnitData[strSelectName]->strName;
	m_iAttackDamage = m_mapUnitData[strSelectName]->iAttackDamage;
	m_iDefense = m_mapUnitData[strSelectName]->iDefense;

	for (int i = 0; i < 3; ++i)
	{
		m_Radio[i].SetCheck(FALSE);
	}

	//int classIndex = iterFind->second->iClassIndex;
	int classIndex = m_mapUnitData[strSelectName]->iClassIndex;
	m_Radio[classIndex].SetCheck(TRUE);

	UpdateData(FALSE);
}


void CUnitTool::OnEnChangeSearch()
{
	// TODO:  RICHEDIT ��Ʈ���� ���, �� ��Ʈ����
	// CDialog::OnInitDialog() �Լ��� ������ 
	//�ϰ� ����ũ�� OR �����Ͽ� ������ ENM_CHANGE �÷��׸� �����Ͽ� CRichEditCtrl().SetEventMask()�� ȣ������ ������
	// �� �˸� �޽����� ������ �ʽ��ϴ�.

	// TODO:  ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	UpdateData(TRUE);

	auto iterFind = m_mapUnitData.find(m_strSearchName);
	if (iterFind == m_mapUnitData.end())
	{
		return;
	}

	// ############################################################################
	int iIndex = m_ListBox.FindString(-1, m_strSearchName);
	// ############################################################################
	if (iIndex == -1)
	{
		return;
	}

	m_ListBox.SetCurSel(iIndex);

	OnLbnSelchangeUnitData();

	UpdateData(FALSE);
}


void CUnitTool::OnBnClickedDelete()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	UpdateData(TRUE);

	int iIndex = m_ListBox.GetCurSel();

	CString strDeleteName = L"";

	m_ListBox.GetText(iIndex, strDeleteName);

	auto iterFind = m_mapUnitData.find(strDeleteName);
	if (iterFind == m_mapUnitData.end())
	{
		return;
	}

	SafeDelete(iterFind->second);
	m_mapUnitData.erase(iterFind);

	// ############################################################################
	m_ListBox.DeleteString(iIndex);
	// ############################################################################

	if (m_ListBox.GetCount() != 0)
	{
		if ((size_t)iIndex < m_mapUnitData.size())
		{
			m_ListBox.SetCurSel(iIndex);
		}
		else
		{
			m_ListBox.SetCurSel(iIndex - 1);
		}

		OnLbnSelchangeUnitData();
	}
	else
	{
		m_strName = L"";
		m_iAttackDamage = 0;
		m_iDefense = 0;
		
		for (int i = 0; i < 3; ++i)
		{
			m_Radio[i].SetCheck(FALSE);
		}
		m_Radio[0].SetCheck(TRUE);
	}

	UpdateData(FALSE);
}


void CUnitTool::OnBnClickedSave()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CFileDialog Dlg(
		FALSE, // Load(TRUE), Save(FALSE)
		L"dat", // default Ȯ����
		L"�������.dat", // default ���ϸ�
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, // �Ӽ���
		L"Data Files(*.dat)|*.dat|Text Files(*.txt)|*.txt||", // ���� & ���� ����
		this // �θ� ������
	);

	TCHAR szCurrentPath[MAX_STR] = L"";

	GetCurrentDirectory(MAX_STR, szCurrentPath);
	PathRemoveFileSpec(szCurrentPath);
	lstrcat(szCurrentPath, L"\\Data");

	Dlg.m_ofn.lpstrInitialDir = szCurrentPath;

	if (Dlg.DoModal() == IDOK)
	{
		HANDLE hFile = CreateFile(
			Dlg.GetPathName(),
			GENERIC_WRITE,
			0,
			0,
			CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL,
			nullptr
		);

		if (hFile == INVALID_HANDLE_VALUE)
		{
			ERR_MSG(L"Unit Save Failed");
			return;
		}

		DWORD dwByte = 0;
		int iStrLength = 0;

		for (auto &MyPair : m_mapUnitData)
		{
			iStrLength = MyPair.second->strName.GetLength() + 1; // NULL ���ڱ��� ����
			WriteFile(hFile, &iStrLength, sizeof(int), &dwByte, nullptr);

			// "CString"�� ���� ���ڿ��� �̾Ƴ��� !!!!
			const TCHAR *pString = MyPair.second->strName.GetString();
			WriteFile(hFile, pString, sizeof(TCHAR) * iStrLength, &dwByte, nullptr);

			WriteFile(hFile, &MyPair.second->iAttackDamage, sizeof(int), &dwByte, nullptr);
			WriteFile(hFile, &MyPair.second->iDefense, sizeof(int), &dwByte, nullptr);
			WriteFile(hFile, &MyPair.second->iClassIndex, sizeof(int), &dwByte, nullptr);
		}

		CloseHandle(hFile);

		AfxMessageBox(L"Unit Save Complete");
	}
}


void CUnitTool::OnBnClickedLoad()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CFileDialog Dlg(
		TRUE,
		L".dat",
		L"�������.dat",
		OFN_HIDEREADONLY,
		L"Data Files(*.dat)|*.dat|Text Files(*.txt)|*.txt||",
		nullptr
	);

	// �ʱ� ȭ�鿡 ������ ���͸� ������ ���� ����.
	TCHAR szCurrentPath[MAX_STR] = L"";

	GetCurrentDirectory(MAX_STR, szCurrentPath);
	PathRemoveFileSpec(szCurrentPath);
	lstrcat(szCurrentPath, L"\\Data");

	Dlg.m_ofn.lpstrInitialDir = szCurrentPath;

	if (Dlg.DoModal() == IDOK)
	{
		HANDLE hFile = CreateFile(
			Dlg.GetPathName(),
			GENERIC_READ,
			0,
			0,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			nullptr
		);

		if (hFile == INVALID_HANDLE_VALUE)
		{
			ERR_MSG(L"Unit Load Failed");
			return;
		}

		m_ListBox.ResetContent();

		if (!(m_mapUnitData.empty()))
		{
			for_each(m_mapUnitData.begin(), m_mapUnitData.end(),
				[](auto &MyPair)
			{
				SafeDelete(MyPair.second);
			});

			m_mapUnitData.clear();
		}

		DWORD dwByte = 0;
		int iStrLength = 0;

		UNIT_DATA *pUnitData = nullptr;
		int iAttackDamage = 0, iDefense = 0, iClassIndex = 0;

		while (true)
		{
			ReadFile(hFile, &iStrLength, sizeof(int), &dwByte, nullptr);

			TCHAR *pString = new TCHAR[iStrLength];
			ReadFile(hFile, pString, sizeof(TCHAR) * iStrLength, &dwByte, nullptr);

			ReadFile(hFile, &iAttackDamage, sizeof(int), &dwByte, nullptr);
			ReadFile(hFile, &iDefense, sizeof(int), &dwByte, nullptr);
			ReadFile(hFile, &iClassIndex, sizeof(int), &dwByte, nullptr);

			if (dwByte == 0)
			{
				delete[] pString;
				break;
			}

			pUnitData = new UNIT_DATA;
			pUnitData->strName = pString; // TCHAR => CString
			delete[] pString;

			pUnitData->iAttackDamage = iAttackDamage;
			pUnitData->iDefense = iDefense;
			pUnitData->iClassIndex = iClassIndex;

			m_mapUnitData.insert({ pUnitData->strName, pUnitData });
			m_ListBox.AddString(pUnitData->strName);
		}

		CloseHandle(hFile);

		AfxMessageBox(L"Unit Load Complete");

		if (!(m_mapUnitData.empty()))
		{
			m_ListBox.SetCurSel(0);
			OnLbnSelchangeUnitData();
		}
	}
}
