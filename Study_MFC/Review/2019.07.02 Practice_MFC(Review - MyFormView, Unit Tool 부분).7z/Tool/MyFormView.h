#pragma once
#include "afxwin.h"
#ifndef _MY_FORM_VIEW_H_
#define _MY_FORM_VIEW_H_


// CMyFormView �� ���Դϴ�.
class CUnitTool;
class CMapTool;

class CMyFormView : public CFormView
{
	DECLARE_DYNCREATE(CMyFormView)

protected:
	CMyFormView();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CMyFormView();

public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MYFORMVIEW };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected: // Virtual Function
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual void OnInitialUpdate();

	DECLARE_MESSAGE_MAP()

public: // Message Function
	afx_msg void OnBnClickedUnitTool();


private:
	CFont m_Font;

public:
	CUnitTool m_UnitTool;
};

#endif