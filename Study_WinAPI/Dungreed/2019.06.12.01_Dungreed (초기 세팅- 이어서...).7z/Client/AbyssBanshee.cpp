#include "stdafx.h"
#include "AbyssBanshee.h"


AbyssBanshee::AbyssBanshee()
{
}


AbyssBanshee::~AbyssBanshee()
{
}

void AbyssBanshee::Init()
{
}

int AbyssBanshee::Update()
{
	return OBJ_NOEVENT;
}

void AbyssBanshee::LateUpdate()
{
}

void AbyssBanshee::Render(HDC hdc)
{
}

void AbyssBanshee::Release()
{
}

void AbyssBanshee::Collision(const Obj * pObj, OBJ::TYPE type)
{
}
