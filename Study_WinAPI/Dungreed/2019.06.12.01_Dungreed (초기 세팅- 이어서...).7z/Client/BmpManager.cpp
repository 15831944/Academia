#include "stdafx.h"
#include "BmpManager.h"


BmpManager::BmpManager()
{
}


BmpManager::~BmpManager()
{
}
