#pragma once
#ifndef _CHAR_OBJ_H_
#define _CHAR_OBJ_H_

#include "Obj.h"

// Status�� �ְ�, �̵��� �� �ִ� Object�� ���� ���� Ŭ���� CharObj

class CharObj : public Obj
{
public:
	CharObj();
	virtual ~CharObj();

public:
	const int getCurHp() const { return mCurHp; }
	const int getAttackDamage() const { return mAttackDamage; }

public:
	void setCurHp(int hp) { mCurHp = hp; }
	void setAttackDamage(int attackDamage) { mAttackDamage = attackDamage; }

protected:
	int mCurHp;
	//int mMaxHp;
	int mAttackDamage;

};

#endif