#pragma once
#ifndef _FAIRY_H_
#define _FAIRY_H_

#include "Obj.h"

class Fairy : public Obj
{
public:
	Fairy();
	virtual ~Fairy();

public:
	enum TYPE {
		L,
		XL,
		END
	};

public:
	// Obj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual void LateInit() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hdc) override;
	virtual void Release() override;

public:
	virtual void Collision(const Obj * pObj, OBJ::TYPE type) override;

public:
	void setFairyType(Fairy::TYPE fairyType) { }

private:
	Fairy::TYPE meFairyType;

	bool mIsTriggerOn;

	TCHAR *mpFrameKey;
};

#endif