#pragma once
class LineManager
{
public:
	LineManager();
	~LineManager();
};

