#include "stdafx.h"

#include "Mouse.h"

#include "ObjManager.h"

#include "AbstractFactoryObj.h"

#include "MainGame.h"


MainGame::MainGame()
{
}


MainGame::~MainGame()
{
	Release();
}

void MainGame::Init()
{
	Obj *pMouse = AbstractFactoryObj<Mouse>::Create(WIN_WIDTH / 2.0f, WIN_HEIGHT / 2.0f);
	// ObjManager �� �߰��� ��.
}

void MainGame::Update()
{
}

void MainGame::LateUpdate()
{
}

void MainGame::Render()
{
}

void MainGame::Release()
{
}
