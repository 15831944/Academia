#include "stdafx.h"
#include "NiflHeim.h"


NiflHeim::NiflHeim()
{
}


NiflHeim::~NiflHeim()
{
}

void NiflHeim::Init()
{
}

int NiflHeim::Update()
{
	return OBJ_NOEVENT;
}

void NiflHeim::LateUpdate()
{
}

void NiflHeim::Render(HDC hdc)
{
}

void NiflHeim::Release()
{
}

void NiflHeim::Collision(const Obj * pObj, OBJ::TYPE type)
{
}
