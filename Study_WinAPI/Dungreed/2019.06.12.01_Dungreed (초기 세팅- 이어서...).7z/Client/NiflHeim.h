#pragma once
#ifndef _NIFLHEIM_H_
#define _NIFLHEIM_H_

#include "CharObj.h"

class NiflHeim : public CharObj
{
public:
	NiflHeim();
	virtual ~NiflHeim();

public:
	// CharObj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hdc) override;
	virtual void Release() override;

public:
	virtual void Collision(const Obj * pObj, OBJ::TYPE type) override;




};

#endif