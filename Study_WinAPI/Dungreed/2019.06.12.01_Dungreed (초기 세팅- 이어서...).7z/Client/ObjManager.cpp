#include "stdafx.h"

#include "Obj.h"

#include "ObjManager.h"

ObjManager* ObjManager::mpInstance = nullptr;

ObjManager::ObjManager()
{
}


ObjManager::~ObjManager()
{
	Release();
}

int ObjManager::Update()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		list<Obj *>::iterator iter = mObjList[i].begin();
		for (; iter != mObjList[i].end(); )
		{
			int eventNum = (*iter)->Update();
			if (eventNum == OBJ_DEAD)
			{
				SafeDelete((*iter));
				iter = mObjList[i].erase(iter);
			}
			else
			{
				++iter;
			}
		}
	}

	return OBJ_NOEVENT;
}

void ObjManager::LateUpdate()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mObjList[i])
		{
			pObj->LateUpdate();

			// Menu Ŭ������ Button ��ü�� ������, ���ܳ��� ����...
			// Button Manager ������ �� !!!
			if (mObjList[i].empty())
			{
				break;
			}
		}
	}
}

void ObjManager::Render(HDC hdc)
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mObjList[i])
		{
			pObj->Render(hdc);
		}
	}
}

void ObjManager::Release()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mObjList[i])
		{
			SafeDelete(pObj);
		}
		mObjList[i].clear();
		mObjList[i].swap(list<Obj *>());
	}
}

void ObjManager::AddObject(Obj * pObj, OBJ::TYPE type)
{
	if (pObj != nullptr)
	{
		mObjList[type].emplace_back(pObj);
	}
}

void ObjManager::AddObjectFront(Obj * pObj, OBJ::TYPE type)
{
	if (pObj != nullptr)
	{
		mObjList[type].emplace_front(pObj);
	}
}

void ObjManager::DeleteObjType(OBJ::TYPE type)
{
	for (Obj *pObj : mObjList[type])
	{

	}
}

const Obj * ObjManager::getPlayer() const
{
	return nullptr;
}

const Obj * ObjManager::getMouse() const
{
	return nullptr;
}

const Obj * ObjManager::getInventory() const
{
	return nullptr;
}

const Obj * ObjManager::getTarget(Obj * pObj, OBJ::TYPE type) const
{
	return nullptr;
}
