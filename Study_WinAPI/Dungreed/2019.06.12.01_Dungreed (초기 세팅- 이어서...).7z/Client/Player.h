#pragma once
#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "CharObj.h"

class Player : public CharObj
{
public:
	Player();
	virtual ~Player();

public:
	// CharObj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hdc) override;
	virtual void Release() override;

public:
	virtual void Collision(const Obj * pObj, OBJ::TYPE type) override;

private:

};

#endif