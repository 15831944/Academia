#pragma once
class SceneManager
{
public:
	SceneManager();
	~SceneManager();
};

