#include "stdafx.h"
#include "Tile.h"


Tile::Tile()
	: mDrawID(0), mOption(0)
{
	ZeroMemory(&mtInfo, sizeof(INFO));
	ZeroMemory(&mtRect, sizeof(RECT));
}


Tile::~Tile()
{
	Release();
}

void Tile::Init()
{
	mtInfo.width = (float)TILE_WIDTH;
	mtInfo.height = (float)TILE_HEIGHT;
}

void Tile::Render(HDC hdc)
{
	//Obj::UpdateRect();

	//int scrollX = ScrollManager::getScrollX();
	//int scrollY = ScrollManager::getScrollY();

	///*HDC hMemDCForTile = BmpManager::getInstance()->FindImage(L"Tile");

	//BitBlt(
	//hdc,
	//m_tRect.left + scrollX, m_tRect.top + scrollY,
	//m_tInfo.width, m_tInfo.height,
	//hMemDCForTile,
	//m_tInfo.width * m_iDrawID, 0,
	//SRCCOPY
	//);*/

	//Rectangle(hdc, m_tRect.left, m_tRect.top, m_tRect.right, m_tRect.bottom);

	mtRect.left = (LONG)(mtInfo.xPos - (mtInfo.width * 0.5f));
	mtRect.top = (LONG)(mtInfo.yPos - (mtInfo.height * 0.5f));
	mtRect.right = (LONG)(mtInfo.xPos + (mtInfo.width * 0.5f));
	mtRect.bottom = (LONG)(mtInfo.yPos + (mtInfo.height * 0.5f));

	Rectangle(hdc, mtRect.left, mtRect.top, mtRect.right, mtRect.bottom);
}

void Tile::Release()
{
}
