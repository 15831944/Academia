#include "stdafx.h"
#include "TileManager.h"


TileManager::TileManager()
{
}


TileManager::~TileManager()
{
}
