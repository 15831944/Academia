#pragma once
#ifndef _DEFINE_H_
#define _DEFINE_H_

// ##################################################################################
// ��ũ�� ���

#define WIN_WIDTH 1200
#define WIN_HEIGHT 720

#define TILE_WIDTH 64
#define TILE_HEIGHT 64

#define TILE_X 100
#define TILE_Y 100

#define OBJ_NOEVENT 0
#define OBJ_DEAD 1



#define GRAVITY 9.8f
#define LASER_WIDTH 128.0f * 9.0f;






// ##################################################################################
// ��ũ�� �Լ�

#define SAFE_DELETE(p)	\
if(p)					\
{						\
	delete p;			\
	p = nullptr;		\
}						\

#define DECLAR_SINGLETON(CLASS)		\
private:							\
	CLASS();						\
	~CLASS();						\
public:								\
	static CLASS* getInstance()		\
	{								\
		if (mpIstance == nullptr)	\
		{							\
			mpInstance = new CLASS;	\
		}							\
		return mpInstance;			\
	}								\
	static void DestroyInstance()	\
	{								\
		if (mpInstance)				\
		{							\
			delete mpInstance;		\
			mpInstance = nullptr;	\
		}							\
	}								\
private:							\
	static CLASS *mpInstance;		\


#define IMPLEMENT_SINGLETON(CLASS)	\
CLASS* CLASS::mpInstance = nullptr;	\



#endif