#include "stdafx.h"
#include "BitMap.h"


BitMap::BitMap()
{
}


BitMap::~BitMap()
{
	Release();
}

void BitMap::Release()
{
	
}

void BitMap::LoadBitMap(const TCHAR * pFilePath)
{
	HDC hdc = GetDC(ghWnd);
	mhMemDC = CreateCompatibleDC(hdc);

	ReleaseDC(ghWnd, hdc);

	// "Parmeter" �ǹ� �ľ��ϱ�.
	mhBitMap = (HBITMAP)LoadImage(
		NULL,
		pFilePath,
		IMAGE_BITMAP,
		0,
		0,
		LR_LOADFROMFILE | LR_CREATEDIBSECTION // ������ Load Resource ������...
	);

	mhOldBitMap = (HBITMAP)SelectObject(mhMemDC, mhBitMap);
}
