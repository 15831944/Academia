#include "stdafx.h"

#include "SceneManager.h"

#include "Button.h"


Button::Button()
	: meButtonType(BUTTON_TYPE::END),
	mdrawID(0),
	mIsPressed(FALSE)
{
}


Button::~Button()
{
	Release();
}

void Button::Init()
{
	mdwButtonCheckTime = GetTickCount();
}

void Button::LateInit()
{
	if (meButtonType == BUTTON_TYPE::MENU)
	{

	}
}

int Button::Update()
{


	return OBJ_NOEVENT;
}

void Button::LateUpdate()
{
}

void Button::Render(HDC hdc)
{
}

void Button::Release()
{
}

void Button::Collision(const Obj * pObj, OBJ::TYPE type)
{
}
