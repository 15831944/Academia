#pragma once
#ifndef _BUTTON_H_
#define _BUTTON_H_

#include "Obj.h"

class Button : public Obj
{
public:
	Button();
	virtual ~Button();

public:
	enum BUTTON_TYPE {
		MENU,
		SHOP,
		END
	};

public:
	// Obj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual void LateInit() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hdc) override;
	virtual void Release() override;

public:
	virtual void Collision(const Obj * pObj, OBJ::TYPE type) override;

public:
	BUTTON_TYPE getButtonType() const { return meButtonType; }
	bool getButtonPressed() const { return mIsPressed; }

public:
	void setButtonType(BUTTON_TYPE buttonType) { meButtonType = buttonType; }
	void setIsPressed(bool isTrue) { mIsPressed = isTrue; }

private:
	BUTTON_TYPE meButtonType;

	DWORD mdwButtonCheckTime;

	int mdrawID;

	bool mIsPressed;
};

#endif