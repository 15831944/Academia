#pragma once
class CollisionManager
{
public:
	CollisionManager();
	~CollisionManager();
};

