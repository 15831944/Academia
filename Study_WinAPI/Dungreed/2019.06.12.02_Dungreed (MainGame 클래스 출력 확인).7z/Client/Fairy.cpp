#include "stdafx.h"
#include "Fairy.h"


Fairy::Fairy()
	: meFairyType(TYPE::END),
	mIsTriggerOn(FALSE),
	mpFrameKey(nullptr)
{
}


Fairy::~Fairy()
{
	Release();
}

void Fairy::Init()
{
	mtInfo.width = 60.0f;
	mtInfo.height = 60.0f;

	mtFrame.frameStart = 0;
	mtFrame.frameEnd = 15;
	mtFrame.frameScene = 0;
	mtFrame.dwFrameSpeed = 80;
	mtFrame.dwFrameTime = GetTickCount();
}

void Fairy::LateInit()
{
	if (meFairyType == Fairy::TYPE::L)
	{
		mpFrameKey = L"Fairy_L";
		mtFrame.frameStart = 0;
	}
	else if (meFairyType == Fairy::TYPE::XL)
	{
		mpFrameKey = L"Fairy_XL";
		mtFrame.frameScene = 6;
	}
}

int Fairy::Update()
{
	Obj::LateInit();

	if (mIsDead)
	{
		return OBJ_DEAD;
	}


	return OBJ_NOEVENT;
}

void Fairy::LateUpdate()
{
	Obj::FrameMove();
}

void Fairy::Render(HDC hdc)
{
	Obj::UpdateRect();

	HDC hMemDCForFairy;
}

void Fairy::Release()
{

}

void Fairy::Collision(const Obj * pObj, OBJ::TYPE type)
{
	
}
