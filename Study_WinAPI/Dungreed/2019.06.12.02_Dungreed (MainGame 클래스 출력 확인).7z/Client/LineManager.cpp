#include "stdafx.h"
#include "LineManager.h"


LineManager::LineManager()
{
}


LineManager::~LineManager()
{
}
