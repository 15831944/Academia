#include "stdafx.h"

#include "Mouse.h"

#include "ObjManager.h"
#include "SceneManager.h"

#include "AbstractFactoryObj.h"

#include "MainGame.h"


MainGame::MainGame()
{
}


MainGame::~MainGame()
{
	Release();
}

void MainGame::Init()
{
	Obj *pMouse = AbstractFactoryObj<Mouse>::Create(WIN_WIDTH / 2.0f, WIN_HEIGHT / 2.0f);
	// ObjManager �� �߰��� ��.

	//SceneManager::getInstance()->ChangeScene(SceneManager::SCENE_TYPE::LOGO);


	BmpManager::getInstance()->InsertImage(L"../Image/Back.bmp", L"Back");
	BmpManager::getInstance()->InsertImage(L"../Image/BackBuffer.bmp", L"BackBuffer");

}

void MainGame::Update()
{
}

void MainGame::LateUpdate()
{
}

void MainGame::Render()
{
	int scrollX = ScrollManager::getScrollX();
	int scrollY = ScrollManager::getScrollY();

	HDC hMemDCForBackBuffer = BmpManager::getInstance()->FindImage(L"BackBuffer");
	HDC hMemDC = BmpManager::getInstance()->FindImage(L"Back");

	BitBlt(
		hMemDCForBackBuffer,
		0, 0,
		WIN_WIDTH, WIN_HEIGHT,
		hMemDC,
		0, 0,
		SRCCOPY
	);

	Rectangle(hMemDCForBackBuffer,
		300, 300,
		400, 400
	);

	//SceneManager::getInstance()->Render(hMemDCForBackBuffer);
	//UIManager::getInstance()->Render(hBackDC);

	BitBlt(
		mhdc,
		0, 0,
		WIN_WIDTH, WIN_HEIGHT,
		hMemDCForBackBuffer,
		0, 0,
		SRCCOPY
	);

}

void MainGame::Release()
{
	ReleaseDC(ghWnd, mhdc);

	SceneManager::DestroyInstance();
	//LineManager::DestroyInstance();
	BmpManager::DestroyInstance();
	KeyManager::DestroyInstance();
	SoundManager::DestroyInstance();
	//UIManager::DestroyInstance();
	ObjManager::DestroyInstance(); // ���� ���߿�...
}
