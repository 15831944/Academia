#include "stdafx.h"

#include "Obj.h"

#include "ObjManager.h"

ObjManager* ObjManager::mpInstance = nullptr;

ObjManager::ObjManager()
{
}


ObjManager::~ObjManager()
{
	Release();
}

int ObjManager::Update()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		list<Obj *>::iterator iter = mObjList[i].begin();
		for (; iter != mObjList[i].end(); )
		{
			int eventNum = (*iter)->Update();
			if (eventNum == OBJ_DEAD)
			{
				SafeDelete((*iter));
				iter = mObjList[i].erase(iter);
			}
			else
			{
				++iter;
			}
		}
	}

	return OBJ_NOEVENT;
}

void ObjManager::LateUpdate()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mObjList[i])
		{
			pObj->LateUpdate();

			// Menu Ŭ������ Button ��ü�� ������, ���ܳ��� ����...
			// Button Manager ������ �� !!!
			if (mObjList[i].empty())
			{
				break;
			}
		}
	}
}

void ObjManager::Render(HDC hdc)
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mObjList[i])
		{
			pObj->Render(hdc);
		}
	}
}

void ObjManager::Release()
{
	for (int i = 0; i < OBJ::TYPE::END; ++i)
	{
		for (Obj *pObj : mObjList[i])
		{
			SafeDelete(pObj);
		}
		mObjList[i].clear();
		mObjList[i].swap(list<Obj *>());
	}
}

void ObjManager::AddObject(Obj *pObj, OBJ::TYPE type)
{
	if (pObj != nullptr)
	{
		mObjList[type].emplace_back(pObj);
	}
}

void ObjManager::AddObjectFront(Obj *pObj, OBJ::TYPE type)
{
	if (pObj != nullptr)
	{
		mObjList[type].emplace_front(pObj);
	}
}

void ObjManager::DeleteObjType(OBJ::TYPE type)
{
	for (Obj *pObj : mObjList[type])
	{
		SafeDelete(pObj);
	}
	//mObjList[type].clear();
	mObjList[type].swap(list<Obj *>());
}

const Obj* ObjManager::getPlayer() const
{
	if (mObjList[OBJ::PLAYER].empty())
	{
		return nullptr; // ������ �÷��̾� "nullptr"�̸� ��� ���ӷ��� ���� �Ұ���...
	}

	return mObjList[OBJ::PLAYER].front();
}

const Obj* ObjManager::getMouse() const
{
	/*if (mObjList[OBJ::MOUSE].empty())
	{
		return nullptr;
	}

	return mObjList[OBJ::MOUSE].front();*/

	return nullptr;
}

const Obj * ObjManager::getInventory() const
{
	return nullptr;
}

const Obj * ObjManager::getTarget(Obj *pObjBase, OBJ::TYPE type) const
{
	// ��ü "pObjBase"�� ��������, "type"�� �ش��ϴ� ���� �Ÿ��� ���� ����� ��ü ã��

	if (mObjList[type].empty())
	{
		return nullptr;
	}

	Obj *pTarget = mObjList[type].front(); // �ʱ⿣ front();

	float baseX = pTarget->getInfo().xPos - pObjBase->getInfo().xPos;
	float baseY = pTarget->getInfo().yPos - pObjBase->getInfo().yPos;

	float baseDist = sqrtf(baseX * baseX + baseY * baseY);

	for (Obj *pObj : mObjList[type])
	{
		float targetX = pObj->getInfo().xPos - pObjBase->getInfo().xPos;
		float targetY = pObj->getInfo().yPos - pObjBase->getInfo().yPos;

		float targetDist = sqrtf(targetX * targetX + targetY * targetY);

		if (targetDist < baseDist)
		{
			pTarget = pObj;
			baseDist = targetDist;
		}
	}

	return pTarget;
}
