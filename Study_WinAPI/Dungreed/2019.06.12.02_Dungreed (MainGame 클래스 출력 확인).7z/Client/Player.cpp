#include "stdafx.h"
#include "Player.h"


Player::Player()
{
	
}


Player::~Player()
{
	Release();
}

void Player::Init()
{
}

int Player::Update()
{
	return OBJ_NOEVENT;
}

void Player::LateUpdate()
{
}

void Player::Render(HDC hdc)
{
}

void Player::Release()
{
}

void Player::Collision(const Obj * pObj, OBJ::TYPE type)
{
}
