#include "stdafx.h"
#include "ScrollManager.h"

int ScrollManager::mScrollX = 0;
int ScrollManager::mScrollY = 0;

ScrollManager::ScrollManager()
{
}


ScrollManager::~ScrollManager()
{
}

void ScrollManager::ScrollLock()
{
}
