#include "stdafx.h"
#include "AbyssGuardian.h"


AbyssGuardian::AbyssGuardian()
{
}


AbyssGuardian::~AbyssGuardian()
{
}
