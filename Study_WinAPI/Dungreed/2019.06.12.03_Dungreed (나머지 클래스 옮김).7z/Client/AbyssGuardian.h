#pragma once
#include "CharObj.h"
class AbyssGuardian :
	public CharObj
{
public:
	AbyssGuardian();
	virtual ~AbyssGuardian();
};

