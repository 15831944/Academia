#pragma once
#ifndef _BMP_MANAGER_H_
#define _BMP_MANAGER_H_

class BitMap;

class BmpManager
{
private:
	BmpManager();
	~BmpManager();

public:
	static BmpManager* getInstance()
	{
		if (mpInstance == nullptr)
		{
			mpInstance = new BmpManager;
		}
		return mpInstance;
	}

	static void DestroyInstance()
	{
		SAFE_DELETE(mpInstance);
	}

public:
	void Release();

public:
	void InsertImage(const TCHAR *pFilePath, const TCHAR *pImageKey);
	HDC FindImage(const TCHAR *pImageKey);


private:
	static BmpManager *mpInstance;

	map<const TCHAR *, BitMap *> mBmpMap;

};

#endif