#include "stdafx.h"
#include "BulletExplosionEffect.h"


BulletExplosionEffect::BulletExplosionEffect()
{
}


BulletExplosionEffect::~BulletExplosionEffect()
{
}
