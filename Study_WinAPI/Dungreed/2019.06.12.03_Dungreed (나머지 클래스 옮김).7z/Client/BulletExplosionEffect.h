#pragma once
#include "Obj.h"
class BulletExplosionEffect :
	public Obj
{
public:
	BulletExplosionEffect();
	virtual ~BulletExplosionEffect();
};

