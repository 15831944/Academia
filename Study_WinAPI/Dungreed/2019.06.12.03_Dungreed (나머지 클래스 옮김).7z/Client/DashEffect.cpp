#include "stdafx.h"
#include "DashEffect.h"


DashEffect::DashEffect()
{
}


DashEffect::~DashEffect()
{
}
