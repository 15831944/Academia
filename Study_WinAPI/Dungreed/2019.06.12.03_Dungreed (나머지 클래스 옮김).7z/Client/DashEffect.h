#pragma once
#include "Obj.h"
class DashEffect :
	public Obj
{
public:
	DashEffect();
	virtual ~DashEffect();
};

