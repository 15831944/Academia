#include "stdafx.h"
#include "DungeonGate.h"


DungeonGate::DungeonGate()
{
}


DungeonGate::~DungeonGate()
{
}
