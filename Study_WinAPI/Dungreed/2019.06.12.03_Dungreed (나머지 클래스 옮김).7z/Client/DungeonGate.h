#pragma once
#include "Obj.h"
class DungeonGate :
	public Obj
{
public:
	DungeonGate();
	virtual ~DungeonGate();
};

