#include "stdafx.h"
#include "Ghost.h"


Ghost::Ghost()
{
}


Ghost::~Ghost()
{
}
