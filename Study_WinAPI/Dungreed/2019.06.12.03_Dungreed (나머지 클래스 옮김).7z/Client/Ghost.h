#pragma once
#include "CharObj.h"
class Ghost :
	public CharObj
{
public:
	Ghost();
	virtual ~Ghost();
};

