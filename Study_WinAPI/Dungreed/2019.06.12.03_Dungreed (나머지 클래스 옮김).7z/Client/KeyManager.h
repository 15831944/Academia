#pragma once
#ifndef _KEY_MANAGER_H_
#define _KEY_MANAGER_H_

class KeyManager
{
private:
	KeyManager();
	~KeyManager();

public:
	static KeyManager* getInstance()
	{
		if (mpInstance == nullptr)
		{
			mpInstance = new KeyManager;
			//mpInstance->Init();
		}
		return mpInstance;
	}

	static void DestroyInstance()
	{
		SAFE_DELETE(mpInstance);
	}

private:
	void Init();

public:
	bool IsKeyPressing(KEY::TYPE type);
	bool IsKeyDown(KEY::TYPE type);
	bool IsKeyUp(KEY::TYPE type);
	bool IsNotAnyKeyPressed();

private:
	void KeyUpdate();

private:
	static KeyManager *mpInstance;

	map<KEY::TYPE, int> mKeyMap;
	map<int, bool>	mKeyStateMap;

};

#endif