#include "stdafx.h"
#include "Lilith.h"


Lilith::Lilith()
{
}


Lilith::~Lilith()
{
}
