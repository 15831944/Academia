#pragma once
#include "CharObj.h"
class Lilith :
	public CharObj
{
public:
	Lilith();
	virtual ~Lilith();
};

