#pragma once
#ifndef _LINE_H_
#define _LINE_H_

class Line
{
public:
	Line(const LINEINFO &tLineInfo);
	~Line();

public:
	void Render(HDC hdc);

public:
	const LINEINFO& getLineInfo() const { return mtLineInfo; }

private:
	LINEINFO mtLineInfo;
};

#endif
