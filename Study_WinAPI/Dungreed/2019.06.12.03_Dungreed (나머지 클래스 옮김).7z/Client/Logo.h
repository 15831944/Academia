#pragma once
#ifndef _LOGO_H_
#define _LOGO_H_

#include "Scene.h"

class Logo : public Scene
{
public:
	Logo();
	virtual ~Logo();

public:
	// Scene��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual void Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hdc) override;
	virtual void Release() override;


};

#endif