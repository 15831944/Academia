#pragma once
#ifndef _MAIN_GAME_H_
#define _MAIN_GAME_H_

class MainGame
{
public:
	MainGame();
	~MainGame();

public:
	void Init();
	void Update();
	void LateUpdate();
	void Render();
	void Release();

private:
	HDC mhdc;
};

#endif