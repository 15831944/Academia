#include "stdafx.h"

#include "Button.h"

#include "ObjManager.h"
#include "SceneManager.h"

//#include "ObjMenuBird.h"

#include "AbstractFactoryObj.h"

#include "Menu.h"


Menu::Menu()
{
}


Menu::~Menu()
{
	Release();
}

void Menu::Init()
{
}

void Menu::Update()
{
}

void Menu::LateUpdate()
{
}

void Menu::Render(HDC hdc)
{
}

void Menu::Release()
{
}
