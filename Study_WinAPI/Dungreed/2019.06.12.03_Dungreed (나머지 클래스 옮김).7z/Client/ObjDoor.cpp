#include "stdafx.h"
#include "ObjDoor.h"


ObjDoor::ObjDoor()
{
}


ObjDoor::~ObjDoor()
{
}
