#pragma once
#include "Obj.h"
class ObjDoor :
	public Obj
{
public:
	ObjDoor();
	virtual ~ObjDoor();
};

