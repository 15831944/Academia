#pragma once
#ifndef _OBJ_MANAGER_H_
#define _OBJ_MANAGER_H_

class Obj;

class ObjManager
{
private:
	ObjManager();
	~ObjManager();

public:
	static ObjManager* getInstance()
	{
		if (mpInstance == nullptr)
		{
			mpInstance = new ObjManager;
		}
		return mpInstance;
	}

	static void DestroyInstance()
	{
		SAFE_DELETE(mpInstance);
	}

public:
	int Update();
	void LateUpdate();
	void Render(HDC hdc);
	void Release();

public:
	void AddObject(Obj *pObj, OBJ::TYPE type);
	void AddObjectFront(Obj *pObj, OBJ::TYPE type);
	void DeleteObjType(OBJ::TYPE type);
	bool IsObjTypeListEmpty(OBJ::TYPE type) { return mObjList[type].empty(); }

public:
	const Obj* getPlayer() const;
	const Obj* getMouse() const;
	const Obj* getInventory() const;
	const Obj* getTarget(Obj *pObjBase, OBJ::TYPE type) const;
	const list<Obj *>& getObjTypeList(OBJ::TYPE type) const { return mObjList[type]; }

private:
	static ObjManager *mpInstance;

	list<Obj *> mObjList[OBJ::TYPE::END];

};

#endif