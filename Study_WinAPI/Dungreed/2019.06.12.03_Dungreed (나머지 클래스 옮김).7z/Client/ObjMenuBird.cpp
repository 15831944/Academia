#include "stdafx.h"
#include "ObjMenuBird.h"


ObjMenuBird::ObjMenuBird()
{
}


ObjMenuBird::~ObjMenuBird()
{
}
