#pragma once
#include "Obj.h"
class ObjMenuBird :
	public Obj
{
public:
	ObjMenuBird();
	virtual ~ObjMenuBird();
};

