#include "stdafx.h"
#include "ObjTorch.h"


ObjTorch::ObjTorch()
{
}


ObjTorch::~ObjTorch()
{
}
