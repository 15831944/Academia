#pragma once
#include "Obj.h"
class ObjTorch :
	public Obj
{
public:
	ObjTorch();
	virtual ~ObjTorch();
};

