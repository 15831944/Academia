#include "stdafx.h"
#include "RedGiantBat.h"


RedGiantBat::RedGiantBat()
{
}


RedGiantBat::~RedGiantBat()
{
}
