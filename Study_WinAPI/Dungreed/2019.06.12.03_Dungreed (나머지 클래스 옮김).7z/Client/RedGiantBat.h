#pragma once
#include "CharObj.h"
class RedGiantBat :
	public CharObj
{
public:
	RedGiantBat();
	virtual ~RedGiantBat();
};

