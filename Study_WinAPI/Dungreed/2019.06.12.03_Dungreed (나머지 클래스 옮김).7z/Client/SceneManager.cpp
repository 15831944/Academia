#include "stdafx.h"

#include "Logo.h"
//#include "Menu.h"
//#include "TileEiditor.h"

#include "Town.h"

//#include "DungeonEntrance.h"
//#include "DungeonStage1.h"

#include "SceneManager.h"


SceneManager* SceneManager::mpInstance = nullptr;


SceneManager::SceneManager()
	: mpScene(nullptr),
	meCurSceneType(SCENE_TYPE::END),
	meNextSceneType(SCENE_TYPE::END)
{
}


SceneManager::~SceneManager()
{
	Release();
}

void SceneManager::Update()
{
	mpScene->Update();
}

void SceneManager::LateUpdate()
{
	mpScene->LateUpdate();
}

void SceneManager::Render(HDC hdc)
{
	mpScene->Render(hdc);
}

void SceneManager::Release()
{
	SAFE_DELETE(mpScene);
}

void SceneManager::ChangeScene(SCENE_TYPE sceneType)
{
	meNextSceneType = sceneType;
	if (meCurSceneType != meNextSceneType)
	{
		// "Scene"�� �޸� ���� ���� �ʰ� �״�� ����� ���� �ִµ�...
		// ���� �� �غ��߰��� !!!!

		if (mpScene)
		{
			delete mpScene;
			mpScene = nullptr;
		}

		switch (meNextSceneType)
		{
		case SceneManager::LOGO:
			mpScene = new Logo;
			break;
		case SceneManager::MENU:
			//mpScene = new Menu;
			break;
		case SceneManager::EDIT:
			//mpScene = new TileEditor;
			break;
		case SceneManager::TOWN:
			mpScene = new Town;
			break;
		case SceneManager::ENTRANCE:
			//mpScene = new DungeonEntrance;
			break;
		case SceneManager::STAGE1:
			//mpScene = new DungeonStage1;
			break;
		case SceneManager::SKELLBOSS:
			//mpScene = new BossStage;
			break;
		case SceneManager::STAGE2:
			break;
		case SceneManager::NIFLHEIM:
			break;
		case SceneManager::END:
			break;
		default:
			break;
		}

		if (mpScene == nullptr)
		{
			return;
		}

		mpScene->Init();

		meCurSceneType = meNextSceneType;
	}
}
