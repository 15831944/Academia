#pragma once
#ifndef _SCENE_MANAGER_H_
#define _SCENE_MANAGER_H_

class Scene;

class SceneManager
{
private:
	SceneManager();
	~SceneManager();

public:
	enum SCENE_TYPE {
		LOGO,
		MENU,
		EDIT,
		TOWN,
		ENTRANCE,
		STAGE1,
		SKELLBOSS,
		STAGE2,
		NIFLHEIM,
		END
	};

public:
	static SceneManager* getInstance()
	{
		if (mpInstance == nullptr)
		{
			mpInstance = new SceneManager;
		}

		return mpInstance;
	}

	static void DestroyInstance()
	{
		SAFE_DELETE(mpInstance);
	}

public:
	void Update();
	void LateUpdate();
	void Render(HDC hdc);
	void Release();

public:
	void ChangeScene(SCENE_TYPE sceneType);

public:
	const SCENE_TYPE& getCurSceneType() const { return meCurSceneType; }

private:
	static SceneManager *mpInstance;

	Scene *mpScene;

	SCENE_TYPE meCurSceneType;
	SCENE_TYPE meNextSceneType;
};

#endif
