#pragma once
#ifndef _SKELL_BOSS_HAND_H_
#define _SKELL_BOSS_HAND_H_

#include "Obj.h"
class SkellBossHand : public Obj
{
public:
	SkellBossHand();
	virtual ~SkellBossHand();

public:
	// Obj��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual int Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hdc) override;
	virtual void Release() override;

public:
	virtual void Collision(const Obj * pObj, OBJ::TYPE type) override;

};

#endif