#include "stdafx.h"
#include "SkellBossSwordAfterImageEffect.h"


SkellBossSwordAfterImageEffect::SkellBossSwordAfterImageEffect()
{
}


SkellBossSwordAfterImageEffect::~SkellBossSwordAfterImageEffect()
{
}
