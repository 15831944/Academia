#pragma once
#include "Obj.h"
class SkellBossSwordAfterImageEffect :
	public Obj
{
public:
	SkellBossSwordAfterImageEffect();
	virtual ~SkellBossSwordAfterImageEffect();
};

