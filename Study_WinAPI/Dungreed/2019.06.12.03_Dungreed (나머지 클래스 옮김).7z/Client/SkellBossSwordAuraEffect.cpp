#include "stdafx.h"
#include "SkellBossSwordAuraEffect.h"


SkellBossSwordAuraEffect::SkellBossSwordAuraEffect()
{
}


SkellBossSwordAuraEffect::~SkellBossSwordAuraEffect()
{
}
