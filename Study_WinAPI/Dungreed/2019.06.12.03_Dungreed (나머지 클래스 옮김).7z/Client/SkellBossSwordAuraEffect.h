#pragma once
#include "Obj.h"
class SkellBossSwordAuraEffect :
	public Obj
{
public:
	SkellBossSwordAuraEffect();
	virtual ~SkellBossSwordAuraEffect();
};

