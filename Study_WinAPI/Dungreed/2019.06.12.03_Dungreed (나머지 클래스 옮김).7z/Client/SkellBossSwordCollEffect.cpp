#include "stdafx.h"
#include "SkellBossSwordCollisionEffect.h"


SkellBossSwordCollisionEffect::SkellBossSwordCollisionEffect()
{
}


SkellBossSwordCollisionEffect::~SkellBossSwordCollisionEffect()
{
}
