#pragma once
#include "Obj.h"
class SkellBossSwordCollisionEffect :
	public Obj
{
public:
	SkellBossSwordCollisionEffect();
	virtual ~SkellBossSwordCollisionEffect();
};

