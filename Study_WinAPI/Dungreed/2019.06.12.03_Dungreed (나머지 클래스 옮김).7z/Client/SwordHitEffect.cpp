#include "stdafx.h"
#include "SwordHitEffect.h"


SwordHitEffect::SwordHitEffect()
{
}


SwordHitEffect::~SwordHitEffect()
{
}
