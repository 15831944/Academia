#pragma once
#include "Obj.h"
class SwordHitEffect :
	public Obj
{
public:
	SwordHitEffect();
	virtual ~SwordHitEffect();
};

