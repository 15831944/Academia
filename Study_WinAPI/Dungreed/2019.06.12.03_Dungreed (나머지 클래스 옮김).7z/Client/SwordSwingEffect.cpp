#include "stdafx.h"
#include "SwordSwingEffect.h"


SwordSwingEffect::SwordSwingEffect()
{
}


SwordSwingEffect::~SwordSwingEffect()
{
}
