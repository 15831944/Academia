#pragma once
#include "Obj.h"
class SwordSwingEffect :
	public Obj
{
public:
	SwordSwingEffect();
	virtual ~SwordSwingEffect();
};

