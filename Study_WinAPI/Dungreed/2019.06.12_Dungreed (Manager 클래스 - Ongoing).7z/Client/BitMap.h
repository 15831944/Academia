#pragma once

#ifndef _BITMAP_H_
#define _BITMAP_H_

class BitMap
{
public:
	BitMap();
	~BitMap();

public:
	void Release();
	
public:
	void LoadBitMap(const TCHAR *pFilePath);

public:
	HDC getMemDC() { return mhMemDC; }

private:
	HDC mhMemDC;

	HBITMAP mhBitMap;
	HBITMAP mhOldBitMap;

};

#endif