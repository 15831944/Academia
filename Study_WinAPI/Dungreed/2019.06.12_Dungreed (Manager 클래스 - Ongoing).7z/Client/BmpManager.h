#pragma once
#ifndef _BMP_MANAGER_H_
#define _BMP_MANAGER_H_



class BmpManager
{
public:
	BmpManager();
	~BmpManager();
};

#endif