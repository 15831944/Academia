#include "stdafx.h"
#include "CharObj.h"


CharObj::CharObj()
{
}


CharObj::~CharObj()
{
}
