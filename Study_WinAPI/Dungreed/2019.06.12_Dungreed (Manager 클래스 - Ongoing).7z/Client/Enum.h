#pragma once
#ifndef _ENUM_H_
#define _ENUM_H_

namespace OBJ
{
	enum TYPE {
		BACKGROUND_FX,
		MONSTER_FX,
		PLAYER_FX,
		NPC,
		MONSTER,
		PLAYER,
		MONSTER_WEAPON,
		PLAYER_WEAPON,
		PLAYER_WEAPON_COLLISION,
		GENERAL_FX,
		END
	};

	enum DIRECTION {
		LEFT,
		RIGHT,
	};
}

namespace KEY
{
	enum TYPE {
		LEFT,
		RIGHT,
		UP,
		DOWN,
		JUMP,
		INTERACTION,
		INVENTORY,
		WEAPON_SWITCHING,
		LBUTTON,
		RBUTTON,
		KEY_NUM1,
		KEY_NUM2,
		KEY_NUM3,
		SKIP,
		TEST,
		LIFE,
		CHEAT
	};
}


#endif