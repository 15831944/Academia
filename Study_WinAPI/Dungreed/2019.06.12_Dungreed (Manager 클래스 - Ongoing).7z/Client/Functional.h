#pragma once
#ifndef _FUNCTIONAL_H_
#define _FUNCTIONAL_H_

#include "MyStrCmp.h"

template <typename T>
void SafeDelete(T &ptr)
{
	if (ptr)
	{
		delete ptr;
		ptr = nullptr;
	}
}

#endif