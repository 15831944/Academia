#include "stdafx.h"
#include "KeyManager.h"


KeyManager::KeyManager()
{
	Init(); // �ƴϸ� getInstance() �Լ����� ���ִ���...
}


KeyManager::~KeyManager()
{
}

void KeyManager::Init()
{
	// �⺻ ����
	mKeyMap.emplace(KEY::LEFT, 'A');
	mKeyStateMap.emplace('A', FALSE);
	mKeyMap.emplace(KEY::RIGHT, 'D');
	mKeyStateMap.emplace('D', FALSE);

	mKeyMap.emplace(KEY::DOWN, 'S');
	mKeyStateMap.emplace('S', FALSE);

	mKeyMap.emplace(KEY::JUMP, VK_SPACE);
	mKeyStateMap.emplace(VK_SPACE, FALSE);

	// Ư��Ű
	mKeyMap.emplace(KEY::INTERACTION, 'F');
	mKeyStateMap.emplace('F', FALSE);
	mKeyMap.emplace(KEY::INVENTORY, 'I');
	mKeyStateMap.emplace('I', FALSE);
	mKeyMap.emplace(KEY::WEAPON_SWITCHING, VK_TAB);
	mKeyStateMap.emplace(VK_TAB, FALSE);

	// ���콺
	mKeyMap.emplace(KEY::LBUTTON, VK_LBUTTON);
	mKeyStateMap.emplace(VK_LBUTTON, FALSE);
	mKeyMap.emplace(KEY::RBUTTON, VK_RBUTTON);
	mKeyStateMap.emplace(VK_RBUTTON, FALSE);

	// �ΰ� Skip
	mKeyMap.emplace(KEY::SKIP, VK_RETURN); // Enter Ű
	mKeyStateMap.emplace(VK_RETURN, FALSE);

	// Ÿ�ϸ� ������
	mKeyMap.emplace(KEY::UP, 'W');
	mKeyStateMap.emplace('W', FALSE);
	mKeyMap.emplace(KEY::KEY_NUM1, '1');
	mKeyStateMap.emplace('1', FALSE);
	mKeyMap.emplace(KEY::KEY_NUM2, '2');
	mKeyStateMap.emplace('2', FALSE);
	mKeyMap.emplace(KEY::KEY_NUM3, '3');
	mKeyStateMap.emplace('3', FALSE);
}

bool KeyManager::IsKeyPressing(KEY::TYPE type)
{
	/*
	0x0000
	0x0001
	0x8000
	0x8001
	*/

	if (GetAsyncKeyState(m_KeyMappingMap[type]) & 0x8000)
	{
		return TRUE;
	}

	return FALSE;
}

bool KeyManager::IsKeyDown(KEY::TYPE type)
{
	if (!(m_bKeyStateMap[m_KeyMappingMap[type]])
		&& (GetAsyncKeyState(m_KeyMappingMap[type]) & 0x8000))
	{
		m_bKeyStateMap[m_KeyMappingMap[type]] = !m_bKeyStateMap[m_KeyMappingMap[type]];
		return TRUE;
	}

	return FALSE;
}

bool KeyManager::IsKeyUp(KEY::TYPE type)
{
	if (m_bKeyStateMap[m_KeyMappingMap[type]]
		&& !(GetAsyncKeyState(m_KeyMappingMap[type]) & 0x8000))
	{
		m_bKeyStateMap[m_KeyMappingMap[type]] = !m_bKeyStateMap[m_KeyMappingMap[type]];
		return TRUE;
	}

	return FALSE;
}

bool KeyManager::IsNotAnyKeyPressed()
{
	map<int, bool>::iterator iter = m_bKeyStateMap.begin();
	for (; iter != m_bKeyStateMap.end(); ++iter)
	{
		if (iter->second == TRUE)
		{
			return FALSE;
		}
	}

	return TRUE;
}

void KeyManager::KeyUpdate()
{
	map<KEY::TYPE, int>::iterator keyIter = m_KeyMappingMap.begin();
	for (; keyIter != m_KeyMappingMap.end(); ++keyIter)
	{
		if (!(m_bKeyStateMap[keyIter->second]) && (GetAsyncKeyState(keyIter->second) & 0x8000))
		{
			m_bKeyStateMap[keyIter->second] = !m_bKeyStateMap[keyIter->second];
		}
		if ((m_bKeyStateMap[keyIter->second]) && !(GetAsyncKeyState(keyIter->second) & 0x8000))
		{
			m_bKeyStateMap[keyIter->second] = !m_bKeyStateMap[keyIter->second];
		}
	}
}
