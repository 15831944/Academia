#include "stdafx.h"
#include "Mouse.h"


Mouse::Mouse()
{
}


Mouse::~Mouse()
{
	Release();
}

void Mouse::Init()
{
	mtInfo.width = 10.0f;
	mtInfo.height = 10.0f;
}

int Mouse::Update()
{
	POINT pt;

	GetCursorPos(&pt);

	ClientToScreen(ghWnd, &pt);

	mtInfo.xPos = (float)pt.x;
	mtInfo.yPos = (float)pt.y;

	return OBJ_NOEVENT;
}

void Mouse::LateUpdate()
{
}

void Mouse::Render(HDC hdc)
{
	Obj::UpdateRect();

	Rectangle(hdc, mtRect.left, mtRect.top, mtRect.right, mtRect.bottom);
}

void Mouse::Release()
{
}

void Mouse::Collision(const Obj * pObj, OBJ::TYPE type)
{
}
