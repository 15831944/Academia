#include "stdafx.h"
#include "Obj.h"


Obj::Obj()
	: meObjType(OBJ::TYPE::END),
	mIsDead(FALSE), mIsInit(FALSE),
	mpFrameKey(nullptr),
	mSpeed(0.0f), mAngle(0.0f)
{
	ZeroMemory(&mtInfo, sizeof(INFO));
	ZeroMemory(&mtRect, sizeof(RECT));
	ZeroMemory(&mtFrame, sizeof(FRAME));
}


Obj::~Obj()
{
}

void Obj::LateInit()
{
	if (!(mIsInit))
	{
		this->LateInit();
		mIsInit = TRUE;
	}
}

void Obj::UpdateRect()
{
	mtRect.left = (LONG)(mtInfo.xPos - (mtInfo.width * 0.5f));
	mtRect.top = (LONG)(mtInfo.yPos - (mtInfo.height * 0.5f));
	mtRect.right = (LONG)(mtInfo.xPos + (mtInfo.width * 0.5f));
	mtRect.bottom = (LONG)(mtInfo.yPos + (mtInfo.height * 0.5f));
}

void Obj::FrameMove()
{
	// ��� �ð� + ��� �ӵ�?!
	if (mtFrame.dwFrameTime + mtFrame.dwFrameSpeed < GetTickCount())
	{
		++mtFrame.frameStart;
		mtFrame.dwFrameTime = GetTickCount();
	}

	// �� �̹̺��� frameStart ���� �Ѿ��, �ٽ� ó������ setting.
}
