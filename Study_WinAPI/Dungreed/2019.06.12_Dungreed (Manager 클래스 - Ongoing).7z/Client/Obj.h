#pragma once
#ifndef _OBJ_H_
#define _OBJ_H_

// ��ǥ�� ũ�Ⱑ �ִ� Object�� ���� ���� Ŭ����

class Obj
{
public:
	Obj();
	virtual ~Obj();

public:
	virtual void Init() = 0;
	virtual void LateInit();
	virtual int Update() = 0;
	virtual void LateUpdate() = 0;
	virtual void Render(HDC hdc) = 0;
	virtual void Release() = 0;

public:
	virtual void Collision(const Obj *pObj, OBJ::TYPE type) = 0;

protected:
	void UpdateRect();
	void FrameMove();

public:
	void SetPosition(float x, float y) { mtInfo.xPos = x, mtInfo.yPos = y; } // �̷��� �ǳ�???
	void SetFrameStart(int frameStart) { mtFrame.frameStart = frameStart; }
	void SetRectSize(float width, float height) { mtInfo.width = width, mtInfo.height = height; }

public:
	const INFO& getInfo() const { return mtInfo; }
	const RECT& getRect() const { return mtRect; }
	//const FRAME& getFrame() const { return mtFrame; }

public:
	void setSpeed(float speed) { mSpeed = speed; }
	void setAngle(float angle) { mAngle = angle; }
	void setIsDead(bool isTrue) { mIsDead = isTrue; }

protected:
	INFO mtInfo;
	RECT mtRect;
	FRAME mtFrame;

	TCHAR *mpFrameKey;

	OBJ::TYPE meObjType;

	bool mIsInit;
	bool mIsDead;
	
	float mSpeed;
	float mAngle;
};

#endif