#include "stdafx.h"

//#include "Logo.h"
//#include "Menu.h"
//#include "TileEiditor.h"

#include "Town.h"

//#include "DungeonEntrance.h"
//#include "DungeonStage1.h"

#include "SceneManager.h"


SceneManager* SceneManager::mpInstance = nullptr;


SceneManager::SceneManager()
	: mpScene(nullptr),
	meCurSceneType(SCENE::SCENE_END),
	meNextSceneType(SCENE::SCENE_END)
{
}


SceneManager::~SceneManager()
{
	Release();
}

void SceneManager::Update()
{
	mpScene->Update();
}

void SceneManager::LateUpdate()
{
}

void SceneManager::Render(HDC hdc)
{
}

void SceneManager::Release()
{
}

void SceneManager::ChangeScene(SCENE sceneType)
{
}
