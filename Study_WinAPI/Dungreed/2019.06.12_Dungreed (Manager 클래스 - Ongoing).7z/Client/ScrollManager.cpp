#include "stdafx.h"
#include "ScrollManager.h"


ScrollManager::ScrollManager()
{
}


ScrollManager::~ScrollManager()
{
}

void ScrollManager::ScrollLock()
{
}
