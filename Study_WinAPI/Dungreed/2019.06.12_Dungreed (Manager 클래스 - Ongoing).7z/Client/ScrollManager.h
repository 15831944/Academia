#pragma once
#ifndef _SCROLL_MANAGER_H_
#define _SCROLL_MANAGER_H_

class ScrollManager
{
private:
	ScrollManager();
	~ScrollManager();

public:
	static void ScrollLock();

	static void ResetScroll() { mScrollX = 0, mScrollY = 0; }
	static void AdjustScrollValue(int scrollX, int scrollY) { mScrollX = scrollX, mScrollY = scrollY; }

public:
	static int getScrollX() { return mScrollX; } // const Ű����� static ��� �Լ��� ����� �� ����?!
	static int getScrollY() { return mScrollY; }

public:
	static void setScrollX(int scrollX) { mScrollX = scrollX; }
	static void setScrollY(int scrollY) { mScrollY = scrollY; }
	//static void setStage(STAGE::TYPE type) { meStage = type; }

private:
	static int mScrollX;
	static int mScrollY;

	//static STAGE::TYPE meStage;

};

#endif