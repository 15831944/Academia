#include "stdafx.h"
#include "SkellBossHand.h"


SkellBossHand::SkellBossHand()
{
}


SkellBossHand::~SkellBossHand()
{
}

void SkellBossHand::Init()
{
}

int SkellBossHand::Update()
{
	return OBJ_NOEVENT;
}

void SkellBossHand::LateUpdate()
{
}

void SkellBossHand::Render(HDC hdc)
{
}

void SkellBossHand::Release()
{
}

void SkellBossHand::Collision(const Obj * pObj, OBJ::TYPE type)
{
}
