#include "stdafx.h"
#include "SkellBossHead.h"


SkellBossHead::SkellBossHead()
{
}


SkellBossHead::~SkellBossHead()
{
}
