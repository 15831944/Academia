#pragma once
#ifndef _SKELL_BOSS_HEAD_H_
#define _SKELL_BOSS_HEAD_H_

#include "CharObj.h"

class SkellBossHead : public CharObj
{
public:
	SkellBossHead();
	virtual ~SkellBossHead();
};

#endif