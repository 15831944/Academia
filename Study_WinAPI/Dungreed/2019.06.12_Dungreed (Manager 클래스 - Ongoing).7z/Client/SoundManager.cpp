#include "stdafx.h"
#include "SoundManager.h"

SoundManager* SoundManager::mpInstance = nullptr;

SoundManager::SoundManager()
	: mpSystem(nullptr)
{
	ZeroMemory(mpChannelArr, sizeof(mpChannelArr));
}


SoundManager::~SoundManager()
{
	Release();
}

void SoundManager::Init()
{
	FMOD_System_Create(&mpSystem);
	FMOD_System_Init(mpSystem, 32, FMOD_INIT_NORMAL, NULL);

	LoadSoundFile();
}

void SoundManager::Release()
{
	for (auto &pairObject : mSoundMap)
	{
		delete[] pairObject.first;
		FMOD_Sound_Release(pairObject.second);
	}
	mSoundMap.clear();

	FMOD_System_Release(mpSystem);
	FMOD_System_Close(mpSystem);
}

void SoundManager::PlaySoundFile(TCHAR * pSoundKey, CHANNEL channel)
{
	auto &iter = find_if(
		mSoundMap.begin(), mSoundMap.end(),
		MyStrCmp(pSoundKey)
	);

	if (iter == mSoundMap.end())
	{
		return;
	}

	FMOD_BOOL isPlay;

	if (FMOD_Channel_IsPlaying(mpChannelArr[channel], &isPlay))
	{
		FMOD_System_PlaySound(mpSystem, FMOD_CHANNEL_FREE, iter->second, FALSE, &mpChannelArr[channel]);
	}

	FMOD_System_Update(mpSystem);
}

void SoundManager::PlayBGM(TCHAR * pSoundKey)
{
	if (mSoundMap.empty())
	{
		return;
	}

	auto &iter = find_if(
		mSoundMap.begin(), mSoundMap.end(),
		MyStrCmp(pSoundKey)
	);

	if (iter == mSoundMap.end())
	{
		return;
	}

	FMOD_System_PlaySound(mpSystem, FMOD_CHANNEL_FREE, iter->second, FALSE, &mpChannelArr[CHANNEL::BGM]);
	FMOD_Channel_SetMode(mpChannelArr[BGM], FMOD_LOOP_NORMAL); // FMOD_LOOP_OFF �ݺ� ��� ���� ��...
	FMOD_System_Update(mpSystem);
}

void SoundManager::StopSound(CHANNEL channel)
{
	FMOD_Channel_Stop(mpChannelArr[channel]);
}

void SoundManager::StopAllSound()
{
	for (int i = 0; i < CHANNEL::MAXCHANNEL; ++i)
	{
		FMOD_Channel_Stop(mpChannelArr[i]);
	}
}

void SoundManager::LoadSoundFile()
{
	_finddata_t fd;

	long handle = _findfirst("../Sound/*.*", &fd);

	if (handle == 0)
		return;

	int result = 0;

	char curPath[128] = "../Sound/";
	char fullPath[128] = "";

	while (result != -1)
	{
		strcpy_s(fullPath, curPath);
		strcat_s(fullPath, fd.name);

		FMOD_SOUND *pSound = nullptr;

		FMOD_RESULT eRes = FMOD_System_CreateSound(mpSystem, fullPath, FMOD_HARDWARE, 0, &pSound);
		if (eRes == FMOD_OK)
		{
			int length = strlen(fd.name) + 1;

			TCHAR *pSoundKey = new TCHAR[sizeof(TCHAR) * length];
			ZeroMemory(pSoundKey, sizeof(TCHAR) * length);

			// ����ϴ� ���� �ڵ��� ���� �ٲ�. ex �ƽ�Ű �ڵ� -> �����ڵ� �̷� ���
			MultiByteToWideChar(CP_ACP, 0, fd.name, length, pSoundKey, length);

			mSoundMap.emplace(pSoundKey, pSound);
		}

		result = _findnext(handle, &fd);

	}

	FMOD_System_Update(mpSystem);
}
