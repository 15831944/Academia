#pragma once
class TileManager
{
public:
	TileManager();
	~TileManager();
};

