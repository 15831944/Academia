#include "stdafx.h"



#include "ObjManager.h"

#include "Town.h"


Town::Town()
{
}


Town::~Town()
{
}

void Town::Init()
{
}

void Town::Update()
{
	ObjManager::getInstance()->Update();
}

void Town::LateUpdate()
{
	ObjManager::getInstance()->LateUpdate();
}

void Town::Render(HDC hdc)
{
	int scrollX = ScrollManager::getScrollX();
	int scrollY = ScrollManager::getScrollY();

	HDC hMemDCForTownBackground;
}

void Town::Release()
{
}
