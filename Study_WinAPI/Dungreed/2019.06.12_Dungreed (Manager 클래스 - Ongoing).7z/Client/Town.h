#pragma once
#ifndef _TOWN_H_
#define _TOWN_H_

#include "Scene.h"

class Town : public Scene
{
public:
	Town();
	virtual ~Town();

public:
	// Scene��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual void Update() override;
	virtual void LateUpdate() override;
	virtual void Render(HDC hdc) override;
	virtual void Release() override;
};

#endif