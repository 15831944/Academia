#pragma once
class UIManager
{
public:
	UIManager();
	~UIManager();
};

