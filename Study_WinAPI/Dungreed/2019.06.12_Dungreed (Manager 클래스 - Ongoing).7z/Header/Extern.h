#pragma once
#ifndef _EXTERN_H_
#define _EXTERN_H_

extern HWND ghWnd;

#endif