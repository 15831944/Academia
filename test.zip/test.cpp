/*

한글한글

*/


#include <iostream>

using std::cout;
using std::endl;

int main(void) {


	cout << "한글한글" << endl;
}